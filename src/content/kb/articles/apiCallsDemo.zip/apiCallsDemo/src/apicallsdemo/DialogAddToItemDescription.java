/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.soap.eBLBaseComponents.*;

public class DialogAddToItemDescription extends JDialog {
  private ApiContext apiContext = new ApiContext();

  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JButton btnCallAddToItemDescription = new JButton();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel7 = new JPanel();
  JTextField txtItemID = new JTextField();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextPane txtDescriptionToAppend = new JTextPane();
  BorderLayout borderLayout3 = new BorderLayout();
  JScrollPane jScrollPane1 = new JScrollPane();

  public DialogAddToItemDescription(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogAddToItemDescription() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    btnCallAddToItemDescription.setText("AddToItemDescription");
    btnCallAddToItemDescription.addActionListener(new DialogAddToItemDescription_btnCallAddToItemDescription_actionAdapter(this));
    jLabel1.setPreferredSize(new Dimension(60, 15));
    jLabel1.setText("Item ID");
    jLabel2.setPreferredSize(new Dimension(60, 15));
    jLabel2.setText("Description");
    txtDescriptionToAppend.setPreferredSize(new Dimension(200, 100));
    jPanel4.setLayout(borderLayout3);
    txtItemID.setMinimumSize(new Dimension(6, 21));
    txtItemID.setPreferredSize(new Dimension(205, 21));
    txtItemID.setText("");
    jPanel5.setPreferredSize(new Dimension(149, 40));
    jPanel6.setMinimumSize(new Dimension(52, 31));
    jPanel6.setPreferredSize(new Dimension(280, 35));
    getContentPane().add(panel1);
    panel1.add(jPanel1,  BorderLayout.NORTH);
    panel1.add(jPanel2,  BorderLayout.CENTER);
    panel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel1.add(jPanel4,  BorderLayout.NORTH);
    jPanel4.add(jPanel6,  BorderLayout.NORTH);
    jPanel6.add(jLabel1, null);
    jPanel6.add(txtItemID, null);
    jPanel4.add(jPanel7, BorderLayout.CENTER);
    jPanel7.add(jLabel2, null);
    jPanel7.add(jScrollPane1, null);
    jScrollPane1.getViewport().add(txtDescriptionToAppend, null);
    jPanel1.add(jPanel5, BorderLayout.CENTER);
    jPanel5.add(btnCallAddToItemDescription, null);
    this.setSize(new Dimension(300, 210));
    this.setResizable(false);
  }

  void btnCallAddToItemDescription_actionPerformed(ActionEvent e) {
    try
    {
      AddToItemDescriptionCall api = new AddToItemDescriptionCall(this.apiContext);

      String itemID = this.txtItemID.getText();
      if( itemID.length() == 0 )
        throw new SdkException("Please enter item ID.");
      api.setItemID(new ItemIDType(itemID));

      String desc = this.txtDescriptionToAppend.getText();
      if( desc.length() == 0 )
        throw new SdkException("Please enter description to be appended.");
      api.setDescription(desc);

      api.addToItemDescription();

      ((FrameDemo)this.getParent()).showInfoMessage("The description has been appended successfully.");
    }
    catch(Exception ex)
    {
      String msg = ex.getClass().getName() + " : " + ex.getMessage();
      ((FrameDemo)this.getParent()).showErrorMessage(msg);
    }
  }
}

class DialogAddToItemDescription_btnCallAddToItemDescription_actionAdapter implements java.awt.event.ActionListener {
  DialogAddToItemDescription adaptee;

  DialogAddToItemDescription_btnCallAddToItemDescription_actionAdapter(DialogAddToItemDescription adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnCallAddToItemDescription_actionPerformed(e);
  }
}
