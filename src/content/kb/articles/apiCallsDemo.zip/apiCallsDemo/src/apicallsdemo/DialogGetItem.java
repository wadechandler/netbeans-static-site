/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
			  All rights reserved."

*/

package apicallsdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.soap.eBLBaseComponents.*;
import com.ebay.sdk.helper.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: eBay Inc.</p>
 * @author Weijun Li
 * @version 1.0
 */

public class DialogGetItem extends JDialog {
  private ApiContext apiContext = new ApiContext();

  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanelResult = new JPanel();
  JPanel jPanel3 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JTextField txtItemId = new JTextField();
  BorderLayout borderLayout2 = new BorderLayout();
  FlowLayout flowLayout1 = new FlowLayout();
  JLabel jLabel3 = new JLabel();
  JPanel jPanelTitle = new JPanel();
  JTextField txtTitle = new JTextField();
  JPanel jPanelDescription = new JPanel();
  JLabel jLabel10 = new JLabel();
  JPanel jPanel2 = new JPanel();
  JLabel jLabel4 = new JLabel();
  JTextField txtReservePrice = new JTextField();
  JPanel jPanel16 = new JPanel();
  JPanel jPanel8 = new JPanel();
  JTextField txtCategory = new JTextField();
  JLabel jLabel7 = new JLabel();
  JPanel jPanelPrice = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JPanel jPanel10 = new JPanel();
  JTextField txtBINPrice = new JTextField();
  JTextField txtCurrentPrice = new JTextField();
  JPanel jPanel14 = new JPanel();
  JPanel jPanel15 = new JPanel();
  JPanel jPanel9 = new JPanel();
  JTextField txtQuantity = new JTextField();
  JLabel jLabel5 = new JLabel();
  JButton btnGetItem = new JButton();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTextPane txtaDescription = new JTextPane();
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel7 = new JPanel();
  JScrollPane spShippingServices = new JScrollPane();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel18 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JTextField txtShippingType = new JTextField();
  BorderLayout borderLayout4 = new BorderLayout();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JLabel jLabel20 = new JLabel();
  JTextField txtSellerGuarantee = new JTextField();
  JLabel jLabel21 = new JLabel();
  JTextField txtLotSize = new JTextField();
  JLabel jLabel22 = new JLabel();
  JLabel jLabel23 = new JLabel();
  JTextField txtFinanceOfferId = new JTextField();
  JLabel jLabel24 = new JLabel();
  JLabel jLabel25 = new JLabel();
  JTextField txtBorder = new JTextField();
  JLabel jLabel26 = new JLabel();
  JTextField txtSPOT = new JTextField();
  JLabel jLabel27 = new JLabel();
  JLabel jLabel28 = new JLabel();
  JTextField txtZip = new JTextField();
  JLabel jLabel29 = new JLabel();
  JLabel jLabel30 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel31 = new JLabel();
  JTextField txtBINPriceLowered = new JTextField();
  JTextField txtReservePriceLowered = new JTextField();
  JLabel jLabel32 = new JLabel();
  JTextField txtNowAndNew = new JTextField();
  JTextField txtApplyShippingDiscount = new JTextField();
  JLabel jLabel33 = new JLabel();
  JLabel jLabel34 = new JLabel();

  public DialogGetItem(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
//      pack();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetItem() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jLabel1.setRequestFocusEnabled(true);
    jLabel1.setText("ItemID:");
    txtItemId.setMinimumSize(new Dimension(200, 21));
    txtItemId.setPreferredSize(new Dimension(200, 21));
    jPanelResult.setLayout(borderLayout2);
    jPanelResult.setBorder(BorderFactory.createEtchedBorder());
    flowLayout1.setHgap(5);
    jLabel3.setText("Title:       ");
    jLabel3.setRequestFocusEnabled(true);
    jLabel3.setToolTipText("");
    jLabel3.setHorizontalAlignment(SwingConstants.LEADING);
    jLabel3.setPreferredSize(new Dimension(80, 15));
    jLabel3.setMinimumSize(new Dimension(55, 15));
    jLabel3.setMaximumSize(new Dimension(55, 15));
    jPanelTitle.setLayout(flowLayout1);
    txtTitle.setMaximumSize(new Dimension(2147483647, 2147483647));
    txtTitle.setMinimumSize(new Dimension(360, 21));
    txtTitle.setOpaque(true);
    txtTitle.setPreferredSize(new Dimension(365, 21));
    txtTitle.setEditable(false);
    txtTitle.setHorizontalAlignment(SwingConstants.LEADING);
    txtTitle.setScrollOffset(0);
    jLabel10.setMaximumSize(new Dimension(55, 15));
    jLabel10.setMinimumSize(new Dimension(55, 15));
    jLabel10.setPreferredSize(new Dimension(85, 15));
    jLabel10.setText("Description:");
    jPanel2.setBorder(null);
    jPanel2.setMinimumSize(new Dimension(459, 80));

    jPanelResult.setPreferredSize(new Dimension(459, 400));
    jPanel2.setPreferredSize(new Dimension(459, 180));
    jPanel2.setLayout(gridBagLayout1);
    this.setTitle("eBay SDK for Java - GetItem");
    jLabel4.setMaximumSize(new Dimension(68, 15));
    jLabel4.setMinimumSize(new Dimension(68, 15));
    jLabel4.setPreferredSize(new Dimension(68, 15));
    jLabel4.setText("Category:");
    txtReservePrice.setMinimumSize(new Dimension(70, 21));
    txtReservePrice.setPreferredSize(new Dimension(70, 21));
    txtReservePrice.setEditable(false);
    txtReservePrice.setText("");
    txtCategory.setMinimumSize(new Dimension(70, 21));
    txtCategory.setPreferredSize(new Dimension(70, 21));
    txtCategory.setRequestFocusEnabled(true);
    txtCategory.setEditable(false);
    txtCategory.setText("");
    jLabel7.setMaximumSize(new Dimension(68, 15));
    jLabel7.setMinimumSize(new Dimension(68, 15));
    jLabel7.setPreferredSize(new Dimension(68, 15));
    jLabel7.setText("CurrentPrice:");
    jPanelPrice.setLayout(gridLayout1);
    gridLayout1.setColumns(3);
    gridLayout1.setHgap(0);
    gridLayout1.setRows(2);
    gridLayout1.setVgap(0);
    txtBINPrice.setMinimumSize(new Dimension(70, 21));
    txtBINPrice.setPreferredSize(new Dimension(70, 21));
    txtBINPrice.setEditable(false);
    txtBINPrice.setText("");
    txtCurrentPrice.setMinimumSize(new Dimension(70, 21));
    txtCurrentPrice.setPreferredSize(new Dimension(70, 21));
    txtCurrentPrice.setEditable(false);
    txtCurrentPrice.setText("");
    txtQuantity.setMinimumSize(new Dimension(70, 21));
    txtQuantity.setPreferredSize(new Dimension(70, 21));
    txtQuantity.setEditable(false);
    txtQuantity.setText("");
    jLabel5.setMaximumSize(new Dimension(68, 15));
    jLabel5.setMinimumSize(new Dimension(68, 15));
    jLabel5.setPreferredSize(new Dimension(68, 15));
    jLabel5.setText("Quantity:");
    btnGetItem.setText("GetItem");
    btnGetItem.addActionListener(new DialogGetItem_btnGetItem_actionAdapter(this));
    txtaDescription.setBorder(null);
    txtaDescription.setOpaque(true);
    txtaDescription.setPreferredSize(new Dimension(185, 21));
    txtaDescription.setEditable(false);
    jScrollPane1.setMinimumSize(new Dimension(24, 24));
    jScrollPane1.setPreferredSize(new Dimension(360, 50));
    jPanel3.setPreferredSize(new Dimension(459, 150));
    jPanel3.setLayout(borderLayout3);
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jPanel5.setPreferredSize(new Dimension(459, 10));
    jPanel4.setPreferredSize(new Dimension(459, 25));
    jPanel4.setLayout(borderLayout4);
    jLabel2.setText("    ");
    jLabel6.setText("                ");
    jLabel11.setText("    ");
    jLabel12.setText("    ");
    jLabel13.setText("    ");
    jLabel15.setText("ReservePrice:");
    jLabel16.setText("    ");
    jLabel17.setText("    ");
    jLabel18.setText("BIN Price:");
    jLabel8.setText("ShippingType:");
    txtShippingType.setBackground(SystemColor.activeCaptionBorder);
    txtShippingType.setPreferredSize(new Dimension(70, 21));
    txtShippingType.setText("");
    spShippingServices.getViewport().setBackground(Color.white);
    jLabel9.setText("   Checkout:");
    jLabel19.setText("ShippingType:");
    jLabel20.setText("    ");
    txtSellerGuarantee.setBackground(UIManager.getColor("Button.background"));
    txtSellerGuarantee.setPreferredSize(new Dimension(70, 21));
    txtSellerGuarantee.setText("");
    jLabel21.setText("SellerGuarantee:");
    txtLotSize.setBackground(UIManager.getColor("Button.background"));
    txtLotSize.setPreferredSize(new Dimension(70, 21));
    txtLotSize.setText("");
    jLabel22.setText("LotSize:");
    jLabel23.setText("    ");
    txtFinanceOfferId.setBackground(UIManager.getColor("Button.background"));
    txtFinanceOfferId.setPreferredSize(new Dimension(70, 21));
    txtFinanceOfferId.setSelectedTextColor(Color.white);
    txtFinanceOfferId.setText("");
    jLabel24.setText("FinanceOfferID:");
    jLabel25.setText("Border:");
    txtBorder.setBackground(UIManager.getColor("Button.background"));
    txtBorder.setPreferredSize(new Dimension(70, 21));
    txtBorder.setText("");
    jLabel26.setText("    ");
    txtSPOT.setBackground(UIManager.getColor("Button.background"));
    txtSPOT.setPreferredSize(new Dimension(70, 21));
    txtSPOT.setRequestFocusEnabled(true);
    txtSPOT.setSelectedTextColor(Color.white);
    txtSPOT.setText("");
    jLabel27.setText("IncludeInProximitySearch:");
    jLabel28.setText("PostalCode:");
    txtZip.setBackground(UIManager.getColor("Button.background"));
    txtZip.setPreferredSize(new Dimension(70, 21));
    txtZip.setText("");
    jLabel29.setRequestFocusEnabled(true);
    jLabel29.setText("        ");
    jLabel30.setText("    ");
    jLabel14.setText("BINPriceLowered:");
    jLabel31.setText("ReservePriceLowered:");
    txtBINPriceLowered.setBackground(UIManager.getColor("Button.background"));
    txtBINPriceLowered.setPreferredSize(new Dimension(70, 21));
    txtBINPriceLowered.setText("");
    txtReservePriceLowered.setBackground(UIManager.getColor("Button.background"));
    txtReservePriceLowered.setPreferredSize(new Dimension(70, 21));
    txtReservePriceLowered.setText("");
    jLabel32.setText("  ");
    txtApplyShippingDiscount.setBackground(UIManager.getColor("Button.background"));
    txtApplyShippingDiscount.setPreferredSize(new Dimension(70, 21));
    txtApplyShippingDiscount.setText("");
    txtNowAndNew.setBackground(UIManager.getColor("Button.background"));
    txtNowAndNew.setPreferredSize(new Dimension(70, 21));
    txtNowAndNew.setText("");
    jLabel33.setText("NowAndNew:");
    jLabel34.setText("ApplyShippingDiscount:");
    jPanelDescription.add(jLabel10, null);
    jPanelDescription.add(jScrollPane1, null);
    jScrollPane1.getViewport().add(txtaDescription, null);
    jPanel1.add(jLabel1, null);
    jPanel1.add(txtItemId, null);
    jPanel1.add(jLabel29, null);
    jPanel1.add(btnGetItem, null);
    getContentPane().add(panel1);
    panel1.add(jPanel1, BorderLayout.NORTH);
    panel1.add(jPanelResult, BorderLayout.CENTER);
    panel1.add(jPanel3,  BorderLayout.SOUTH);
    jPanel3.add(jPanel4, BorderLayout.NORTH);
    jPanel4.add(jLabel9, BorderLayout.WEST);
    jPanel3.add(jPanel5, BorderLayout.SOUTH);
    jPanel3.add(jPanel6, BorderLayout.WEST);
    jPanel3.add(jPanel7, BorderLayout.EAST);
    jPanel3.add(spShippingServices, BorderLayout.CENTER);
    jPanelResult.add(jPanelTitle,  BorderLayout.NORTH);
    jPanelTitle.add(jLabel3, null);
    jPanelTitle.add(txtTitle, null);
    jPanelResult.add(jPanelDescription,  BorderLayout.SOUTH);
    jPanelResult.add(jPanel2, BorderLayout.CENTER);

    jPanel2.add(jLabel5,     new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel2,     new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtQuantity,    new GridBagConstraints(2, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel6,     new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel4,     new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel11,    new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtCategory,   new GridBagConstraints(6, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel12,    new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel13,    new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtCurrentPrice,   new GridBagConstraints(2, 3, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel7,    new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel16,    new GridBagConstraints(1, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel17,    new GridBagConstraints(1, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel18,     new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtBINPrice,   new GridBagConstraints(2, 6, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel20,    new GridBagConstraints(0, 8, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel23,   new GridBagConstraints(2, 12, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtFinanceOfferId,     new GridBagConstraints(2, 13, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel24,     new GridBagConstraints(0, 13, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel25,    new GridBagConstraints(4, 13, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtBorder,     new GridBagConstraints(6, 13, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel26,    new GridBagConstraints(0, 14, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtSPOT,     new GridBagConstraints(2, 15, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel27,     new GridBagConstraints(0, 15, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel28,     new GridBagConstraints(4, 15, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtZip,     new GridBagConstraints(6, 15, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel30,   new GridBagConstraints(0, 10, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel21, new GridBagConstraints(0, 11, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtSellerGuarantee, new GridBagConstraints(2, 11, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel22, new GridBagConstraints(4, 11, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtLotSize, new GridBagConstraints(6, 11, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel15, new GridBagConstraints(0, 9, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtReservePrice, new GridBagConstraints(2, 9, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel19, new GridBagConstraints(4, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtShippingType, new GridBagConstraints(6, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel14,   new GridBagConstraints(4, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel31,   new GridBagConstraints(4, 9, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtBINPriceLowered,   new GridBagConstraints(6, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtReservePriceLowered,   new GridBagConstraints(6, 9, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel32,  new GridBagConstraints(0, 16, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtNowAndNew,   new GridBagConstraints(2, 17, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtApplyShippingDiscount,   new GridBagConstraints(6, 17, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel33,   new GridBagConstraints(0, 17, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel34,   new GridBagConstraints(4, 17, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

    this.setModal(true);
    this.setResizable(false);
    this.setSize(new Dimension(520, 580));
  }

  void btnGetItem_actionPerformed(ActionEvent e) {

    try
    {
      if( this.txtItemId.getText().length() == 0 )
        throw new Exception("Please enter Item ID first.");

      GetItemCall api = new GetItemCall(apiContext);

      DetailLevelCodeType[] detailLevels = new DetailLevelCodeType[] {
          DetailLevelCodeType.ReturnAll,
          DetailLevelCodeType.ItemReturnAttributes,
          DetailLevelCodeType.ItemReturnDescription
      };
      api.setDetailLevel(detailLevels);

      ItemIDType itemID = new ItemIDType(this.txtItemId.getText());
      ItemType item = api.getItem(itemID);

      // Display data in GUI.
      this.txtTitle.setText(item.getTitle());
      this.txtQuantity.setText(item.getQuantity().toString());
      this.txtCategory.setText(item.getPrimaryCategory().getCategoryID());
      this.txtCurrentPrice.setText(
        (new Double(item.getSellingStatus().getCurrentPrice().getValue()).toString()));

      AmountType amt = item.getReservePrice();
      this.txtReservePrice.setText(
        amt == null ? "" : (new Double(amt.getValue()).toString()));

      amt = item.getBuyItNowPrice();
      this.txtBINPrice.setText(
        amt == null ? "" : (new Double(amt.getValue()).toString()));

      ReviseStatusType reviseStatus = item.getReviseStatus();
      Boolean binPriceLowered = reviseStatus.getBuyItNowLowered();
      if (binPriceLowered != null) {
        this.txtBINPriceLowered.setText(binPriceLowered.toString());
      }
      Boolean reservePriceLowered = reviseStatus.getReserveLowered();
      if (reservePriceLowered != null) {
        this.txtReservePriceLowered.setText(reservePriceLowered.toString());
      }
      this.txtaDescription.setText(item.getDescription());

      SellerGuaranteeLevelCodeType level = item.getSeller().getSellerInfo().getSellerGuaranteeLevel();
      if (level != null) {
        this.txtSellerGuarantee.setText(level.getValue().toString());
      }
      Integer lotSize = item.getLotSize();
      if (lotSize != null) {
        this.txtLotSize.setText(lotSize.toString());
      }
      String financeOfferId = item.getFinanceOfferID();
      if (financeOfferId != null) {
        this.txtFinanceOfferId.setText(financeOfferId);
      }

      ListingEnhancementsCodeType[] enhancements = item.getListingEnhancement();
      int len = enhancements != null ? enhancements.length : 0;
      if (len > 0) {
        for (int i = 0; i < len; i++) {
          if (enhancements[i] == ListingEnhancementsCodeType.Border) {
            this.txtBorder.setText("true");
          }
        }
      }

      ProximitySearchDetailsType spot = item.getProximitySearchDetails();
      if (spot != null) {
        this.txtSPOT.setText(spot.getIncludeInProximitySearch().toString());
        this.txtZip.setText(spot.getPostalCode().toString());
      }

      Boolean nowAndNew = item.getNowAndNew();
      if (nowAndNew != null) {
        this.txtNowAndNew.setText(nowAndNew.toString());
      }

      Boolean applyShippingDiscount = item.getApplyShippingDiscount();
      if (applyShippingDiscount != null) {
        this.txtApplyShippingDiscount.setText(applyShippingDiscount.toString());
      }

      displayShippingServices(item.getShippingDetails());
    }
    catch(Exception ex)
    {
      ((FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }

  void displayShippingServices(ShippingDetailsType shippingDetails)
  {
    ShippingTypeCodeType shippingType = shippingDetails.getShippingType();

    if (shippingType != null) {
      this.txtShippingType.setText(shippingType.getValue().toString());
    }

    DefaultMutableTreeNode root =  new DefaultMutableTreeNode("Checkout Details");
    ShippingServiceOptionTreeBuilder builder = ShippingServiceOptionTreeBuilder.getInstance();
    root.add(builder.buildShippingServiceOptionTree(shippingType, shippingDetails.getShippingServiceOptions()));
    root.add(builder.buildShippingServiceOptionTree(shippingType, shippingDetails.getInternationalShippingServiceOption()));

    JTree jTree1 = new JTree(root);
    jTree1.setEditable(false);
    jTree1.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
    jTree1.setShowsRootHandles(true);

    this.spShippingServices.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    this.spShippingServices.setViewportBorder(BorderFactory.createEtchedBorder());
    this.spShippingServices.getViewport().add(jTree1, null);
  }
}

class DialogGetItem_btnGetItem_actionAdapter implements java.awt.event.ActionListener {
  DialogGetItem adaptee;

  DialogGetItem_btnGetItem_actionAdapter(DialogGetItem adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnGetItem_actionPerformed(e);
  }
}
