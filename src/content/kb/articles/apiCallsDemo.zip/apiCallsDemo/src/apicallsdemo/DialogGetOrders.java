/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.event.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.soap.eBLBaseComponents.*;
import com.ebay.sdk.helper.ui.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: eBay Inc.</p>
 * @author not attributable
 * @version 1.0
 */

public class DialogGetOrders extends JDialog {
  private ApiContext apiContext = new ApiContext();

  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel0 = new JPanel();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JButton btnGetOrders = new JButton();

  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel2 = new JPanel();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel8 = new JPanel();
  JPanel jPanel9 = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField txtOrderId = new JTextField();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JTextField txtStartDate = new JTextField();
  JLabel jLabel6 = new JLabel();
  JTextField txtEndDate = new JTextField();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  GridBagLayout gridBagLayout3 = new GridBagLayout();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JComboBox cbxOrderStatus = new JComboBox();
  JComboBox cbxOrderRole = new JComboBox();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  BorderLayout borderLayout5 = new BorderLayout();
  BorderLayout borderLayout6 = new BorderLayout();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel18 = new JLabel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JLabel jLabel19 = new JLabel();
  JLabel jLabel20 = new JLabel();
  JTextField txtNumberOfOrders = new JTextField();
  BorderLayout borderLayout7 = new BorderLayout();
  JPanel jPanel10 = new JPanel();
  JPanel jPanel11 = new JPanel();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel13 = new JPanel();
  BorderLayout borderLayout8 = new BorderLayout();
  JPanel jPanel14 = new JPanel();
  JPanel jPanel15 = new JPanel();
  JPanel jPanel16 = new JPanel();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel24 = new JLabel();
  JLabel jLabel21 = new JLabel();
  JLabel jLabel22 = new JLabel();

  public DialogGetOrders(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetOrders() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    this.setModal(true);
    this.setTitle("eBay SDK for Java - GetOrders");

    jPanel1.setLayout(borderLayout2);
    jPanel3.setLayout(borderLayout3);

    btnGetOrders.setText("GetOrders");
    btnGetOrders.addActionListener(new DialogGetOrders_btnGetOrders_actionAdapter(this));
    jPanel6.setLayout(borderLayout6);
    jPanel5.setMinimumSize(new Dimension(10, 1));
    jPanel5.setPreferredSize(new Dimension(10, 1));
    jPanel2.setLayout(borderLayout4);
    jPanel7.setLayout(gridBagLayout1);
    jLabel1.setText("OrderID(s):");
    jLabel2.setText("        ");
    txtOrderId.setPreferredSize(new Dimension(200, 21));
    jLabel3.setText("  ");
    jLabel4.setText("StartDate:");
    jLabel5.setText("  ");
    txtStartDate.setPreferredSize(new Dimension(160, 21));
    txtStartDate.setText("");
    jLabel6.setText("EndDate:");
    txtEndDate.setPreferredSize(new Dimension(160, 21));
    txtEndDate.setText("");
    jLabel7.setText("  ");
    jLabel8.setText("OrderRole:");
    jPanel8.setLayout(gridBagLayout3);
    jLabel10.setText("  ");
    jLabel11.setText("    ");
    jLabel12.setText("OrderStatus:");
    jLabel9.setPreferredSize(new Dimension(80, 15));
    jLabel9.setText("  ");
    jLabel13.setText("(yyyy-mm-dd hh:mm:ss)");
    jLabel14.setText("(yyyy-mm-dd hh:mm:ss)");
    jPanel4.setBorder(null);
    jPanel9.setLayout(borderLayout5);
    jPanel9.setBorder(null);
    jPanel9.setMaximumSize(new Dimension(32767, 32767));
    jLabel15.setPreferredSize(new Dimension(2, 15));
    jLabel15.setText("  ");
    jLabel16.setPreferredSize(new Dimension(2, 15));
    jLabel16.setText("  ");
    jLabel17.setPreferredSize(new Dimension(3, 2));
    jLabel17.setText(" ");
    jLabel18.setPreferredSize(new Dimension(3, 2));
    jLabel18.setText(" ");
    jLabel19.setText("(separated by a comma)");
    jScrollPane1.getViewport().setBackground(Color.white);
    jLabel20.setText("  Number of orders:  ");
    txtNumberOfOrders.setBackground(UIManager.getColor("activeCaptionBorder"));
    txtNumberOfOrders.setPreferredSize(new Dimension(60, 21));

    jPanel0.setLayout(borderLayout7);
    jPanel0.setBorder(BorderFactory.createEtchedBorder());

    jPanel10.setDebugGraphicsOptions(0);
    jPanel10.setPreferredSize(new Dimension(10, 45));
    jPanel10.setRequestFocusEnabled(true);
    jPanel10.setLayout(borderLayout8);
    jPanel14.setBorder(null);
    jPanel14.setPreferredSize(new Dimension(300, 10));
    jPanel14.setLayout(gridBagLayout2);
    jLabel24.setText("    ");
    jPanel8.setBorder(null);
    jPanel7.setMinimumSize(new Dimension(262, 150));
    jLabel21.setPreferredSize(new Dimension(100, 21));
    jLabel21.setText("");
    jLabel22.setText("  ");
    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jPanel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel1.add(jPanel0, BorderLayout.CENTER);
    jPanel0.add(jPanel10, BorderLayout.NORTH);
    jPanel10.add(jPanel14, BorderLayout.WEST);
    jPanel14.add(jLabel20, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel14.add(jLabel24, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel14.add(txtNumberOfOrders, new GridBagConstraints(3, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel14.add(jLabel21, new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel10.add(jPanel15, BorderLayout.EAST);
    jPanel10.add(jPanel16, BorderLayout.CENTER);
    jPanel0.add(jPanel11, BorderLayout.WEST);
    jPanel0.add(jPanel12, BorderLayout.EAST);
    jPanel0.add(jPanel13, BorderLayout.SOUTH);
    jPanel0.add(jScrollPane1, BorderLayout.CENTER);

    jPanel3.add(jPanel4, BorderLayout.NORTH);
    jPanel3.add(jPanel6, BorderLayout.SOUTH);

    jPanel2.add(jPanel7, BorderLayout.NORTH);
    jPanel7.add(jLabel1,   new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel2,  new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(txtOrderId,   new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel3,  new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel4,   new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel5,  new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(txtStartDate,   new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel6,   new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(txtEndDate,   new GridBagConstraints(2, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel7,  new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel8,   new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel11,  new GridBagConstraints(0, 7, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(cbxOrderRole,   new GridBagConstraints(2, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel9,   new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel13,  new GridBagConstraints(5, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel14,  new GridBagConstraints(5, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel19,   new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel22, new GridBagConstraints(4, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel12, new GridBagConstraints(3, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(cbxOrderStatus, new GridBagConstraints(5, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jPanel9, BorderLayout.SOUTH);
    jPanel2.add(jPanel8, BorderLayout.CENTER);
    jPanel8.add(jLabel10,     new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel8.add(btnGetOrders,  new GridBagConstraints(1, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);

    ComboBoxModel dataModel = new DefaultComboBoxModel(ControlEntryTypes.orderStatuses);
    this.cbxOrderStatus.setModel(dataModel);
    this.cbxOrderStatus.setSelectedIndex(0);

    dataModel = new DefaultComboBoxModel(ControlEntryTypes.orderRoles);
    this.cbxOrderRole.setModel(dataModel);
    this.cbxOrderRole.setSelectedIndex(0);

    jPanel2.setPreferredSize(new Dimension(900, 220));
    jPanel3.setPreferredSize(new Dimension(900, 1));
    jPanel4.setPreferredSize(new Dimension(900, 1));
    jPanel6.setPreferredSize(new Dimension(900, 1));
    jPanel7.setPreferredSize(new Dimension(900, 170));
    jPanel8.setPreferredSize(new Dimension(900, 45));
    jPanel9.setPreferredSize(new Dimension(900, 1));

    this.setSize(new Dimension(900, 500));
  }

  void btnGetOrders_actionPerformed(ActionEvent e)
  {
    try {
      String ids = this.txtOrderId.getText().trim();
      if (ids.length() == 0) {
        throw new Exception("Please enter valid OrderIds.");
      }

      DetailLevelCodeType[] detailLevels = new DetailLevelCodeType[] {
          DetailLevelCodeType.ReturnAll,
          DetailLevelCodeType.ItemReturnAttributes,
          DetailLevelCodeType.ItemReturnDescription
      };

      GetOrdersCall api = new GetOrdersCall(this.apiContext);
      api.setDetailLevel(detailLevels);

      StringTokenizer st = new StringTokenizer(ids, ",");
      ArrayList lstOrders = new ArrayList();
      while (st.hasMoreTokens()) {
        lstOrders.add(st.nextToken());
      }

      int size = lstOrders.size();
      OrderIDType[] orderIds = new OrderIDType[size];
      for (int i = 0; i < size; i++) {
        orderIds[i] = new OrderIDType(lstOrders.get(i).toString().trim());
      }

      OrderIDArrayType oiat = new OrderIDArrayType();
      oiat.setOrderID(orderIds);
      api.setOrderIDArray(oiat);

      int idx = this.cbxOrderStatus.getSelectedIndex();
      OrderStatusCodeType status = (OrderStatusCodeType) ControlEntryTypes.orderStatuses[idx].Tag;
      api.setOrderStatus(status);

      idx = this.cbxOrderRole.getSelectedIndex();
      TradingRoleCodeType role = (TradingRoleCodeType) ControlEntryTypes.orderRoles[idx].Tag;
      api.setOrderRole(role);

      if (this.txtStartDate.getText().trim().length() > 0) {
        Calendar date = GuiUtil.getCalendarFromField(this.txtStartDate);
        api.setCreateTimeFrom(date);
      }

      if (this.txtEndDate.getText().trim().length() > 0) {
        Calendar date = GuiUtil.getCalendarFromField(this.txtEndDate);
        api.setCreateTimeTo(date);
      }

      OrderType[] orders = api.getOrders();
      displayOrders(orders);
    }
    catch (Exception ex) {
      ( (FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }

  void displayOrders(OrderType[] orders)
  {
    int size = orders != null ? orders.length : 0;
    this.txtNumberOfOrders.setText(new Integer(size).toString());

    String[] columnNames = {"OrderId", "NumberOfTrans", "TransPrice", "CreatedDate", "ShippingServiceSelected", "FinanceOfferId", "InsuranceWanted"};
    Object[] [] dataTable = new Object [size][7];
    for (int i = 0; i < size; i++) {
      OrderType order = orders[i];
      dataTable[i][0] = order.getOrderID().getValue();
      dataTable[i][1] = new Integer(order.getTransactionArray().getTransaction().length).toString();
      dataTable[i][2] = new Double(order.getTotal().getValue()).toString();
      dataTable[i][3] = eBayUtil.toAPITimeString(order.getCreatedTime().getTime());
      ShippingServiceOptionsType sso = order.getShippingServiceSelected();
      if (sso != null) {
        dataTable[i][4] = sso.getShippingService().toString();
      }
      dataTable[i][5] = order.getFinanceOfferID();
      ShippingDetailsType shippingDetails = order.getShippingDetails();
      Boolean insuranceWanted = shippingDetails.getInsuranceWanted();
      if (insuranceWanted != null) {
        dataTable[i][6] = insuranceWanted.toString();
      }
    }

    JTable jTable1 = new JTable(dataTable, columnNames);
    jTable1.setEnabled(false);
    this.jScrollPane1.getViewport().add(jTable1, null);
  }

}

class DialogGetOrders_btnGetOrders_actionAdapter implements java.awt.event.ActionListener {
  DialogGetOrders adaptee;

  DialogGetOrders_btnGetOrders_actionAdapter(DialogGetOrders adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnGetOrders_actionPerformed(e);
  }
}
