/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.util.Date;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: eBay Inc.</p>
 * @author not attributable
 * @version 1.0
 */

public class DialogAddDisputeResponse extends JDialog {
  private ApiContext apiContext = new ApiContext();

  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JPanel jPanel2 = new JPanel();
  JPanel jPanel4 = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField txtDisputeId = new JTextField();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  BorderLayout borderLayout3 = new BorderLayout();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTextPane txpMessage = new JTextPane();
  JComboBox cbxActivity = new JComboBox();

  static ControlTagItem[] activities = new ControlTagItem[] {
      new ControlTagItem(DisputeActivityCodeType.SellerAddInformation.toString(), DisputeActivityCodeType.SellerAddInformation),
      new ControlTagItem(DisputeActivityCodeType.SellerCompletedTransaction.toString(), DisputeActivityCodeType.SellerCompletedTransaction),
      new ControlTagItem(DisputeActivityCodeType.CameToAgreementNeedFVFCredit.toString(), DisputeActivityCodeType.CameToAgreementNeedFVFCredit),
      new ControlTagItem(DisputeActivityCodeType.SellerEndCommunication.toString(), DisputeActivityCodeType.SellerEndCommunication)
  };
  BorderLayout borderLayout5 = new BorderLayout();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel7 = new JPanel();
  JButton btnAddDisputeResponse = new JButton();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JTextField txtCallStatus = new JTextField();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JTextField txteBayTime = new JTextField();

  public DialogAddDisputeResponse(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogAddDisputeResponse() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    this.setModal(true);
    this.setTitle("eBay SDK for Java - AddDisputeResponse");

    this.setSize(new Dimension(350, 420));

    jPanel1.setLayout(borderLayout2);
    jPanel3.setLayout(borderLayout5);

    jPanel2.setLayout(gridBagLayout1);
    jLabel1.setText("DisputeID:");
    jLabel2.setText("          ");
    txtDisputeId.setPreferredSize(new Dimension(100, 21));
    jLabel4.setText("Activity:");
    jLabel5.setText("       ");
    jLabel3.setText("          ");
    jPanel4.setLayout(borderLayout3);
    jLabel9.setText("    MessageText:");
    jLabel10.setMaximumSize(new Dimension(12, 1));
    jLabel10.setMinimumSize(new Dimension(12, 1));
    jLabel10.setPreferredSize(new Dimension(12, 3));
    jLabel10.setIconTextGap(4);
    jLabel10.setText("    ");
    jLabel11.setText("  ");
    jLabel12.setText("  ");
    txpMessage.setText("");
    jPanel5.setMinimumSize(new Dimension(1, 1));
    jPanel5.setPreferredSize(new Dimension(1, 1));
    jPanel7.setBorder(BorderFactory.createEtchedBorder());
    jPanel7.setLayout(gridBagLayout2);
    btnAddDisputeResponse.setText("AddDisputeResponse");
    btnAddDisputeResponse.addActionListener(new DialogAddDisputeResponse_btnAddDisputeResponse_actionAdapter(this));
    jLabel6.setText("CallStatus:");
    jLabel7.setText("    ");
    jLabel8.setToolTipText("");
    jLabel8.setText("    ");
    txtCallStatus.setBackground(UIManager.getColor("Button.background"));
    txtCallStatus.setPreferredSize(new Dimension(80, 21));
    txtCallStatus.setText("");
    jLabel13.setText("    ");
    jLabel14.setText("eBayTime:");
    txteBayTime.setBackground(UIManager.getColor("Button.light"));
    txteBayTime.setPreferredSize(new Dimension(120, 21));
    txteBayTime.setText("");
    jPanel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(jPanel6, BorderLayout.NORTH);
    jPanel6.add(btnAddDisputeResponse, null);
    jPanel3.add(jPanel5, BorderLayout.SOUTH);
    jPanel3.add(jPanel7, BorderLayout.CENTER);
    jPanel2.add(jLabel1,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel2, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtDisputeId,  new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel3, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel4, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel5, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(cbxActivity,        new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 4, 0));
    jPanel1.add(jPanel4, BorderLayout.CENTER);
    jPanel4.add(jLabel9, BorderLayout.NORTH);
    jPanel4.add(jLabel10, BorderLayout.SOUTH);
    jPanel4.add(jLabel11, BorderLayout.WEST);
    jPanel4.add(jLabel12, BorderLayout.EAST);
    jPanel4.add(jScrollPane1, BorderLayout.CENTER);
    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jScrollPane1.getViewport().add(txpMessage, null);
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel7.add(jLabel6,   new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel7,    new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel8,    new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(txtCallStatus,     new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel13,   new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel14,   new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(txteBayTime,   new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

    ComboBoxModel dataModel = new DefaultComboBoxModel(DialogAddDisputeResponse.activities);
    this.cbxActivity.setModel(dataModel);
    this.cbxActivity.setSelectedIndex(0);

    jPanel2.setPreferredSize(new Dimension(300, 110));
    jPanel3.setPreferredSize(new Dimension(300, 130));
    jPanel4.setPreferredSize(new Dimension(300, 110));
    jPanel6.setPreferredSize(new Dimension(300, 35));
    jPanel7.setPreferredSize(new Dimension(300, 95));
    jPanel1.setPreferredSize(new Dimension(320, 370));
    this.setSize(new Dimension(320, 370));
    this.setResizable(false);
  }

  void btnAddDisputeResponse_actionPerformed(ActionEvent e) {
    try {
      String disputeId = this.txtDisputeId.getText().trim();
      if (disputeId.length() == 0) {
        throw new Exception("Please enter a DisputeId.");
      }

      int idx = this.cbxActivity.getSelectedIndex();
      ControlTagItem activity = DialogAddDisputeResponse.activities[idx];
      DisputeActivityCodeType dact = (DisputeActivityCodeType) activity.Tag;

      AddDisputeResponseCall api = new AddDisputeResponseCall(this.apiContext);
      api.setDisputeID(new DisputeIDType(disputeId));
      api.setMessageText(this.txpMessage.getText());
      api.setDisputeActivity(dact);
      AddDisputeResponseResponseType resp = api.addDisputeResponse();

      this.txtCallStatus.setText(resp.getAck().getValue().toString());
    }
    catch(Exception ex) {
      this.txteBayTime.setText(eBayUtil.toAPITimeString(new Date()));
      this.txtCallStatus.setText("Failure");
      ( (FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }
}

class DialogAddDisputeResponse_btnAddDisputeResponse_actionAdapter implements java.awt.event.ActionListener {
  DialogAddDisputeResponse adaptee;

  DialogAddDisputeResponse_btnAddDisputeResponse_actionAdapter(DialogAddDisputeResponse adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnAddDisputeResponse_actionPerformed(e);
  }
}
