/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
//import com.ebay.sdk.util.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: eBay Inc.</p>
 * @author not attributable
 * @version 1.0
 */

public class DialogAddDispute extends JDialog {
  private ApiContext apiContext = new ApiContext();

  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField txtItemId = new JTextField();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JTextField txtTransactionId = new JTextField();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JButton btnAddDispute = new JButton();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel18 = new JLabel();
  JComboBox cbxReason = new JComboBox();
  JComboBox cbxExplaination = new JComboBox();

  static ControlTagItem[] reasons = new ControlTagItem[] {
      new ControlTagItem(DisputeReasonCodeType.BuyerHasNotPaid.toString(), DisputeReasonCodeType.BuyerHasNotPaid),
      new ControlTagItem(DisputeReasonCodeType.TransactionMutuallyCanceled.toString(), DisputeReasonCodeType.TransactionMutuallyCanceled)
  };

  static ControlTagItem[] explanations = new ControlTagItem[] {
      new ControlTagItem(DisputeExplanationCodeType.BuyerHasNotResponded.toString(), DisputeExplanationCodeType.BuyerHasNotResponded),
      new ControlTagItem(DisputeExplanationCodeType.BuyerRefusedToPay.toString(), DisputeExplanationCodeType.BuyerRefusedToPay),
      new ControlTagItem(DisputeExplanationCodeType.BuyerReturnedItemForRefund.toString(), DisputeExplanationCodeType.BuyerReturnedItemForRefund),
      new ControlTagItem(DisputeExplanationCodeType.UnableToResolveTerms.toString(), DisputeExplanationCodeType.UnableToResolveTerms),
      new ControlTagItem(DisputeExplanationCodeType.BuyerPurchasingMistake.toString(), DisputeExplanationCodeType.BuyerPurchasingMistake),
      new ControlTagItem(DisputeExplanationCodeType.ShipCountryNotSupported.toString(), DisputeExplanationCodeType.ShipCountryNotSupported),
      new ControlTagItem(DisputeExplanationCodeType.ShippingAddressNotConfirmed.toString(), DisputeExplanationCodeType.ShippingAddressNotConfirmed),
      new ControlTagItem(DisputeExplanationCodeType.PaymentMethodNotSupported.toString(), DisputeExplanationCodeType.PaymentMethodNotSupported),
      new ControlTagItem(DisputeExplanationCodeType.BuyerNoLongerRegistered.toString(), DisputeExplanationCodeType.BuyerNoLongerRegistered),
      new ControlTagItem(DisputeExplanationCodeType.OtherExplanation.toString(),DisputeExplanationCodeType.OtherExplanation)
  };
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JLabel jLabel19 = new JLabel();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel20 = new JLabel();
  JLabel jLabel21 = new JLabel();
  JTextField txtDisputeId = new JTextField();

  public DialogAddDispute(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogAddDispute() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    this.setModal(true);
    this.setTitle("eBay SDK for Java - AddDispute");

    this.setSize(new Dimension(350, 420));

    jPanel1.setLayout(borderLayout2);
    jPanel2.setLayout(gridBagLayout1);
    jLabel1.setRequestFocusEnabled(true);
    jLabel1.setHorizontalAlignment(SwingConstants.LEADING);
    jLabel1.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel1.setText("ItemID:");
    jLabel3.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel3.setText("TransactionID:");
    jLabel5.setFont(new java.awt.Font("MS Sans Serif", 0, 11));
    jLabel5.setHorizontalAlignment(SwingConstants.LEADING);
    jLabel5.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel5.setText("Reason:");
    jLabel6.setRequestFocusEnabled(true);
    jLabel6.setText("          ");
    jLabel7.setText("");
    jLabel2.setText("");
    jLabel4.setText("");
    jLabel8.setText("   ");
    jLabel9.setText("   ");
    jLabel10.setText("   ");
    jPanel3.setLayout(borderLayout3);

    jLabel11.setText("  ");
    jLabel12.setText("  ");
    jLabel14.setText("");
    jLabel13.setText("  ");
    jLabel15.setText("     ");
    btnAddDispute.setText("AddDispute");
    btnAddDispute.addActionListener(new DialogAddDispute_btnAddDispute_actionAdapter(this));
    jLabel16.setText("      ");
    jLabel17.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel17.setText(" Explanation:");
    jLabel18.setText("    ");
    jLabel19.setText("    ");
    jPanel6.setLayout(gridBagLayout2);
    jLabel20.setBorder(null);
    jLabel20.setText("DisputeID:");
    jLabel21.setText("          ");
    txtDisputeId.setBackground(Color.lightGray);
    txtDisputeId.setMinimumSize(new Dimension(157, 21));
    txtDisputeId.setPreferredSize(new Dimension(157, 21));
    txtDisputeId.setRequestFocusEnabled(true);
    jPanel4.setBorder(null);
    jPanel6.setBorder(BorderFactory.createEtchedBorder());
    jPanel5.setMinimumSize(new Dimension(10, 1));
    jPanel5.setPreferredSize(new Dimension(10, 1));
    txtItemId.setPreferredSize(new Dimension(80, 21));
    txtTransactionId.setPreferredSize(new Dimension(80, 21));
    jPanel2.add(jLabel2,     new GridBagConstraints(2, 1, 3, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel4,     new GridBagConstraints(4, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel6,     new GridBagConstraints(4, 5, 1, 3, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel7,     new GridBagConstraints(0, 8, 5, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel8,     new GridBagConstraints(0, 9, 3, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel9,     new GridBagConstraints(4, 9, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel10,     new GridBagConstraints(5, 9, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel11,     new GridBagConstraints(0, 2, 2, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel12,     new GridBagConstraints(5, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel13,     new GridBagConstraints(0, 5, 2, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel14,     new GridBagConstraints(5, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel15,     new GridBagConstraints(3, 9, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel1,      new GridBagConstraints(1, 1, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtItemId,      new GridBagConstraints(5, 1, 2, 2, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 51, 0));
    jPanel2.add(txtTransactionId,      new GridBagConstraints(5, 4, 3, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(-5, 0, 5, 0), 51, 0));
    jPanel2.add(jLabel3,          new GridBagConstraints(1, 4, 3, 1, 0.0, 0.0
            ,GridBagConstraints.NORTH, GridBagConstraints.NONE, new Insets(-5, -6, 5, 0), 0, 0));
    jPanel2.add(jLabel5,        new GridBagConstraints(1, 7, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 7, 0, 0), 0, 0));
    jPanel2.add(jLabel17,        new GridBagConstraints(1, 11, 3, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 20, 0));
    jPanel2.add(jLabel18,    new GridBagConstraints(1, 12, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(cbxReason,    new GridBagConstraints(5, 7, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(cbxExplaination,   new GridBagConstraints(5, 11, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel16,  new GridBagConstraints(0, 11, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel19, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel1.add(jPanel3, BorderLayout.SOUTH);

    jPanel3.add(jPanel4, BorderLayout.NORTH);
    jPanel4.add(btnAddDispute, null);
    jPanel3.add(jPanel5, BorderLayout.SOUTH);
    jPanel3.add(jPanel6, BorderLayout.CENTER);
    jPanel6.add(jLabel20,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel21, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(txtDisputeId, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

    jPanel1.add(jPanel2, BorderLayout.NORTH);
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);

    ComboBoxModel dataModel = new DefaultComboBoxModel(DialogAddDispute.reasons);
    this.cbxReason.setModel(dataModel);
    this.cbxReason.setSelectedIndex(0);

    dataModel = new DefaultComboBoxModel(DialogAddDispute.explanations);
    this.cbxExplaination.setModel(dataModel);
    this.cbxExplaination.setSelectedIndex(0);

    jPanel2.setPreferredSize(new Dimension(320, 160));
    jPanel3.setPreferredSize(new Dimension(320, 85));
    jPanel4.setPreferredSize(new Dimension(320, 35));
    jPanel6.setPreferredSize(new Dimension(320, 50));
    this.setSize(new Dimension(320, 245));
    this.setResizable(false);
  }

  void btnAddDispute_actionPerformed(ActionEvent e)
  {
    try {
      this.txtDisputeId.setText(" ");

      String itemId = this.txtItemId.getText().trim();
      String transactionId = this.txtTransactionId.getText().trim();

      if ( itemId.length() == 0 && transactionId.length() == 0) {
        throw new Exception("Please enter either an ItemId or TransactionId.");
      }

      int idx = this.cbxReason.getSelectedIndex();
      ControlTagItem reason = DialogAddDispute.reasons[idx];
      DisputeReasonCodeType drct = (DisputeReasonCodeType) reason.Tag;
      idx = this.cbxExplaination.getSelectedIndex();
      ControlTagItem explanation = DialogAddDispute.explanations[idx];
      DisputeExplanationCodeType dect = (DisputeExplanationCodeType) explanation.Tag;

      DetailLevelCodeType[] detailLevels = new DetailLevelCodeType[] {
          DetailLevelCodeType.ReturnAll,
          DetailLevelCodeType.ItemReturnAttributes,
          DetailLevelCodeType.ItemReturnDescription
      };

      AddDisputeCall api = new AddDisputeCall(this.apiContext);
      api.setDetailLevel(detailLevels);
      api.setItemID(new ItemIDType(itemId));
      api.setTransactionID(transactionId);
      api.setDisputeExplanation(dect);
      api.setDisputeReason(drct);

      DisputeIDType id = api.addDispute();

      this.txtDisputeId.setText(id.getValue());
    }
    catch (Exception ex) {
      ((FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }
}

class DialogAddDispute_btnAddDispute_actionAdapter implements java.awt.event.ActionListener {
  DialogAddDispute adaptee;

  DialogAddDispute_btnAddDispute_actionAdapter(DialogAddDispute adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnAddDispute_actionPerformed(e);
  }
}
