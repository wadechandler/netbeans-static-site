/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;

public class DialogAddSecondChanceItem extends JDialog {
  private ApiContext apiContext = new ApiContext();

  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JPanel jPanelOriginalItemID = new JPanel();
  JPanel jPanelBINPrice = new JPanel();
  JPanel jPanelCopyEmailToSeller = new JPanel();
  JPanel jPanelDuration = new JPanel();
  JPanel jPanelRecipientBidderUserID = new JPanel();
  JTextField txtOriginalItemId = new JTextField();
  JLabel jLabel1 = new JLabel();
  JTextField txtRecipientBidderUserId = new JTextField();
  JLabel jLabel2 = new JLabel();
  JComboBox comboDuration = new JComboBox();
  JLabel jLabel4 = new JLabel();
  JCheckBox cbxCopyEmailToSeller = new JCheckBox();
  JTextField txtBINPrice = new JTextField();
  JLabel jLabel5 = new JLabel();
  JButton btnAddSecondChangeIcen = new JButton();
  GridLayout gridLayout2 = new GridLayout();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel8 = new JPanel();
  JPanel jPanel9 = new JPanel();
  JTextField txtItemID = new JTextField();
  JLabel jLabel6 = new JLabel();
  JTextField txtListingFee = new JTextField();
  JLabel jLabel7 = new JLabel();
  JTextField txtStartTime = new JTextField();
  JLabel jLabel8 = new JLabel();
  JTextField txtEndTime = new JTextField();
  JLabel jLabel9 = new JLabel();
  JButton btnVerifyAddSecondChanceItem = new JButton();

  public DialogAddSecondChanceItem(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();

      //
      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();

      // Initialize combo box.
      Object[] list = new Object[] {
          new ControlTagItem("1 Day", ListingDurationCodeType.Days_1),
          new ControlTagItem("3 Days", ListingDurationCodeType.Days_3),
          new ControlTagItem("5 Days", ListingDurationCodeType.Days_5),
          new ControlTagItem("7 Days", ListingDurationCodeType.Days_7),
      };
      ComboBoxModel dataModel = new DefaultComboBoxModel(list);
      this.comboDuration.setModel(dataModel);
      this.comboDuration.setSelectedIndex(2);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogAddSecondChanceItem() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jPanel4.setLayout(gridLayout1);
    gridLayout1.setColumns(2);
    gridLayout1.setRows(3);
    jLabel1.setText("OriginalItemID:");
    txtOriginalItemId.setPreferredSize(new Dimension(80, 21));
    txtOriginalItemId.setText("");
    jLabel2.setToolTipText("");
    jLabel2.setText("RecipientBidderUserID:");
    txtRecipientBidderUserId.setPreferredSize(new Dimension(80, 21));
    txtRecipientBidderUserId.setText("");
    jLabel4.setText("Duration:");
    cbxCopyEmailToSeller.setText("Copy email to seller");
    jLabel5.setText("BuyItNow price:");
    txtBINPrice.setPreferredSize(new Dimension(60, 21));
    txtBINPrice.setText("");
    btnAddSecondChangeIcen.setText("AddSecondChanceItem");
    btnAddSecondChangeIcen.addActionListener(new DialogAddSecondChanceItem_btnAddSecondChangeIcen_actionAdapter(this));
    jPanel2.setLayout(gridLayout2);
    gridLayout2.setColumns(2);
    gridLayout2.setRows(2);
    jLabel6.setPreferredSize(new Dimension(60, 15));
    jLabel6.setText("ItemID:");
    txtItemID.setPreferredSize(new Dimension(60, 21));
    txtItemID.setEditable(false);
    txtItemID.setText("");
    jLabel7.setMinimumSize(new Dimension(55, 15));
    jLabel7.setPreferredSize(new Dimension(60, 15));
    jLabel7.setText("Listing Fee:");
    txtListingFee.setMaximumSize(new Dimension(2147483647, 2147483647));
    txtListingFee.setMinimumSize(new Dimension(6, 21));
    txtListingFee.setPreferredSize(new Dimension(60, 21));
    txtListingFee.setEditable(false);
    txtListingFee.setSelectionStart(4);
    jLabel8.setPreferredSize(new Dimension(60, 15));
    jLabel8.setText("StartTime:");
    txtStartTime.setPreferredSize(new Dimension(60, 21));
    txtStartTime.setEditable(false);
    txtStartTime.setText("");
    jLabel9.setPreferredSize(new Dimension(60, 15));
    jLabel9.setText("EndTime:");
    txtEndTime.setPreferredSize(new Dimension(60, 21));
    txtEndTime.setEditable(false);
    txtEndTime.setText("");
    btnVerifyAddSecondChanceItem.setText("VerifyAddSecondChanceItem");
    btnVerifyAddSecondChanceItem.addActionListener(new DialogAddSecondChanceItem_btnVerifyAddSecondChanceItem_actionAdapter(this));
    getContentPane().add(panel1);
    panel1.add(jPanel1,  BorderLayout.NORTH);
    jPanel1.add(jPanel4,  BorderLayout.NORTH);
    jPanel4.add(jPanelOriginalItemID, null);
    jPanelOriginalItemID.add(jLabel1, null);
    jPanelOriginalItemID.add(txtOriginalItemId, null);
    jPanel4.add(jPanelRecipientBidderUserID, null);
    jPanelRecipientBidderUserID.add(jLabel2, null);
    jPanelRecipientBidderUserID.add(txtRecipientBidderUserId, null);
    jPanel4.add(jPanelDuration, null);
    jPanelDuration.add(jLabel4, null);
    jPanelDuration.add(comboDuration, null);
    jPanel4.add(jPanelCopyEmailToSeller, null);
    jPanelCopyEmailToSeller.add(cbxCopyEmailToSeller, null);
    jPanel4.add(jPanelBINPrice, null);
    jPanelBINPrice.add(jLabel5, null);
    jPanelBINPrice.add(txtBINPrice, null);
    jPanel1.add(jPanel5, BorderLayout.CENTER);
    jPanel5.add(btnAddSecondChangeIcen, null);
    jPanel5.add(btnVerifyAddSecondChanceItem, null);
    panel1.add(jPanel2,  BorderLayout.CENTER);
    jPanel2.add(jPanel6, null);
    jPanel6.add(jLabel6, null);
    jPanel6.add(txtItemID, null);
    jPanel2.add(jPanel9, null);
    jPanel9.add(jLabel7, null);
    jPanel9.add(txtListingFee, null);
    jPanel2.add(jPanel8, null);
    jPanel8.add(jLabel8, null);
    jPanel8.add(txtStartTime, null);
    jPanel2.add(jPanel7, null);
    jPanel7.add(jLabel9, null);
    jPanel7.add(txtEndTime, null);
    panel1.add(jPanel3, BorderLayout.SOUTH);
  }

  void internalAddSecondChanceItem(boolean isVerify)
  {
    try
    {
      GuiUtil.isTextControlFilled(this.txtOriginalItemId, "Please enter OriginalItemId");
      GuiUtil.isTextControlFilled(this.txtRecipientBidderUserId, "Please enter RecipientBidderUserId");

      AddSecondChanceItemCall api = new AddSecondChanceItemCall(this.apiContext);

      ControlTagItem ct = (ControlTagItem)this.comboDuration.getSelectedItem();

      api.setCopyEmailToSeller(this.cbxCopyEmailToSeller.isSelected());
      api.setRecipientBidderUserID(new UserIDType(this.txtRecipientBidderUserId.getText()));

      ItemType item = new ItemType();
      item.setListingDuration((ListingDurationCodeType)ct.Tag);
      item.setItemID(new ItemIDType(this.txtOriginalItemId.getText()));

      if( txtBINPrice.getText().length() != 0 )
      {
        double bp = Double.parseDouble(this.txtBINPrice.getText());
        item.setBuyItNowPrice(new AmountType(bp));
      }

      api.setItem(item);

      // Executes the API.
      FeesType fees = isVerify ? api.verifyAddSecondChanceItem() : api.addSecondChanceItem();

      // Display results.
      this.txtItemID.setText(isVerify ? "" : item.getItemID().toString());

      FeeType ft = eBayUtil.findFeeByName(fees.getFee(), "ListingFee");
      this.txtListingFee.setText(new Double(ft.getFee().getValue()).toString());

      ListingDetailsType ld = item.getListingDetails();
      this.txtStartTime.setText(eBayUtil.toAPITimeString(ld.getStartTime().getTime()));
      this.txtEndTime.setText(eBayUtil.toAPITimeString(ld.getEndTime().getTime()));
    }
    catch(Exception ex)
    {
      String msg = ex.getClass().getName() + " : " + ex.getMessage();
      ((FrameDemo)this.getParent()).showErrorMessage(msg);
    }
  }

  void btnAddSecondChangeItem_actionPerformed(ActionEvent e) {
    internalAddSecondChanceItem(false);
  }

  void btnVerifyAddSecondChanceItem_actionPerformed(ActionEvent e) {
    internalAddSecondChanceItem(true);
  }
}

class DialogAddSecondChanceItem_btnAddSecondChangeIcen_actionAdapter implements java.awt.event.ActionListener {
  DialogAddSecondChanceItem adaptee;

  DialogAddSecondChanceItem_btnAddSecondChangeIcen_actionAdapter(DialogAddSecondChanceItem adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnAddSecondChangeItem_actionPerformed(e);
  }
}

class DialogAddSecondChanceItem_btnVerifyAddSecondChanceItem_actionAdapter implements java.awt.event.ActionListener {
  DialogAddSecondChanceItem adaptee;

  DialogAddSecondChanceItem_btnVerifyAddSecondChanceItem_actionAdapter(DialogAddSecondChanceItem adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnVerifyAddSecondChanceItem_actionPerformed(e);
  }
}
