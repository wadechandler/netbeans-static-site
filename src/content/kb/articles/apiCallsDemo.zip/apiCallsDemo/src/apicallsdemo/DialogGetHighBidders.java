/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.soap.eBLBaseComponents.*;

public class DialogGetHighBidders extends JDialog {
  private ApiContext apiContext = new ApiContext();

  final static int totalColumns = 9;
  final String[] colNames = new String[] {
      "Action", "User", "Currency", "MaxBid", "Quantity", "BidTime", "HighestBid", "SecondChanceEnabled", "TransactionID"
  };

  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();

  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();

  JPanel jPanel11 = new JPanel();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel13 = new JPanel();
  JPanel jPanel14 = new JPanel();

  JTextField txtItemID = new JTextField();
  JLabel jLabel1 = new JLabel();
  JButton btnGetHighBidders = new JButton();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable tblHighBidders = new JTable();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel2 = new JLabel();

  public DialogGetHighBidders(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetHighBidders() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jPanel2.setLayout(borderLayout3);

    jLabel1.setText("Item ID");
    txtItemID.setPreferredSize(new Dimension(100, 21));
    txtItemID.setText("");
    btnGetHighBidders.setText("GetHighBidders");
    btnGetHighBidders.addActionListener(new DialogGetHighBidders_btnGetHighBidders_actionAdapter(this));
    jPanel11.setMinimumSize(new Dimension(10, 20));
    jPanel5.setPreferredSize(new Dimension(163, 50));
    jPanel5.setLayout(gridBagLayout1);
    jLabel2.setText("        ");
    jPanel4.setPreferredSize(new Dimension(119, 45));
    jScrollPane1.getViewport().setBackground(Color.white);
    getContentPane().add(panel1);
    panel1.add(jPanel1,  BorderLayout.NORTH);
    jPanel1.add(jPanel5,  BorderLayout.NORTH);
    jPanel5.add(txtItemID,   new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel2,  new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel1.add(jPanel4, BorderLayout.CENTER);
    panel1.add(jPanel2,  BorderLayout.CENTER);
    jPanel2.add(jPanel11, BorderLayout.NORTH);
    jPanel2.add(jPanel12, BorderLayout.SOUTH);
    jPanel2.add(jPanel13, BorderLayout.WEST);
    jPanel2.add(jPanel14, BorderLayout.EAST);
    jPanel2.add(jScrollPane1, BorderLayout.CENTER);
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jScrollPane1.getViewport().add(tblHighBidders, null);
    panel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel4.add(btnGetHighBidders, null);

    this.setSize(new Dimension(800, 400));
  }

  static String[] offerTypeToColumns(OfferType ot)
  {
    String[] cols = new String[totalColumns];
    int i = 0;
    cols[i++] = ot.getAction() != null ? ot.getAction().toString() : "";
    cols[i++] = ot.getUser() != null ? ot.getUser().getUserID().getValue() : "";
    cols[i++] = ot.getCurrency() != null ? ot.getCurrency().toString() : "";
    cols[i++] = ot.getMaxBid() != null ? (new Double(ot.getMaxBid().getValue()).toString()) : "";
    cols[i++] = ot.getQuantity().toString();
    cols[i++] = ot.getTimeBid() != null ? eBayUtil.toAPITimeString(ot.getTimeBid().getTime()) : "";
    cols[i++] = ot.getHighestBid() != null ? (new Double(ot.getHighestBid().getValue()).toString()) : "";
    cols[i++] = ot.getSecondChanceEnabled() != null ? ot.getSecondChanceEnabled().toString() : "";
    cols[i++] = ot.getTransactionID();

    return cols;
  }

  void btnGetHighBidders_actionPerformed(ActionEvent e) {
    try
    {
      GetHighBiddersCall api = new GetHighBiddersCall(this.apiContext);

      String itemID = this.txtItemID.getText();
      if( itemID.length() == 0 )
        throw new SdkException("Please enter the item ID.");

      api.setItemID(new ItemIDType(itemID));

      final OfferType[] offers = api.getHighBidders();

      // Display items in table.
      TableModel dataModel = new AbstractTableModel() {
        public int getColumnCount() { return totalColumns; }
        public int getRowCount() { return offers == null ? 0 : offers.length;}
        public String getColumnName(int columnIndex){
          return colNames[columnIndex];
        }
        public Object getValueAt(int row, int col)
        {
          OfferType ot = offers[row];
          return offerTypeToColumns(ot)[col];
        }
      };

      this.tblHighBidders.setModel(dataModel);
    }
    catch(Exception ex)
    {
      String msg = ex.getClass().getName() + " : " + ex.getMessage();
      ((FrameDemo)this.getParent()).showErrorMessage(msg);
    }
  }
}

class DialogGetHighBidders_btnGetHighBidders_actionAdapter implements java.awt.event.ActionListener {
  DialogGetHighBidders adaptee;

  DialogGetHighBidders_btnGetHighBidders_actionAdapter(DialogGetHighBidders adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnGetHighBidders_actionPerformed(e);
  }
}
