/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;
import com.ebay.sdk.helper.*;

public class DialogGetCategoryListings extends JDialog {
  private ApiContext apiContext = new ApiContext();
  private SiteCodeType siteId = SiteCodeType.US;
  final static int totalColumns = 7;
  final String[] colNames = new String[] {
    "ItemID", "StartTime", "Price", "QuantitySold", "BidCount", "TimeLeft", "Border"};

  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();

  JPanel panel1 = new JPanel();

  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JTextField txtCategoryID = new JTextField();
  JLabel jLabel1 = new JLabel();
  JButton btnGetCategoryListings = new JButton();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JTextField txtEntriesPerPage = new JTextField();
  JTextField txtPageNumber = new JTextField();
  JComboBox cbxItemType = new JComboBox();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable tblCategories = new JTable();
  JPanel jPanel11 = new JPanel();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel13 = new JPanel();
  JPanel jPanel14 = new JPanel();
  JPanel jPanel15 = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JComboBox cbxListingOrder = new JComboBox();
  JLabel jLabel13 = new JLabel();
  JComboBox cbxSearchLocation = new JComboBox();
  JLabel jLabel12 = new JLabel();
  JComboBox cbxSite = new JComboBox();
  JLabel jLabel14 = new JLabel();

  public DialogGetCategoryListings(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      customInit();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetCategoryListings() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    txtCategoryID.setPreferredSize(new Dimension(80, 21));
    txtCategoryID.setText("67088");
    jLabel1.setText("Category ID:");
    btnGetCategoryListings.setText("GetCategoryListings");
    btnGetCategoryListings.addActionListener(new DialogGetCategoryListings_btnGetCategoryListings_actionAdapter(this));
    jPanel5.setLayout(gridBagLayout2);
    txtEntriesPerPage.setPreferredSize(new Dimension(80, 21));
    txtEntriesPerPage.setText("100");
    txtPageNumber.setPreferredSize(new Dimension(80, 21));
    txtPageNumber.setText("0");
    jPanel6.setPreferredSize(new Dimension(143, 40));
    jPanel6.setLayout(gridBagLayout1);
    jPanel5.setOpaque(true);
    jPanel5.setPreferredSize(new Dimension(10, 160));
    jLabel2.setText("        ");
    jLabel3.setPreferredSize(new Dimension(60, 15));
    jLabel3.setText(" ");
    jLabel6.setText("ItemType:");
    jLabel7.setText("        ");
    jLabel8.setText("    ");
    jLabel9.setText("PageNumber:");
    jLabel10.setText("Page size:");
    jScrollPane1.getViewport().setBackground(Color.white);
    jLabel4.setText("    ");
    jLabel5.setText("    ");
    jLabel11.setText("ListingOrder:");
    jLabel13.setText("SearchLocation:");
    jLabel12.setText("Site:");
    jLabel14.setText("    ");
    cbxSite.addActionListener(new DialogGetCategoryListings_cbxSite_actionAdapter(this));
    getContentPane().add(panel1);
    panel1.add(jPanel1,  BorderLayout.NORTH);
    jPanel1.add(jPanel6, BorderLayout.SOUTH);
    jPanel6.add(btnGetCategoryListings,       new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel1.add(jPanel5, BorderLayout.CENTER);
    jPanel5.add(jLabel2,        new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel3,      new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel7,      new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel8,      new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel4,     new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel5,    new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

    panel1.add(jPanel2, BorderLayout.CENTER);
    jPanel2.setLayout(borderLayout3);
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.add(jPanel11, BorderLayout.NORTH);
    jPanel2.add(jPanel12, BorderLayout.SOUTH);
    jPanel2.add(jPanel13, BorderLayout.WEST);
    jPanel2.add(jPanel14, BorderLayout.EAST);
    jPanel2.add(jScrollPane1, BorderLayout.CENTER);

    jScrollPane1.getViewport().add(tblCategories, null);
    panel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel5.add(txtEntriesPerPage,  new GridBagConstraints(6, 7, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel10,  new GridBagConstraints(4, 7, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(txtPageNumber,  new GridBagConstraints(2, 7, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel9,  new GridBagConstraints(0, 7, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(cbxListingOrder,  new GridBagConstraints(6, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel11,  new GridBagConstraints(4, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(cbxItemType,  new GridBagConstraints(6, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel6,  new GridBagConstraints(4, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(cbxSearchLocation,  new GridBagConstraints(2, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel13,  new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(txtCategoryID,  new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel1,  new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel12,    new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(cbxSite,    new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel14,  new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

    jPanel1.setPreferredSize(new Dimension(800, 200));
    this.setSize(new Dimension(800, 500));
  }

  static String[] itemToColumns(ItemType item)
  {
    String[] cols = new String[DialogGetCategoryListings.totalColumns];
    int i = 0;
    cols[i++] = item.getItemID().toString();

    ListingDetailsType dtl = item.getListingDetails();

    cols[i++] = eBayUtil.toAPITimeString(dtl.getStartTime().getTime());

    cols[i++] = (new Double(item.getSellingStatus().getCurrentPrice().getValue())).toString();
    Integer qs = item.getSellingStatus().getQuantitySold();
    cols[i++] = (qs == null) ? "" : qs.toString();
    cols[i++] = item.getSellingStatus().getBidCount().toString();

    org.apache.axis.types.Duration tl = item.getTimeLeft();
    if (tl != null) {
      cols[i] = java.text.MessageFormat.format("{0} days {1} hours",
                                                 new Object[] {new Integer(tl.
          getDays()), new Integer(tl.getHours())});
    }
    i++;

    ListingEnhancementsCodeType [] enhancements = item.getListingEnhancement();
    int size = enhancements != null ? enhancements.length : 0;
    for (int j = 0; j < size; j++) {
      if (enhancements[j] == ListingEnhancementsCodeType.Border) {
        cols[i] = "yes";
      }
    }

    return cols;
  }

  void btnGetCategoryListings_actionPerformed(ActionEvent e) {
    try
    {
      String catId = this.txtCategoryID.getText().trim();
      if (catId.length() == 0) {
        throw new Exception("Please enter CategoryID first.");

      }

      this.apiContext.setSite(this.siteId);

      GetCategoryListingsCall api = new GetCategoryListingsCall(this.apiContext);
      api.setCategoryID(catId);

      if (this.cbxSearchLocation.getSelectedIndex() > 0) {
        ControlTagItem cti = (ControlTagItem)this.cbxSearchLocation.
            getSelectedItem();

        if (cti != null) {
          SearchLocationType searchLocation = new SearchLocationType();
          searchLocation.setRegionID(cti.Tag.toString());
          api.setSearchLocation(searchLocation);
        }
      }

      ControlTagItem itemType = (ControlTagItem)this.cbxItemType.getSelectedItem();
      api.setItemTypeFilter((ItemTypeFilterCodeType)itemType.Tag);

      itemType = (ControlTagItem)this.cbxListingOrder.getSelectedItem();
      api.setOrderBy((CategoryListingsOrderCodeType)itemType.Tag);

      PaginationType pagination = new PaginationType();
      String pageNumber = this.txtPageNumber.getText().trim();
      if (pageNumber.length() > 0) {
        pagination.setPageNumber(new Integer(pageNumber));
      }
      String entriesPerPage = this.txtEntriesPerPage.getText().trim();
      if (entriesPerPage.length() > 0) {
        pagination.setEntriesPerPage(new Integer(entriesPerPage));
      }
      api.setPagination(pagination);

      final ItemType[] items = api.getCategoryListings();

      TableModel dataModel = new AbstractTableModel() {
        public int getColumnCount() {
          return totalColumns;
        }

        public int getRowCount() {
          return items != null ? items.length : 0;
        }

        public String getColumnName(int columnIndex) {
          return colNames[columnIndex];
        }

        public Object getValueAt(int row, int col) {
          ItemType item = items[row];
          return itemToColumns(item)[col];
        }
      };

      this.tblCategories.setModel(dataModel);
    }
    catch (Exception ex) {
      ( (FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }

  void customInit()
  {
    initStaticControls();
    initServiceControls(SiteCodeType.US);
  }

  void initStaticControls()
  {
    DefaultComboBoxModel dataModel = new DefaultComboBoxModel(ControlEntryTypes.sites);
    this.cbxSite.setModel(dataModel);
    this.cbxSite.setSelectedIndex(0);

    dataModel = new DefaultComboBoxModel(ControlEntryTypes.itemTypes);
    this.cbxItemType.setModel(dataModel);
    this.cbxItemType.setSelectedIndex(0);

    dataModel = new DefaultComboBoxModel(ControlEntryTypes.listingOrders);
    this.cbxListingOrder.setModel(dataModel);
    this.cbxListingOrder.setSelectedIndex(0);
  }

  void initServiceControls(SiteCodeType siteId)
  {
    initRegionServices(siteId);
  }

  void initRegionServices(SiteCodeType siteId)
  {
    ServiceControlManager manager = ServiceControlManager.getInstance();
    ControlTagItem[] regions = manager.createRegionServiceControl(siteId, true);
    DefaultComboBoxModel dataModel = new DefaultComboBoxModel(regions);
    this.cbxSearchLocation.setModel(dataModel);
    this.cbxSearchLocation.setSelectedIndex(0);
  }

  void cbxSite_actionPerformed(ActionEvent e) {
    SiteCodeType siteId = (SiteCodeType) ((ControlTagItem)this.cbxSite.getSelectedItem()).Tag;
    if (!this.siteId.equals(siteId)) {
      this.siteId = siteId;
      initRegionServices(this.siteId);
    }
  }
}

class DialogGetCategoryListings_btnGetCategoryListings_actionAdapter implements java.awt.event.ActionListener {
  DialogGetCategoryListings adaptee;

  DialogGetCategoryListings_btnGetCategoryListings_actionAdapter(DialogGetCategoryListings adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnGetCategoryListings_actionPerformed(e);
  }
}

class DialogGetCategoryListings_cbxSite_actionAdapter implements java.awt.event.ActionListener {
  DialogGetCategoryListings adaptee;

  DialogGetCategoryListings_cbxSite_actionAdapter(DialogGetCategoryListings adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.cbxSite_actionPerformed(e);
  }
}
