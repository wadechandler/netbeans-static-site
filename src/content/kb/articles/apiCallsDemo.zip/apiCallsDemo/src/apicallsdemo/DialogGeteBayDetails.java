package apicallsdemo;

public class DialogGeteBayDetails {
  public DialogGeteBayDetails() {
  }
}