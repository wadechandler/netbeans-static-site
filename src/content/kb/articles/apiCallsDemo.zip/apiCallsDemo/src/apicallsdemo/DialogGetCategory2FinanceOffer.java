/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.util.Calendar;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.event.*;
import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: eBay Inc.</p>
 * @author not attributable
 * @version 1.0
 */

public class DialogGetCategory2FinanceOffer extends JDialog
{
  private ApiContext apiContext = new ApiContext();

  BorderLayout borderLayout1 = new BorderLayout();

  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel7 = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JButton btnGetCategory2FinanceOffer = new JButton();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField txtCategoryId = new JTextField();
  JLabel jLabel3 = new JLabel();
  JTextField txtLastModifiedDate = new JTextField();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel8 = new JPanel();
  JPanel jPanel9 = new JPanel();
  JPanel jPanel10 = new JPanel();
  JPanel jPanel11 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  BorderLayout borderLayout5 = new BorderLayout();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel13 = new JPanel();
  JPanel jPanel14 = new JPanel();
  GridBagLayout gridBagLayout3 = new GridBagLayout();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JTextField txtNumOfCategory2FinanceOffer = new JTextField();
  JLabel jLabel8 = new JLabel();

  public DialogGetCategory2FinanceOffer(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetCategory2FinanceOffer() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    this.setModal(true);
    this.setTitle("eBay SDK for Java - GetCategory2FinanceOffer");
    jPanel1.setLayout(borderLayout2);
    jPanel4.setBorder(BorderFactory.createEtchedBorder());
    jPanel4.setLayout(borderLayout4);
    jPanel2.setBorder(null);
    jPanel2.setMinimumSize(new Dimension(10, 10));
    jPanel2.setPreferredSize(new Dimension(10, 150));
    jPanel2.setLayout(borderLayout3);
    jPanel5.setBorder(null);
    jPanel5.setOpaque(true);
    jPanel5.setPreferredSize(new Dimension(10, 100));
    jPanel5.setLayout(gridBagLayout2);
    jPanel7.setLayout(gridBagLayout1);
    btnGetCategory2FinanceOffer.setText("GetCategory2FinanceOffer");
    btnGetCategory2FinanceOffer.addActionListener(new DialogGetCategory2FinanceOffer_btnGetCategory2FinanceOffer_actionAdapter(this));
    jLabel1.setText("CategoryID:");
    jLabel2.setText("    ");
    txtCategoryId.setPreferredSize(new Dimension(120, 21));
    txtCategoryId.setText("");
    jLabel3.setText("    ");
    txtLastModifiedDate.setPreferredSize(new Dimension(120, 21));
    txtLastModifiedDate.setText("");
    jLabel4.setText("LastModifiedDate:");
    jLabel5.setOpaque(false);
    jLabel5.setRequestFocusEnabled(true);
    jLabel5.setText("  (yyyy-mm-dd hh:mm:ss)");
    jPanel6.setPreferredSize(new Dimension(10, 1));
    jPanel8.setPreferredSize(new Dimension(10, 40));
    jPanel8.setLayout(borderLayout5);
    jPanel12.setBorder(null);
    jPanel12.setPreferredSize(new Dimension(300, 10));
    jPanel12.setLayout(gridBagLayout3);
    jLabel6.setText("Number of Categories:");
    jLabel7.setText("    ");
    txtNumOfCategory2FinanceOffer.setBackground(UIManager.getColor("Button.background"));
    txtNumOfCategory2FinanceOffer.setPreferredSize(new Dimension(60, 21));
    txtNumOfCategory2FinanceOffer.setText("");
    jLabel8.setPreferredSize(new Dimension(100, 10));
    jLabel8.setText("");
    jPanel3.setMinimumSize(new Dimension(10, 1));
    jPanel3.setPreferredSize(new Dimension(10, 1));
    jScrollPane1.getViewport().setBackground(Color.white);
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(jPanel5, BorderLayout.NORTH);
    jPanel5.add(jLabel1,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel2, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(txtCategoryId,  new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel3, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(txtLastModifiedDate, new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel4,  new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel5, new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jPanel6, BorderLayout.SOUTH);
    jPanel2.add(jPanel7, BorderLayout.CENTER);
    jPanel7.add(btnGetCategory2FinanceOffer, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel1.add(jPanel4, BorderLayout.CENTER);
    jPanel4.add(jPanel8, BorderLayout.NORTH);
    jPanel8.add(jPanel12, BorderLayout.WEST);
    jPanel12.add(jLabel6, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel12.add(jLabel7, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel12.add(txtNumOfCategory2FinanceOffer, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel8.add(jPanel13, BorderLayout.EAST);
    jPanel8.add(jPanel14, BorderLayout.CENTER);
    jPanel4.add(jPanel9, BorderLayout.SOUTH);
    jPanel4.add(jPanel10, BorderLayout.WEST);
    jPanel4.add(jPanel11, BorderLayout.EAST);
    jPanel12.add(jLabel8, new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel4.add(jScrollPane1, BorderLayout.CENTER);

    this.setSize(new Dimension(500, 400));
  }

  void btnGetCategory2FinanceOffer_actionPerformed(ActionEvent e)
  {
   try
   {
     DetailLevelCodeType[] detailLevels = new DetailLevelCodeType[] {
         DetailLevelCodeType.ReturnAll,
         DetailLevelCodeType.ItemReturnAttributes,
         DetailLevelCodeType.ItemReturnDescription
     };

     String categoryId = this.txtCategoryId.getText().trim();
     String lastModifiedDate = this.txtLastModifiedDate.getText().trim();

     GetCategory2FinanceOfferCall api = new GetCategory2FinanceOfferCall(this.apiContext);
     api.setDetailLevel(detailLevels);
     if (lastModifiedDate.length() > 0) {
      Calendar date = GuiUtil.getCalendarFromField(this.txtLastModifiedDate);
      api.setLastModifiedDate(date);
     }
     if (categoryId.length() > 0) {
       api.setCategoryId(categoryId);
     }
     CategoryFinanceOfferType[] categoryFinanceOffers = api.getCategory2FinanceOffer();
     displayCategory2FinanceOffer(categoryFinanceOffers);
    }
    catch(Exception ex)
    {
      ((FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }

  void displayCategory2FinanceOffer(CategoryFinanceOfferType[] categoryFinanceOffers)
  {
    int size = categoryFinanceOffers.length;
    this.txtNumOfCategory2FinanceOffer.setText(Integer.toString(size));
    DefaultMutableTreeNode top = createNodes(categoryFinanceOffers);

    JTree jTree1 = new JTree(top);
    jTree1.setEditable(false);
    jTree1.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
    jTree1.setShowsRootHandles(true);
    jTree1.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent e) {
      }
    });

    this.jScrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    this.jScrollPane1.setViewportBorder(BorderFactory.createEtchedBorder());
    DefaultTreeCellRenderer treeRenderer = new DefaultTreeCellRenderer();

    this.jScrollPane1.getViewport().add(jTree1, null);
  }

  public DefaultMutableTreeNode createNodes(CategoryFinanceOfferType[] categoryFinanceOffers)
  {
    DefaultMutableTreeNode top =  new DefaultMutableTreeNode("Categories");

    int size = categoryFinanceOffers.length;
    for (int i = 0; i < size; i++) {
      top.add(createCategoryNode(categoryFinanceOffers[i]));
    }
    return top;
   }

   DefaultMutableTreeNode createCategoryNode(CategoryFinanceOfferType cat)
   {
     String catId = cat.getCategoryID();
     if (catId.equals("-1")) {
       catId += " (All categories)";
     }
     DefaultMutableTreeNode catNode =  new DefaultMutableTreeNode("Category id = " + catId);
     String[] financeOffers = cat.getFinanceOfferID();
     int size = financeOffers.length;
     for (int i = 0; i < size; i++) {
       catNode.add(new DefaultMutableTreeNode("FinanceOffer id = " + financeOffers[i]));
     }
     return catNode;
   }
}

class DialogGetCategory2FinanceOffer_btnGetCategory2FinanceOffer_actionAdapter implements java.awt.event.ActionListener {
  DialogGetCategory2FinanceOffer adaptee;

  DialogGetCategory2FinanceOffer_btnGetCategory2FinanceOffer_actionAdapter(DialogGetCategory2FinanceOffer adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnGetCategory2FinanceOffer_actionPerformed(e);
  }
}



