/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.util.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.soap.eBLBaseComponents.*;

/**
* <p>Title: </p>
* <p>Description: </p>
* <p>Copyright: Copyright (c) 2004</p>
* <p>Company: eBay Inc.</p>
 * @author Changyi
 * @version 1.0
 */
public class DialogGetProductFinder extends JDialog {
  private ApiContext apiContext = new ApiContext();

  BorderLayout borderLayout1 = new BorderLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;

  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JButton btnGetProductFinder = new JButton();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField txtIDs = new JTextField();
  JLabel jLabel3 = new JLabel();
  JTextField txtBrowser = new JTextField();
  JLabel jLabel4 = new JLabel();
  GridBagLayout gridBagLayout3 = new GridBagLayout();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JTextField txtCallStatus = new JTextField();

  public DialogGetProductFinder(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetProductFinder() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    jPanel1.setLayout(borderLayout2);
    this.setModal(true);
    this.setTitle("eBay SDK for Java - GetProductFinder");

    jPanel2.setBorder(null);
    this.jPanel2.setPreferredSize(new Dimension(320, 100));
    jPanel2.setLayout(gridBagLayout2);
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel3.setPreferredSize(new Dimension(420, 50));
    jPanel3.setLayout(gridBagLayout3);
    this.jPanel4.setPreferredSize(new Dimension(420, 50));
    jPanel4.setLayout(gridBagLayout1);

    btnGetProductFinder.setText("GetProductFinder");
    btnGetProductFinder.addActionListener(new DialogGetProductFinder_btnGetProductFinder_actionAdapter(this));
    jLabel1.setText("ProductFinderIDs:");
    jLabel2.setText("    ");
    txtIDs.setMinimumSize(new Dimension(6, 21));
    txtIDs.setPreferredSize(new Dimension(120, 21));
    txtIDs.setText("");
    jLabel3.setText("    ");
    txtBrowser.setPreferredSize(new Dimension(257, 21));
    txtBrowser.setText("");
    jLabel4.setText("Browser Command:");
    jLabel5.setText("CallStatus:");
    jLabel6.setText("        ");
    txtCallStatus.setBackground(Color.lightGray);
    txtCallStatus.setPreferredSize(new Dimension(80, 21));
    txtCallStatus.setText("");
    txtCallStatus.setHorizontalAlignment(SwingConstants.CENTER);
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jPanel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(jLabel5, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel3.add(jLabel6, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel3.add(txtCallStatus, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel1.add(jPanel4, BorderLayout.CENTER);
    jPanel4.add(btnGetProductFinder,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel2,  new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtIDs,   new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel3,   new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel4,   new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtBrowser, new GridBagConstraints(2, 2, 1, 2, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

    this.txtBrowser.setText("C:/Program Files/Internet Explorer/IEXPLORE.EXE");
    this.setSize(new Dimension(420, 200));
    this.setResizable(false);
  }

  void btnGetProductFinder_actionPerformed(ActionEvent e) {
    try {
      DetailLevelCodeType[] detailLevels = new DetailLevelCodeType[] {
          DetailLevelCodeType.ReturnAll,
          DetailLevelCodeType.ItemReturnAttributes,
          DetailLevelCodeType.ItemReturnDescription
      };

      String browserPath = this.txtBrowser.getText().trim();
      if (browserPath.length() < 1) {

      }

      GetProductFinderCall api = new GetProductFinderCall(this.apiContext);
      api.setDetailLevel(detailLevels);

      String sIDs = this.txtIDs.getText().trim();

      StringTokenizer st = new StringTokenizer(sIDs, ",");
      ArrayList lstIDs = new ArrayList();
      while (st.hasMoreTokens()) {
        lstIDs.add(st.nextToken());
      }

      int size = lstIDs.size();
      if (size > 0) {
        int [] ids = new int[size];
        for (int i = 0; i < size; i++) {
          ids[i] = Integer.parseInt(lstIDs.get(i).toString().trim());
        }
        api.setProductFinderIDs(ids);
      }

      String resp = api.getProductFinder();

      String homeDir = System.getProperty("user.home");
      long t = System.currentTimeMillis();
      String filePath = homeDir.replace('\\', '/') + "/" + t + ".xml";
      FileWriter fw = new FileWriter(filePath);
      if (resp == null) {
        Date dt = api.getResponseObject().getTimestamp().getTime();
        resp = "<?xml version=\"1.0\" encoding=\"utf-8\"?><eBay><EBayTime>";
        resp += eBayUtil.toAPITimeString(dt);
        resp += "</EBayTime><Version>";
        resp += api.getAttributeSystemVersion();
        resp += "</Version></eBay>";
      }
      fw.write(resp);
      fw.close();
      String cmd = browserPath + " " + filePath;
      Process process = Runtime.getRuntime().exec(cmd);
      this.txtCallStatus.setText(api.getResponseObject().getAck().getValue().toString());
    }
    catch(Exception ex) {
      ((FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }
}

class DialogGetProductFinder_btnGetProductFinder_actionAdapter implements java.awt.event.ActionListener {
  DialogGetProductFinder adaptee;

  DialogGetProductFinder_btnGetProductFinder_actionAdapter(DialogGetProductFinder adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnGetProductFinder_actionPerformed(e);
  }
}
