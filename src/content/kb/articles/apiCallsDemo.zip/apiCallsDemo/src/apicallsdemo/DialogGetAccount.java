/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;

public class DialogGetAccount extends JDialog {

  private ApiContext apiContext = new ApiContext();

  final static int totalColumns = 7;
  final String[] colNames = new String[] {
      "RefNumber", "Type", "ItemID", "Balance", "Credit", "Date", "Debit"
  };

  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();

  JPanel panel1 = new JPanel();

  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();

  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JButton btnCallGetAccount = new JButton();
  GridLayout gridLayout1 = new GridLayout();
  JPanel jPanel6 = new JPanel();
  JRadioButton rbtnLastInvoice = new JRadioButton();
  JPanel jPanel8 = new JPanel();
  JRadioButton rbtnSpecifiedInvoice = new JRadioButton();
  JTextField txtInvoiceDate = new JTextField();
  JPanel jPanel9 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable tblAccountEntries = new JTable();
  ButtonGroup buttonGroupHistoryType = new ButtonGroup();
  JPanel jPanel10 = new JPanel();
  JRadioButton rbtnBetweenSpecifiedDates = new JRadioButton();
  JTextField txtToDate = new JTextField();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JTextField txtFromDate = new JTextField();
  JLabel jLabel4 = new JLabel();

  JPanel jPanel11 = new JPanel();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel13 = new JPanel();
  JPanel jPanel14 = new JPanel();

  public DialogGetAccount(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();

      java.util.Calendar calNow = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("GMT"));
      this.txtInvoiceDate.setText(eBayUtil.toAPITimeString(calNow.getTime()));

      GuiUtil.setTimeFilterFields(5, this.txtFromDate, this.txtToDate);

      updateGUI();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetAccount() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    btnCallGetAccount.setText("GetAccount");
    btnCallGetAccount.addActionListener(new DialogGetAccount_btnCallGetAccount_actionAdapter(this));
    jPanel4.setLayout(gridLayout1);
    gridLayout1.setRows(5);
    rbtnLastInvoice.setPreferredSize(new Dimension(320, 23));
    rbtnLastInvoice.setVerifyInputWhenFocusTarget(true);
    rbtnLastInvoice.setSelected(true);
    rbtnLastInvoice.setText("Since Last Invoice");
    rbtnLastInvoice.addChangeListener(new DialogGetAccount_rbtnLastInvoice_changeAdapter(this));
    rbtnSpecifiedInvoice.setPreferredSize(new Dimension(140, 23));
    rbtnSpecifiedInvoice.setText("Specified Invoice Date:");
    rbtnSpecifiedInvoice.addChangeListener(new DialogGetAccount_rbtnSpecifiedInvoice_changeAdapter(this));
    txtInvoiceDate.setPreferredSize(new Dimension(85, 21));
    txtInvoiceDate.setToolTipText("");
    txtInvoiceDate.setSelectionStart(0);
    txtInvoiceDate.setText("");
    jLabel1.setText("Specify Account History to view");
    rbtnBetweenSpecifiedDates.setText("Between Dates:");
    rbtnBetweenSpecifiedDates.addChangeListener(new DialogGetAccount_rbtnBetweenSpecifiedDates_changeAdapter(this));
    jLabel2.setText("To");
    jLabel3.setVerifyInputWhenFocusTarget(true);
    jLabel3.setText("From");
    txtFromDate.setPreferredSize(new Dimension(80, 21));
    txtFromDate.setText("");
    txtToDate.setPreferredSize(new Dimension(80, 21));
    txtToDate.setSelectionStart(0);
    txtToDate.setText("");
    jLabel4.setText("(yyyy-mm-dd hh:mm:ss)");
    jPanel3.setPreferredSize(new Dimension(10, 1));
    jScrollPane1.getViewport().setBackground(Color.white);
    jPanel5.setPreferredSize(new Dimension(103, 40));
    jPanel8.add(rbtnSpecifiedInvoice, null);
    jPanel8.add(txtInvoiceDate, null);
    jPanel8.add(jLabel4, null);
    jPanel10.add(rbtnBetweenSpecifiedDates, null);
    jPanel10.add(jLabel3, null);
    jPanel10.add(txtFromDate, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(txtToDate, null);
    getContentPane().add(panel1);
    panel1.add(jPanel1,  BorderLayout.NORTH);
    jPanel1.add(jPanel4,  BorderLayout.NORTH);
    jPanel1.add(jPanel5, BorderLayout.CENTER);
    jPanel5.add(btnCallGetAccount, null);
    panel1.add(jPanel2, BorderLayout.CENTER);

    jPanel2.setLayout(borderLayout3);
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.add(jPanel11, BorderLayout.NORTH);
    jPanel2.add(jPanel12, BorderLayout.SOUTH);
    jPanel2.add(jPanel13, BorderLayout.WEST);
    jPanel2.add(jPanel14, BorderLayout.EAST);
    jPanel2.add(jScrollPane1, BorderLayout.CENTER);

    jScrollPane1.getViewport().add(tblAccountEntries, null);
    panel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel4.add(jPanel9, null);
    jPanel9.add(jLabel1, null);
    jPanel4.add(jPanel6, null);
    jPanel6.add(rbtnLastInvoice, null);
    jPanel4.add(jPanel8, null);
    jPanel4.add(jPanel10, null);
    buttonGroupHistoryType.add(rbtnLastInvoice);
    buttonGroupHistoryType.add(rbtnSpecifiedInvoice);
    buttonGroupHistoryType.add(rbtnBetweenSpecifiedDates);

    this.setSize(new Dimension(700, 450));
  }

  static String[] accountEntryToColumns(AccountEntryType entry)
  {
    String[] cols = new String[totalColumns];
    int i = 0;
    cols[i++] = entry.getRefNumber() != null ? entry.getRefNumber() : "";
    cols[i++] = entry.getAccountDetailsEntryType() != null ? entry.getAccountDetailsEntryType().toString() : "";
    cols[i++] = entry.getItemID() != null ? entry.getItemID().toString() : "";
    cols[i++] = entry.getBalance() != null ? new Double(entry.getBalance().getValue()).toString() : "";
    cols[i++] = entry.getCredit() != null ? new Double(entry.getCredit().getValue()).toString() : "";
    cols[i++] = entry.getDate() != null ? eBayUtil.toAPITimeString(entry.getDate().getTime()) : "";
    cols[i++] = entry.getDebit() != null ? new Double(entry.getDebit().getValue()).toString() : "";

    return cols;
  }

  void updateGUI()
  {
    this.txtInvoiceDate.setEnabled(this.rbtnSpecifiedInvoice.isSelected());
    boolean period = this.rbtnBetweenSpecifiedDates.isSelected();
    this.txtFromDate.setEnabled(period);
    this.txtToDate.setEnabled(period);
  }

  void btnCallGetAccount_actionPerformed(ActionEvent e) {
    try
    {
      GetAccountCall api = new GetAccountCall(this.apiContext);
      api.setDetailLevel(new DetailLevelCodeType[] { DetailLevelCodeType.ReturnAll});

      AccountHistorySelectionCodeType ht = AccountHistorySelectionCodeType.AllHistory;

      if( this.rbtnLastInvoice.isSelected() )
      {
        ht = AccountHistorySelectionCodeType.LastInvoice;
      }
      else if( this.rbtnSpecifiedInvoice.isSelected() )
      {
        ht = AccountHistorySelectionCodeType.SpecifiedInvoice;
        api.setInvoiceDate(GuiUtil.getCalendarFromField(this.txtInvoiceDate));
      }
      else if( this.rbtnBetweenSpecifiedDates.isSelected() )
      {
        ht = AccountHistorySelectionCodeType.BetweenSpecifiedDates;
        api.setViewPeriod(GuiUtil.getTimeFilterFromFields(this.txtFromDate, this.txtToDate));
      }
      api.setViewType(ht);

      // Call eBay.
      final AccountEntryType[] entries = api.getAccount();

      // Display items in table.
      TableModel dataModel = new AbstractTableModel() {
        public int getColumnCount() { return totalColumns; }
        public int getRowCount() { return entries == null ? 0 : entries.length;}
        public String getColumnName(int columnIndex){
          return colNames[columnIndex];
        }
        public Object getValueAt(int row, int col)
        {
          AccountEntryType cat = entries[row];
          return accountEntryToColumns(cat)[col];
        }
      };

      this.tblAccountEntries.setModel(dataModel);
    }
    catch(Exception ex)
    {
      String msg = ex.getClass().getName() + " : " + ex.getMessage();
      ((FrameDemo)this.getParent()).showErrorMessage(msg);
    }
  }

  void rbtnLastInvoice_stateChanged(ChangeEvent e) {
    this.updateGUI();
  }

  void rbtnSpecifiedInvoice_stateChanged(ChangeEvent e) {
    this.updateGUI();
  }

  void rbtnBetweenSpecifiedDates_stateChanged(ChangeEvent e) {
    this.updateGUI();
  }

  void rbtnAllHistory_stateChanged(ChangeEvent e) {
    this.updateGUI();
  }
}

class DialogGetAccount_btnCallGetAccount_actionAdapter implements java.awt.event.ActionListener {
  DialogGetAccount adaptee;

  DialogGetAccount_btnCallGetAccount_actionAdapter(DialogGetAccount adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnCallGetAccount_actionPerformed(e);
  }
}

class DialogGetAccount_rbtnLastInvoice_changeAdapter implements javax.swing.event.ChangeListener {
  DialogGetAccount adaptee;

  DialogGetAccount_rbtnLastInvoice_changeAdapter(DialogGetAccount adaptee) {
    this.adaptee = adaptee;
  }
  public void stateChanged(ChangeEvent e) {
    adaptee.rbtnLastInvoice_stateChanged(e);
  }
}

class DialogGetAccount_rbtnSpecifiedInvoice_changeAdapter implements javax.swing.event.ChangeListener {
  DialogGetAccount adaptee;

  DialogGetAccount_rbtnSpecifiedInvoice_changeAdapter(DialogGetAccount adaptee) {
    this.adaptee = adaptee;
  }
  public void stateChanged(ChangeEvent e) {
    adaptee.rbtnSpecifiedInvoice_stateChanged(e);
  }
}

class DialogGetAccount_rbtnBetweenSpecifiedDates_changeAdapter implements javax.swing.event.ChangeListener {
  DialogGetAccount adaptee;

  DialogGetAccount_rbtnBetweenSpecifiedDates_changeAdapter(DialogGetAccount adaptee) {
    this.adaptee = adaptee;
  }
  public void stateChanged(ChangeEvent e) {
    adaptee.rbtnBetweenSpecifiedDates_stateChanged(e);
  }
}
