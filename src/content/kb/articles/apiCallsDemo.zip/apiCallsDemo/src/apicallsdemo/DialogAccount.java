/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
			  All rights reserved."

*/

package apicallsdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import com.ebay.sdk.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: eBay Inc.</p>
 * @author Weijun Li
 * @version 1.0
 */

public class DialogAccount extends JDialog {
  private ApiContext apiContext;

  BorderLayout borderLayout1 = new BorderLayout();
  JButton btnOK = new JButton();
  JPanel jPanelBottom = new JPanel();
  JPanel jPanelUNCredential = new JPanel();
  JPanel jPanelTokenCredential = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanelEBayAccount = new JPanel();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout5 = new BorderLayout();
  JPanel jPanelAPIAccount = new JPanel();
  JPanel jPanelUNCHolder = new JPanel();
  JPanel jPanelTCHolder = new JPanel();
  BorderLayout borderLayout6 = new BorderLayout();
  BorderLayout borderLayout7 = new BorderLayout();
  JPanel jPanel5 = new JPanel();
  JRadioButton rbtnUseUserName = new JRadioButton();
  GridLayout gridLayout1 = new GridLayout();
  JPanel jPanelDevId = new JPanel();
  JPanel jPanelCertificate = new JPanel();
  JTextField txtDeveloperID = new JTextField();
  JLabel jLabel1 = new JLabel();
  JTextField txtCertificate = new JTextField();
  JLabel jLabel3 = new JLabel();
  GridLayout gridLayout2 = new GridLayout();
  JPanel jPanel8 = new JPanel();
  JPanel jPanel9 = new JPanel();
  JTextField txtUserName = new JTextField();
  JLabel jLabel4 = new JLabel();
  JTextField txtPassword = new JTextField();
  JLabel jLabel5 = new JLabel();
  JPanel jPanel4 = new JPanel();
  JRadioButton rbtnUserToken = new JRadioButton();
  JPanel jPanel10 = new JPanel();
  JPanel jPanel11 = new JPanel();
  JLabel jLabel6 = new JLabel();
  BorderLayout borderLayout4 = new BorderLayout();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  BorderLayout borderLayout8 = new BorderLayout();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel13 = new JPanel();
  GridLayout gridLayout3 = new GridLayout();
  JPanel jPanel14 = new JPanel();
  JPanel jPanel15 = new JPanel();
  JTextField txtApiServerUrl = new JTextField();
  JLabel jLabel9 = new JLabel();
  JTextField txtEpsServerUrl = new JTextField();
  JLabel jLabel10 = new JLabel();
  ButtonGroup CredentialType = new ButtonGroup();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTextPane txtTokenData = new JTextPane();
  JPanel jPanel16 = new JPanel();
  BorderLayout borderLayout9 = new BorderLayout();
  JPanel jPanelApiCredentials = new JPanel();
  JLabel jLabel2 = new JLabel();
  JTextField txtApplicationID = new JTextField();
  JPanel jPanelAppId = new JPanel();

  public DialogAccount(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();

      //
      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();

      this.txtTokenData.setText(this.apiContext.getApiCredential().geteBayToken());

      ApiAccount ac = this.apiContext.getApiCredential().getApiAccount();
      eBayAccount ec = this.apiContext.getApiCredential().geteBayAccount();
      this.txtDeveloperID.setText(ac.getDeveloper());
      this.txtApplicationID.setText(ac.getApplication());
      this.txtCertificate.setText(ac.getCertificate());

      this.txtUserName.setText(ec.getUsername());
      this.txtPassword.setText(ec.getPassword());

      this.txtApiServerUrl.setText(this.apiContext.getApiServerUrl());
      this.txtEpsServerUrl.setText(this.apiContext.getEpsServerUrl());

      this.rbtnUserToken.setSelected(this.apiContext.getApiCredential().geteBayToken().length() > 0);

      //
      updateGUIStatus();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void updateGUIStatus()
  {
    this.jPanelUNCredential.setVisible(this.rbtnUseUserName.isSelected());
    this.jPanelTokenCredential.setVisible(this.rbtnUserToken.isSelected());
  }

  public DialogAccount() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    this.getContentPane().setLayout(borderLayout1);
    this.setModal(true);
    this.setResizable(true);
    this.setTitle("Account Information");
    btnOK.setText("OK");
    btnOK.addActionListener(new DialogAccount_btnOK_actionAdapter(this));

    jPanelUNCredential.setDebugGraphicsOptions(0);
    jPanelUNCredential.setLayout(borderLayout2);
    jPanelTokenCredential.setLayout(borderLayout3);
    jPanelEBayAccount.setLayout(gridLayout2);
    jPanel1.setLayout(borderLayout5);
    jPanelUNCHolder.setLayout(borderLayout6);
    jPanelTCHolder.setLayout(borderLayout7);
    rbtnUseUserName.setPreferredSize(new Dimension(260, 23));
    rbtnUseUserName.setSelected(true);
    rbtnUseUserName.setText("Use Username/Password as credential.");
    rbtnUseUserName.addChangeListener(new DialogAccount_rbtnUseUserName_changeAdapter(this));
    jPanelAPIAccount.setLayout(gridLayout1);
    gridLayout1.setColumns(1);
    gridLayout1.setRows(3);
    jLabel1.setPreferredSize(new Dimension(80, 15));
    jLabel1.setText("DeveloperID:");
    jLabel3.setPreferredSize(new Dimension(80, 15));
    jLabel3.setText("Certificate:");
    gridLayout2.setColumns(1);
    gridLayout2.setRows(2);
    jLabel4.setPreferredSize(new Dimension(80, 15));
    jLabel4.setText("Username:");
    jLabel5.setPreferredSize(new Dimension(80, 15));
    jLabel5.setText("Password:");
    rbtnUserToken.setPreferredSize(new Dimension(260, 23));
    rbtnUserToken.setText("Use token as credential.");
    rbtnUserToken.addChangeListener(new DialogAccount_rbtnUserToken_changeAdapter(this));
    jLabel6.setText("Enter your token text:");
    jPanel10.setLayout(borderLayout4);
    jLabel7.setText("        ");
    jLabel8.setToolTipText("");
    jLabel8.setText("        ");
    txtDeveloperID.setPreferredSize(new Dimension(100, 21));
    txtDeveloperID.setText("Admintest1");
    txtDeveloperID.addActionListener(new DialogAccount_txtDeveloperID_actionAdapter(this));
    txtCertificate.setPreferredSize(new Dimension(100, 21));
    txtCertificate.setText("AdminCertificate");
    txtUserName.setPreferredSize(new Dimension(100, 21));
    txtUserName.setText("apitest11");
    txtPassword.setPreferredSize(new Dimension(100, 21));
    txtPassword.setToolTipText("");
    txtPassword.setText("ebay");
    jPanelBottom.setLayout(borderLayout8);
    jPanel13.setLayout(gridLayout3);
    gridLayout3.setColumns(1);
    gridLayout3.setRows(2);
    jLabel9.setPreferredSize(new Dimension(90, 15));
    jLabel9.setText("API Server URL:");
    jLabel10.setPreferredSize(new Dimension(90, 15));
    jLabel10.setText("EPS Server URL:");
    txtApiServerUrl.setPreferredSize(new Dimension(200, 21));
    txtApiServerUrl.setText("");
    txtEpsServerUrl.setPreferredSize(new Dimension(200, 21));
    txtEpsServerUrl.setText("");
    jPanel16.setLayout(borderLayout9);
    jLabel2.setPreferredSize(new Dimension(80, 15));
    jLabel2.setText("ApplicationID:");
    txtApplicationID.setPreferredSize(new Dimension(100, 21));
    txtApplicationID.setRequestFocusEnabled(true);
    txtApplicationID.setText("AdminApp");
    txtTokenData.setPreferredSize(new Dimension(50, 21));
    jPanelAppId.add(jLabel2, null);
    jPanelAppId.add(txtApplicationID, null);
    this.getContentPane().add(jPanelBottom, BorderLayout.SOUTH);
    jPanelUNCredential.add(jPanelEBayAccount, BorderLayout.CENTER);
    jPanel10.add(jLabel7,  BorderLayout.WEST);
    jPanel10.add(jLabel8,  BorderLayout.EAST);
    jPanel10.add(jScrollPane1,  BorderLayout.CENTER);
    jPanelTokenCredential.add(jPanel11, BorderLayout.NORTH);
    jPanel11.add(jLabel6, null);
    jPanelTCHolder.add(jPanel4, BorderLayout.NORTH);
    jPanel4.add(rbtnUserToken, null);
    jScrollPane1.getViewport().add(txtTokenData, null);
    jPanelTokenCredential.add(jPanel10, BorderLayout.CENTER);
    jPanelTCHolder.add(jPanelTokenCredential, BorderLayout.CENTER);
    this.getContentPane().add(jPanel16,  BorderLayout.CENTER);
    jPanel16.add(jPanelTCHolder, BorderLayout.SOUTH);
    jPanel16.add(jPanelUNCHolder,  BorderLayout.CENTER);
    jPanelUNCHolder.add(jPanelUNCredential, BorderLayout.CENTER);
    jPanelDevId.add(jLabel1, null);
    jPanelDevId.add(txtDeveloperID, null);
    jPanelAPIAccount.add(jPanelDevId, null);
    jPanelCertificate.add(jLabel3, null);
    jPanelCertificate.add(txtCertificate, null);
    jPanelAPIAccount.add(jPanelAppId, null);
    jPanelAPIAccount.add(jPanelCertificate, null);
    jPanelUNCHolder.add(jPanel5, BorderLayout.NORTH);
    jPanel5.add(rbtnUseUserName, null);
    jPanel16.add(jPanelApiCredentials, BorderLayout.NORTH);
    jPanelApiCredentials.add(jPanelAPIAccount, null);
    jPanelEBayAccount.add(jPanel8, null);
    jPanel8.add(jLabel4, null);
    jPanel8.add(txtUserName, null);
    jPanelEBayAccount.add(jPanel9, null);
    jPanel9.add(jLabel5, null);
    jPanel9.add(txtPassword, null);
    jPanelUNCredential.add(jPanel1, BorderLayout.SOUTH);
    jPanelBottom.add(jPanel12, BorderLayout.SOUTH);
    jPanel12.add(btnOK, null);
    jPanelBottom.add(jPanel13, BorderLayout.NORTH);
    jPanel13.add(jPanel14, null);
    jPanel14.add(jLabel9, null);
    jPanel14.add(txtApiServerUrl, null);
    jPanel13.add(jPanel15, null);
    jPanel15.add(jLabel10, null);
    jPanel15.add(txtEpsServerUrl, null);
    CredentialType.add(rbtnUseUserName);
    CredentialType.add(rbtnUserToken);

  }

  void btnOK_actionPerformed(ActionEvent e)
  {
    if( this.txtDeveloperID.getText().length() == 0 ||
        this.txtApplicationID.getText().length() == 0 ||
        this.txtCertificate.getText().length() == 0)
    {
      JOptionPane.showMessageDialog(this, "Please enter the application ID, developer ID and certificate ID.", "Account", JOptionPane.ERROR_MESSAGE);
      return;
    }

    ApiAccount ac = this.apiContext.getApiCredential().getApiAccount();
    eBayAccount ec = this.apiContext.getApiCredential().geteBayAccount();

    ac.setApplication(this.txtApplicationID.getText());
    ac.setDeveloper(this.txtDeveloperID.getText());
    ac.setCertificate(this.txtCertificate.getText());

    if( this.rbtnUseUserName.isSelected() )
    {
      ec.setUsername(this.txtUserName.getText());
      ec.setPassword(this.txtPassword.getText());

      // Empty token field.
      this.apiContext.getApiCredential().seteBayToken("");
    }
    else
    {
        this.apiContext.getApiCredential().seteBayToken(this.txtTokenData.getText());
    }

    this.apiContext.setApiServerUrl(this.txtApiServerUrl.getText());
    this.apiContext.setEpsServerUrl(this.txtEpsServerUrl.getText());

    this.dispose();
  }

  void rbtnUseUserName_stateChanged(ChangeEvent e) {
    updateGUIStatus();
  }

  void rbtnUserToken_stateChanged(ChangeEvent e) {
    updateGUIStatus();
  }

  void txtDeveloperID_actionPerformed(ActionEvent e) {

  }
}

class DialogAccount_btnOK_actionAdapter implements java.awt.event.ActionListener {
  DialogAccount adaptee;

  DialogAccount_btnOK_actionAdapter(DialogAccount adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnOK_actionPerformed(e);
  }
}

class DialogAccount_rbtnUseUserName_changeAdapter implements javax.swing.event.ChangeListener {
  DialogAccount adaptee;

  DialogAccount_rbtnUseUserName_changeAdapter(DialogAccount adaptee) {
    this.adaptee = adaptee;
  }
  public void stateChanged(ChangeEvent e) {
    adaptee.rbtnUseUserName_stateChanged(e);
  }
}

class DialogAccount_rbtnUserToken_changeAdapter implements javax.swing.event.ChangeListener {
  DialogAccount adaptee;

  DialogAccount_rbtnUserToken_changeAdapter(DialogAccount adaptee) {
    this.adaptee = adaptee;
  }
  public void stateChanged(ChangeEvent e) {
    adaptee.rbtnUserToken_stateChanged(e);
  }
}

class DialogAccount_txtDeveloperID_actionAdapter implements java.awt.event.ActionListener {
  DialogAccount adaptee;

  DialogAccount_txtDeveloperID_actionAdapter(DialogAccount adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.txtDeveloperID_actionPerformed(e);
  }
}
