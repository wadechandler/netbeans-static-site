/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.util.Date;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.soap.eBLBaseComponents.*;
import com.ebay.sdk.helper.ui.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: eBay Inc.</p>
 * @author not attributable
 * @version 1.0
 */

public class DialogAddMemberMessage extends JDialog {
  private ApiContext apiContext = new ApiContext();

  BorderLayout borderLayout1 = new BorderLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;

  static ControlTagItem[] messageTypes = new ControlTagItem[] {
      new ControlTagItem(MessageTypeCodeType.AskSellerQuestion.toString(), MessageTypeCodeType.AskSellerQuestion),
      new ControlTagItem(MessageTypeCodeType.ResponseToASQQuestion.toString(), MessageTypeCodeType.ResponseToASQQuestion),
      new ControlTagItem(MessageTypeCodeType.ContactEbayMember.toString(), MessageTypeCodeType.ContactEbayMember)
  };

  static ControlTagItem[] questionTypes = new ControlTagItem[] {
      new ControlTagItem(QuestionTypeCodeType.General.toString(), QuestionTypeCodeType.General),
      new ControlTagItem(QuestionTypeCodeType.Shipping.toString(), QuestionTypeCodeType.Shipping),
      new ControlTagItem(QuestionTypeCodeType.Payment.toString(), QuestionTypeCodeType.Payment),
      new ControlTagItem(QuestionTypeCodeType.MultipleItemShipping.toString(), QuestionTypeCodeType.MultipleItemShipping)
  };

  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel7 = new JPanel();
  BorderLayout borderLayout4 = new BorderLayout();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField txtCallStatus = new JTextField();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JButton tbnAddMemberMessage = new JButton();
  GridBagLayout gridBagLayout3 = new GridBagLayout();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JTextField txtItemId = new JTextField();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JComboBox cbxMessageType = new JComboBox();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel lbDisplayToPublic = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JLabel lbEmailCopyToSender = new JLabel();
  JLabel jLabel18 = new JLabel();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JComboBox cbxQuestionType = new JComboBox();
  BorderLayout borderLayout5 = new BorderLayout();
  JTextField txtRecipientUserId = new JTextField();
  JTextField txtParentMessageId = new JTextField();
  JLabel jLabel20 = new JLabel();
  JLabel jLabel21 = new JLabel();
  JTextField txtSubject = new JTextField();
  BorderLayout borderLayout6 = new BorderLayout();
  JPanel jPanel8 = new JPanel();
  JPanel jPanel9 = new JPanel();
  BorderLayout borderLayout7 = new BorderLayout();
  JLabel jLabel24 = new JLabel();
  JLabel jLabel25 = new JLabel();
  JLabel jLabel26 = new JLabel();
  JLabel jLabel22 = new JLabel();
  JLabel jLabel23 = new JLabel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTextPane txpMessageText = new JTextPane();
  JCheckBox ckbHideSenderEmailAddress = new JCheckBox();
  JCheckBox ckbDisplayToPublic = new JCheckBox();
  JCheckBox ckbEmailCopyToSender = new JCheckBox();
  JLabel jLabel12 = new JLabel();
  JTextField txteBayTime = new JTextField();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel27 = new JLabel();


  public DialogAddMemberMessage(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      customInit();
      pack();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogAddMemberMessage() {
    this(null, "", false);
  }

  void customInit()
  {
    initStaticControls();
  }

  void initStaticControls()
  {
    DefaultComboBoxModel dataModel = new DefaultComboBoxModel(DialogAddMemberMessage.messageTypes);
    this.cbxMessageType.setModel(dataModel);

    dataModel = new DefaultComboBoxModel(DialogAddMemberMessage.questionTypes);
    this.cbxQuestionType.setModel(dataModel);
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    jPanel1.setLayout(borderLayout2);

    this.setTitle("eBay SDK for Java - AddMemberMessage");
    this.getContentPane().setLayout(borderLayout4);

    this.jPanel2.setPreferredSize(new Dimension(550, 150));
    jPanel2.setLayout(gridBagLayout3);
    this.jPanel3.setPreferredSize(new Dimension(550, 220));
    jPanel3.setLayout(borderLayout3);
    jPanel4.setBorder(null);
    this.jPanel4.setPreferredSize(new Dimension(550, 25));
    jPanel4.setLayout(borderLayout5);
    this.jPanel5.setPreferredSize(new Dimension(550, 150));
    jPanel5.setLayout(borderLayout6);
    jPanel6.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel6.setPreferredSize(new Dimension(550, 30));
    jPanel6.setLayout(gridBagLayout1);
    jPanel7.setPreferredSize(new Dimension(550, 25));
    jPanel7.setLayout(gridBagLayout2);
    jLabel1.setText("CallStatus:");
    jLabel2.setText("        ");
    txtCallStatus.setBackground(UIManager.getColor("Button.background"));
    txtCallStatus.setPreferredSize(new Dimension(65, 21));
    txtCallStatus.setText("");
    txtCallStatus.setScrollOffset(0);
    tbnAddMemberMessage.setText("AddMemberMessage");
    tbnAddMemberMessage.addActionListener(new DialogAddMemberMessage_tbnAddMemberMessage_actionAdapter(this));
    jLabel3.setText("ItemID:");
    jLabel4.setText("    ");
    jLabel5.setText("    ");
    jLabel7.setText("    ");
    jLabel8.setText("RecipientUserID:");
    jLabel9.setText("    ");
    jLabel10.setText("ParentMessageID:");
    jLabel11.setText("    ");
    lbDisplayToPublic.setText("DisplayToPublic:");
    jLabel13.setText("    ");
    jLabel14.setText("        ");
    jLabel15.setText("HideSenderEmailAddress:");
    lbEmailCopyToSender.setText("EmailCopyToSender:");
    jLabel18.setText("    ");
    jLabel17.setText("MessageType:");
    jLabel19.setText("QuestionType:");
    jLabel6.setText("        ");
    jLabel20.setPreferredSize(new Dimension(80, 15));
    jLabel20.setRequestFocusEnabled(true);
    jLabel20.setText("      Subject:");
    jLabel21.setText("    ");
    jPanel8.setPreferredSize(new Dimension(10, 25));
    jPanel8.setLayout(borderLayout7);
    jLabel24.setText("      Message:");
    jLabel25.setText("  ");
    jLabel26.setText("  ");
    jLabel22.setText("    ");
    jLabel23.setText("    ");
    jPanel9.setPreferredSize(new Dimension(10, 2));
    txpMessageText.setText("");
    txtItemId.setPreferredSize(new Dimension(85, 21));
    txtItemId.setText("");
    txtRecipientUserId.setPreferredSize(new Dimension(85, 21));
    txtRecipientUserId.setText("");
    txtParentMessageId.setPreferredSize(new Dimension(85, 21));
    txtParentMessageId.setText("");
    ckbHideSenderEmailAddress.setText("");
    ckbDisplayToPublic.setText("");
    ckbEmailCopyToSender.setText("");
    jLabel12.setText("        ");
    jLabel16.setText("    ");
    jLabel27.setText("eBayTime:");
    txteBayTime.setBackground(UIManager.getColor("Button.background"));
    txteBayTime.setPreferredSize(new Dimension(120, 21));
    txteBayTime.setText("");
    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jPanel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(jPanel5, BorderLayout.NORTH);
    jPanel5.add(jPanel8, BorderLayout.NORTH);
    jPanel8.add(jLabel24, BorderLayout.WEST);
    jPanel8.add(jLabel25, BorderLayout.EAST);
    jPanel8.add(jLabel26, BorderLayout.CENTER);
    jPanel5.add(jPanel9, BorderLayout.SOUTH);
    jPanel5.add(jLabel22, BorderLayout.WEST);
    jPanel5.add(jLabel23, BorderLayout.EAST);
    jPanel5.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(txpMessageText, null);
    jPanel3.add(jPanel6, BorderLayout.SOUTH);
    jPanel6.add(jLabel1,     new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel2,     new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(txtCallStatus,     new GridBagConstraints(7, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel12,    new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(txteBayTime,     new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel16,  new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel27, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel3.add(jPanel7, BorderLayout.CENTER);
    jPanel1.add(jPanel4, BorderLayout.CENTER);
    jPanel4.add(jLabel20, BorderLayout.WEST);
    jPanel4.add(jLabel21, BorderLayout.EAST);
    jPanel4.add(txtSubject, BorderLayout.CENTER);
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel7.add(tbnAddMemberMessage, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel3,     new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel4,     new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtItemId,      new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel5,    new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel6,    new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel7,    new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel8,     new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel9,    new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel10,     new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel11,    new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(lbDisplayToPublic,     new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel13,    new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel14,    new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel18,    new GridBagConstraints(6, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(cbxMessageType,    new GridBagConstraints(6, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel17,   new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel19,   new GridBagConstraints(4, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel15,  new GridBagConstraints(4, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(lbEmailCopyToSender, new GridBagConstraints(4, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(cbxQuestionType,   new GridBagConstraints(6, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtRecipientUserId,   new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtParentMessageId,   new GridBagConstraints(2, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(ckbHideSenderEmailAddress,     new GridBagConstraints(6, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, -4, 0, 0), 0, 0));
    jPanel2.add(ckbDisplayToPublic,  new GridBagConstraints(2, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, -4, 0, 0), 0, 0));
    jPanel2.add(ckbEmailCopyToSender,  new GridBagConstraints(6, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, -4, 0, 0), 0, 0));

    this.setModal(true);
    this.setSize(new Dimension(550, 395));
    this.setResizable(false);
  }

  void tbnAddMemberMessage_actionPerformed(ActionEvent e)
  {
    try {
      DetailLevelCodeType[] detailLevels = new DetailLevelCodeType[] {
          DetailLevelCodeType.ReturnAll,
          DetailLevelCodeType.ItemReturnAttributes,
          DetailLevelCodeType.ItemReturnDescription
      };

      MemberMessageType message = new MemberMessageType();
      message.setDisplayToPublic(new Boolean(this.ckbDisplayToPublic.isSelected()));
      message.setEmailCopyToSender(new Boolean(this.ckbEmailCopyToSender.isSelected()));
      message.setHideSendersEmailAddress(new Boolean(this.ckbHideSenderEmailAddress.isSelected()));
      message.setMessageType((MessageTypeCodeType)((ControlTagItem)this.cbxMessageType.getSelectedItem()).Tag);
      message.setQuestionType((QuestionTypeCodeType)((ControlTagItem)this.cbxQuestionType.getSelectedItem()).Tag);

      String subject = this.txtSubject.getText().trim();
      if (subject.length() > 0) {
        message.setSubject(subject);
      }
      String recipientUserId = this.txtRecipientUserId.getText().trim();
      if (recipientUserId.length() > 0) {
        message.setRecipientID(new String[] {recipientUserId});
      }
      String parentMessageId = this.txtParentMessageId.getText().trim();
      if (parentMessageId.length() > 0) {
        message.setParentMessageID(parentMessageId);
      }

      String messageText = this.txpMessageText.getText().trim();
      message.setBody(messageText);

      AddMemberMessageCall api = new AddMemberMessageCall(this.apiContext);
      api.setDetailLevel(detailLevels);
      api.setMemberMessage(message);

      String itemId = this.txtItemId.getText().trim();
      if (itemId.length() > 0) {
        api.setItemID(new ItemIDType(itemId));
      }
      this.txpMessageText.getText().trim();

      AddMemberMessageResponseType resp = api.AddMemberMessage();
      Date dt = resp.getTimestamp().getTime();
      this.txteBayTime.setText(eBayUtil.toAPITimeString(dt));
      this.txtCallStatus.setText(resp.getAck().getValue().toString());
    }
    catch (Exception ex) {
      ( (FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }
}

class DialogAddMemberMessage_tbnAddMemberMessage_actionAdapter implements java.awt.event.ActionListener {
  DialogAddMemberMessage adaptee;

  DialogAddMemberMessage_tbnAddMemberMessage_actionAdapter(DialogAddMemberMessage adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.tbnAddMemberMessage_actionPerformed(e);
  }
}
