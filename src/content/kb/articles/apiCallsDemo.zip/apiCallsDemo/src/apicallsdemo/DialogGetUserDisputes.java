/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.util.ArrayList;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: eBay Inc.</p>
 * @author Changyi
 * @version 1.0
 */
public class DialogGetUserDisputes extends JDialog {
  private ApiContext apiContext = new ApiContext();

  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel20 = new JLabel();
  JLabel jLabel21 = new JLabel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel23 = new JLabel();
  JLabel jLabel8 = new JLabel();

  static ControlTagItem[] filters = new ControlTagItem[] {
      new ControlTagItem(DisputeFilterTypeCodeType.AllInvolvedDisputes.toString(), DisputeFilterTypeCodeType.AllInvolvedDisputes),
      new ControlTagItem(DisputeFilterTypeCodeType.DisputesAwaitingMyResponse.toString(), DisputeFilterTypeCodeType.DisputesAwaitingMyResponse),
      new ControlTagItem(DisputeFilterTypeCodeType.DisputesAwaitingOtherPartyResponse.toString(), DisputeFilterTypeCodeType.DisputesAwaitingOtherPartyResponse),
      new ControlTagItem(DisputeFilterTypeCodeType.AllInvolvedClosedDisputes.toString(), DisputeFilterTypeCodeType.AllInvolvedClosedDisputes)
  };

  static ControlTagItem[] sortTypes = new ControlTagItem[] {
      new ControlTagItem(DisputeSortTypeCodeType.None.toString(), DisputeSortTypeCodeType.None),
      new ControlTagItem(DisputeSortTypeCodeType.DisputeCreatedTimeAscending.toString(), DisputeSortTypeCodeType.DisputeCreatedTimeAscending),
      new ControlTagItem(DisputeSortTypeCodeType.DisputeCreatedTimeDescending.toString(), DisputeSortTypeCodeType.DisputeCreatedTimeDescending),
      new ControlTagItem(DisputeSortTypeCodeType.DisputeStatusAscending.toString(), DisputeSortTypeCodeType.DisputeStatusAscending),
      new ControlTagItem(DisputeSortTypeCodeType.DisputeStatusDescending.toString(), DisputeSortTypeCodeType.DisputeStatusDescending),
      new ControlTagItem(DisputeSortTypeCodeType.DisputeCreditEligibilityAscending.toString(), DisputeSortTypeCodeType.DisputeCreditEligibilityAscending),
      new ControlTagItem(DisputeSortTypeCodeType.DisputeCreditEligibilityDescending.toString(), DisputeSortTypeCodeType.DisputeCreditEligibilityDescending)
  };

  static ControlTagItem[] sortOrder = new ControlTagItem[] {
      new ControlTagItem(SortOrderCodeType.Ascending.toString(), SortOrderCodeType.Ascending),
      new ControlTagItem(SortOrderCodeType.Descending.toString(), SortOrderCodeType.Descending)
  };

  JLabel jLabel16 = new JLabel();
  BorderLayout borderLayout3 = new BorderLayout();
  JLabel jLabel19 = new JLabel();
  JLabel jLabel22 = new JLabel();
  JLabel jLabel24 = new JLabel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JLabel jLabel26 = new JLabel();
  BorderLayout borderLayout4 = new BorderLayout();
  JLabel jLabel27 = new JLabel();
  JLabel jLabel28 = new JLabel();
  JLabel jLabel29 = new JLabel();
  JScrollPane jScrollPane2 = new JScrollPane();
  BorderLayout borderLayout5 = new BorderLayout();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel7 = new JPanel();
  JButton btnGetUserDisputes = new JButton();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel30 = new JLabel();
  JLabel jLabel31 = new JLabel();
  JComboBox cbxFilter = new JComboBox();
  JLabel jLabel32 = new JLabel();
  JLabel jLabel33 = new JLabel();
  JLabel jLabel34 = new JLabel();
  JTextField txtPageNumber = new JTextField();
  JLabel jLabel35 = new JLabel();
  JLabel jLabel36 = new JLabel();
  JComboBox cbxSortType = new JComboBox();
  JLabel jLabel37 = new JLabel();
  JComboBox cbxSortOrder = new JComboBox();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JTextField txtStartDisputeNumber = new JTextField();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel18 = new JLabel();
  JTextField txtEndDisputeNumber = new JTextField();
  JLabel jLabel25 = new JLabel();
  JLabel jLabel38 = new JLabel();
  JLabel jLabel39 = new JLabel();
  JTextField txtTotalPage = new JTextField();

  public DialogGetUserDisputes(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetUserDisputes() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    this.setModal(true);
    this.setTitle("eBay SDK for Java - GetUserDisputes");

    jPanel1.setLayout(borderLayout2);
    jPanel2.setLayout(borderLayout5);
    jLabel6.setRequestFocusEnabled(true);
    jLabel6.setText("          ");
    jLabel7.setText("");
    jLabel2.setText("");
    jLabel4.setText("");

    jLabel11.setText("  ");
    jLabel12.setText("  ");
    jLabel14.setText("");
    jLabel13.setText("  ");

    jLabel20.setRequestFocusEnabled(true);
    jLabel20.setText("          ");
    jLabel21.setText("   ");
    jLabel1.setText("      ");
    jLabel3.setText("       ");
    jLabel5.setText("           ");
    jLabel23.setText("    ");
    jLabel8.setRequestFocusEnabled(true);
    jLabel8.setText("  ");
    jPanel3.setMinimumSize(new Dimension(600, 250));
    jPanel3.setLayout(borderLayout3);
    jLabel16.setMaximumSize(new Dimension(113, 25));
    jLabel16.setMinimumSize(new Dimension(113, 25));
    jLabel16.setPreferredSize(new Dimension(113, 25));
    jLabel16.setText("    Dispute from buyers:");
    jLabel19.setText("  ");
    jLabel22.setText("  ");
    jLabel24.setText("    ");
    jLabel26.setMaximumSize(new Dimension(105, 25));
    jLabel26.setMinimumSize(new Dimension(105, 25));
    jLabel26.setPreferredSize(new Dimension(105, 25));
    jLabel26.setText("  Dispute from sellers:");
    jPanel4.setLayout(borderLayout4);
    jLabel27.setText("  ");
    jLabel28.setText("    ");
    jLabel29.setText("  ");
    jScrollPane1.getViewport().setBackground(Color.white);
    jScrollPane2.getViewport().setBackground(Color.white);
    btnGetUserDisputes.setText("GetUserDisputes");
    btnGetUserDisputes.addActionListener(new DialogGetUserDisputes_btnGetUserDisputes_actionAdapter(this));
    jPanel5.setLayout(gridBagLayout1);
    jLabel30.setText("Filter:");
    jLabel31.setText("        ");
    jLabel32.setText("        ");
    jLabel33.setText("PageNumber:");
    jLabel34.setText("        ");
    txtPageNumber.setPreferredSize(new Dimension(80, 21));
    jLabel35.setText("        ");
    jLabel36.setText("SortType:");
    jLabel37.setText("SortOrder:");
    cbxSortType.setActionCommand("comboBoxChanged");
    jPanel6.setBorder(BorderFactory.createEtchedBorder());
    jPanel6.setLayout(gridBagLayout2);
    jLabel9.setText("StartDisputeNumber:");
    jLabel10.setText("  ");
    jLabel15.setText("        ");
    jLabel17.setText("EndDisputeNumber:");
    jLabel18.setText("  ");
    jLabel25.setText("        ");
    jLabel38.setText("TotalPage:");
    jLabel39.setText("  ");
    txtEndDisputeNumber.setBackground(UIManager.getColor("Button.background"));
    txtEndDisputeNumber.setMinimumSize(new Dimension(100, 21));
    txtEndDisputeNumber.setPreferredSize(new Dimension(100, 21));
    txtEndDisputeNumber.setText("");
    txtStartDisputeNumber.setBackground(UIManager.getColor("Button.background"));
    txtStartDisputeNumber.setMaximumSize(new Dimension(2147483647, 2147483647));
    txtStartDisputeNumber.setMinimumSize(new Dimension(100, 21));
    txtStartDisputeNumber.setPreferredSize(new Dimension(100, 21));
    txtStartDisputeNumber.setText("");
    txtTotalPage.setBackground(UIManager.getColor("Button.background"));
    txtTotalPage.setMinimumSize(new Dimension(60, 21));
    txtTotalPage.setPreferredSize(new Dimension(60, 21));
    txtTotalPage.setText("");
    txtTotalPage.setColumns(0);
    jPanel2.add(jLabel6, BorderLayout.EAST);
    jPanel2.add(jLabel11, BorderLayout.EAST);
    jPanel2.add(jLabel12, BorderLayout.EAST);
    jPanel2.add(jLabel13, BorderLayout.EAST);
    jPanel2.add(jLabel14, BorderLayout.WEST);

    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jPanel1.add(jPanel4, BorderLayout.SOUTH);
    jPanel4.add(jLabel26, BorderLayout.NORTH);
    jPanel4.add(jLabel27, BorderLayout.WEST);
    jPanel4.add(jLabel28, BorderLayout.SOUTH);
    jPanel4.add(jLabel29, BorderLayout.EAST);
    jPanel4.add(jScrollPane2, BorderLayout.CENTER);
    jPanel4.setBorder(BorderFactory.createEtchedBorder());

    jPanel1.add(jPanel3, BorderLayout.CENTER);
    jPanel3.add(jLabel19, BorderLayout.WEST);
    jPanel3.add(jLabel22, BorderLayout.EAST);
    jPanel3.add(jLabel24, BorderLayout.SOUTH);
    jPanel3.add(jScrollPane1, BorderLayout.CENTER);
    jPanel3.add(jLabel16, BorderLayout.NORTH);
    jPanel3.setBorder(BorderFactory.createEtchedBorder());

    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel2.add(jLabel1, BorderLayout.EAST);
    jPanel2.add(jLabel3, BorderLayout.EAST);
    jPanel2.add(jLabel5, BorderLayout.EAST);
    jPanel2.add(jLabel8, BorderLayout.EAST);
    jPanel2.add(jPanel5, BorderLayout.NORTH);
    jPanel5.add(jLabel30,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel31, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(cbxFilter,  new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel32, new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel33,  new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel34, new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(txtPageNumber,  new GridBagConstraints(6, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel35, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel36,  new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(cbxSortType,  new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel37,  new GridBagConstraints(4, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(cbxSortOrder,  new GridBagConstraints(6, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jPanel7, BorderLayout.CENTER);
    jPanel7.add(btnGetUserDisputes, null);
    jPanel2.add(jPanel6, BorderLayout.SOUTH);
    jPanel6.add(jLabel9,  new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel10,  new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(txtStartDisputeNumber,  new GridBagConstraints(2, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel15,  new GridBagConstraints(3, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel17,  new GridBagConstraints(4, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel18,  new GridBagConstraints(5, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(txtEndDisputeNumber,  new GridBagConstraints(6, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel25,  new GridBagConstraints(7, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel38,  new GridBagConstraints(8, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(jLabel39,  new GridBagConstraints(9, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel6.add(txtTotalPage,  new GridBagConstraints(10, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

    ComboBoxModel dataModel = new DefaultComboBoxModel(DialogGetUserDisputes.filters);
    this.cbxFilter.setModel(dataModel);
    this.cbxFilter.setSelectedIndex(0);

    dataModel = new DefaultComboBoxModel(DialogGetUserDisputes.sortTypes);
    this.cbxSortType.setModel(dataModel);
    this.cbxSortType.setSelectedIndex(0);

    dataModel = new DefaultComboBoxModel(DialogGetUserDisputes.sortOrder);
    this.cbxSortOrder.setModel(dataModel);
    this.cbxSortOrder.setSelectedIndex(0);

    jPanel2.setPreferredSize(new Dimension(600, 200));
    jPanel3.setPreferredSize(new Dimension(600, 200));
    jPanel4.setPreferredSize(new Dimension(600, 200));
    jPanel1.setPreferredSize(new Dimension(600, 600));
    jPanel5.setPreferredSize(new Dimension(600, 100));
    jPanel6.setPreferredSize(new Dimension(600, 50));
    jPanel7.setPreferredSize(new Dimension(600, 50));

    this.setSize(new Dimension(600, 600));
  }

  void displayDisputes(DisputeType[] disputes)
  {
    int size = disputes != null ? disputes.length : 0;

      String[] colDisputeFromSellers = {
          "DisputeId", "ItemId", "TransactionId", "CreateTime", "CreditEligibility", "Seller"};

      String[] colDisputeFromBuyers = {
          "DisputeId", "ItemId", "TransactionId", "CreateTime", "CreditEligibility", "Buyer"};

      ArrayList buyerList = new ArrayList();
      ArrayList sellerList = new ArrayList();
      for (int i = 0; i < size; i++) {
        DisputeType dispute = disputes[i];
        String role = dispute.getOtherPartyRole().getValue().toString();
        if (BUYER.equals(role)) {
          buyerList.add(dispute);
        }
        else if (SELLER.equals(role)) {
          sellerList.add(dispute);
        }
      }

      size = buyerList.size();
      if (size > 0) {
        Object[][] dataTable = new Object[size][6];
        for (int i = 0; i < size; i++) {
          DisputeType dispute = disputes[i];
          dataTable[i][0] = dispute.getDisputeID().getValue();
          dataTable[i][1] = dispute.getItem().getItemID().getValue();
          dataTable[i][2] = dispute.getTransactionID();
          dataTable[i][3] = eBayUtil.toAPITimeString(dispute.
              getDisputeCreatedTime().getTime());
          dataTable[i][4] = dispute.getDisputeCreditEligibility().getValue().
              toString();
          UserIDType userId = dispute.getBuyerUserID();
          String user = "";
          if (userId != null) {
            user = userId.getValue();
          }
          dataTable[i][5] = user;
        }
        JTable jTable1 = new JTable(dataTable, colDisputeFromBuyers);
        this.jScrollPane1.getViewport().add(jTable1, null);
      }
      else {
        Object[][] dataTable = new Object[1][6];
        JTable jTable1 = new JTable(dataTable, colDisputeFromBuyers);
        this.jScrollPane1.getViewport().add(jTable1, null);
      }

      size = sellerList.size();
      if (size > 0) {
        Object[][] dataTable = new Object[size][6];
        for (int i = 0; i < size; i++) {
          DisputeType dispute = disputes[i];
          dataTable[i][0] = dispute.getDisputeID().getValue();
          dataTable[i][1] = dispute.getItem().getItemID().getValue();
          dataTable[i][2] = dispute.getTransactionID();
          dataTable[i][3] = eBayUtil.toAPITimeString(dispute.
              getDisputeCreatedTime().getTime());
          dataTable[i][4] = dispute.getDisputeCreditEligibility().getValue().
              toString();
          dataTable[i][5] = dispute.getOtherPartyName();
        }
        JTable jTable2 = new JTable(dataTable, colDisputeFromSellers);
        this.jScrollPane2.getViewport().add(jTable2, null);
      }
      else {
        Object[][] dataTable = new Object[1][6];
        JTable jTable2 = new JTable(dataTable, colDisputeFromSellers);
        this.jScrollPane2.getViewport().add(jTable2, null);
      }

  }

  void btnGetUserDisputes_actionPerformed(ActionEvent e) {
    try {
      int idx = this.cbxFilter.getSelectedIndex();
      DisputeFilterTypeCodeType filterType = (DisputeFilterTypeCodeType)
          DialogGetUserDisputes.filters[idx].Tag;

      idx = this.cbxSortOrder.getSelectedIndex();
      SortOrderCodeType sortOrder = (SortOrderCodeType) DialogGetUserDisputes.
          sortOrder[idx].Tag;

      idx = this.cbxSortType.getSelectedIndex();
      DisputeSortTypeCodeType sortType = (DisputeSortTypeCodeType)
          DialogGetUserDisputes.sortTypes[idx].Tag;

      String pageNumber = this.txtPageNumber.getText().trim();
      if (pageNumber == null || pageNumber.length() == 0) {
        pageNumber = "0";
      }
      GetUserDisputesCall api = new GetUserDisputesCall(this.apiContext);
      api.setDisputeFilterType(filterType);
      api.setDisputeSortType(sortType);
      PaginationType pt = new PaginationType();
      pt.setPageNumber(new Integer(pageNumber));
      pt.setEntriesPerPage(new Integer(100));
      api.setPagination(pt);

      GetUserDisputesResponseType resp = api.getUserDisputes();
      this.txtEndDisputeNumber.setText(resp.getEndingDisputeID().getValue());
      this.txtStartDisputeNumber.setText(resp.getStartingDisputeID().getValue());
      DisputeType[] disputes = resp.getDisputeArray().getDispute();
      displayDisputes(disputes);
    }
    catch(Exception ex) {
      ((FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }

  String BUYER = "Buyer";
  String SELLER = "Seller";
}

class DialogGetUserDisputes_btnGetUserDisputes_actionAdapter implements java.awt.event.ActionListener {
  DialogGetUserDisputes adaptee;

  DialogGetUserDisputes_btnGetUserDisputes_actionAdapter(DialogGetUserDisputes adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnGetUserDisputes_actionPerformed(e);
  }
}
