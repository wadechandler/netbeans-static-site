/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.util.Calendar;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.event.*;
import javax.swing.tree.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;
import com.ebay.sdk.helper.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: eBay Inc.</p>
 * @author not attributable
 * @version 1.0
 */

public class DialogGetItemShipping extends JDialog {
  private ApiContext apiContext = new ApiContext();

  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JButton btnGetItemShipping = new JButton();

  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel2 = new JPanel();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel8 = new JPanel();
  JPanel jPanel9 = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField txtItemId = new JTextField();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JTextField txtQuantitySold = new JTextField();
  JLabel jLabel8 = new JLabel();
  GridBagLayout gridBagLayout3 = new GridBagLayout();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JComboBox cbxCountryCode = new JComboBox();
  JLabel jLabel9 = new JLabel();
  JTextField txtPostalCode = new JTextField();
  BorderLayout borderLayout6 = new BorderLayout();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JScrollPane jScrollPane1 = new JScrollPane();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel16 = new JLabel();
  JTextField txtShippingType = new JTextField();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel18 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JTextField txtCurrency = new JTextField();
  JLabel jLabel20 = new JLabel();
  JLabel jLabel21 = new JLabel();
  JLabel jLabel22 = new JLabel();
  JLabel jLabel23 = new JLabel();
  JLabel jLabel24 = new JLabel();
  JLabel jLabel25 = new JLabel();
  JTextField txtShipFromZipCode = new JTextField();
  JTextField txtPackageHandlingCost = new JTextField();
  JTextField txtShippingRateType = new JTextField();
  JTextField txtShippingPackage = new JTextField();
  JTextField txtInsuranceFee = new JTextField();
  JTextField txtShippingIrregular = new JTextField();
  JLabel jLabel28 = new JLabel();
  JLabel jLabel29 = new JLabel();
  JLabel jLabel30 = new JLabel();

  public DialogGetItemShipping(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetItemShipping() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    this.setModal(true);
    this.setTitle("eBay SDK for Java - GetItemShipping");
    jPanel1.setLayout(borderLayout2);
    jPanel3.setLayout(borderLayout3);
    btnGetItemShipping.setText("GetItemShipping");
    btnGetItemShipping.addActionListener(new DialogGetItemShipping_btnGetItemShipping_actionAdapter(this));
    jPanel6.setLayout(borderLayout6);
    jPanel6.setBorder(BorderFactory.createEtchedBorder());
    jPanel5.setMinimumSize(new Dimension(10, 1));
    jPanel5.setPreferredSize(new Dimension(10, 1));
    jPanel2.setLayout(borderLayout4);
    jPanel7.setLayout(gridBagLayout1);
    jLabel1.setText("ItemID:");
    jLabel2.setText("        ");
    txtItemId.setPreferredSize(new Dimension(120, 21));
    jLabel3.setText("  ");
    jLabel4.setText("QuantitySold:");
    jLabel5.setText("  ");
    txtQuantitySold.setPreferredSize(new Dimension(120, 21));
    txtQuantitySold.setText("");
    jLabel8.setText("Destination PostalCode:");
    jPanel8.setLayout(gridBagLayout3);
    jLabel10.setText("  ");
    jLabel11.setText("    ");
    jLabel12.setText("Destination CountryCode:");
    jLabel9.setText("  ");
    jPanel4.setBorder(null);
    jPanel9.setLayout(gridBagLayout2);
    jPanel9.setBorder(BorderFactory.createEtchedBorder());
    jPanel9.setMaximumSize(new Dimension(32767, 32767));
    txtPostalCode.setPreferredSize(new Dimension(120, 21));
    jLabel6.setText(" ");
    jLabel7.setText(" ");
    jLabel13.setPreferredSize(new Dimension(10, 1));
    jLabel13.setText(" ");
    jLabel14.setPreferredSize(new Dimension(3, 1));
    jLabel14.setText(" ");
    jScrollPane1.getViewport().setBackground(Color.white);
    jScrollPane1.setPreferredSize(new Dimension(1, 4));
    jLabel15.setText("ShippingType");
    jLabel16.setToolTipText("");
    jLabel16.setText("  ");
    txtShippingType.setBackground(Color.lightGray);
    txtShippingType.setPreferredSize(new Dimension(60, 21));
    txtShippingType.setText("");
    jLabel17.setText("        ");
    jLabel18.setText("Currency:");
    jLabel19.setText("    ");
    txtCurrency.setBackground(Color.lightGray);
    txtCurrency.setPreferredSize(new Dimension(60, 21));
    txtCurrency.setText("");
    jLabel20.setText("    ");
    jLabel21.setText("ShipFromZipCode:");
    jLabel22.setText("    ");
    jLabel23.setText("ShippingRateType:");
    jLabel24.setText("    ");
    jLabel25.setText("ShippingPackage:");
    txtShipFromZipCode.setBackground(Color.lightGray);
    txtShipFromZipCode.setPreferredSize(new Dimension(60, 21));
    txtShipFromZipCode.setText("");
    txtPackageHandlingCost.setBackground(Color.lightGray);
    txtPackageHandlingCost.setPreferredSize(new Dimension(60, 21));
    txtPackageHandlingCost.setText("");
    txtShippingRateType.setBackground(Color.lightGray);
    txtShippingRateType.setPreferredSize(new Dimension(60, 21));
    txtShippingRateType.setSelectedTextColor(Color.white);
    txtShippingRateType.setText("");
    txtShippingPackage.setBackground(Color.lightGray);
    txtShippingPackage.setMinimumSize(new Dimension(6, 21));
    txtShippingPackage.setPreferredSize(new Dimension(60, 21));
    txtShippingPackage.setText("");
    txtInsuranceFee.setBackground(Color.lightGray);
    txtInsuranceFee.setPreferredSize(new Dimension(60, 21));
    txtInsuranceFee.setText("");
    txtShippingIrregular.setBackground(Color.lightGray);
    txtShippingIrregular.setPreferredSize(new Dimension(60, 21));
    txtShippingIrregular.setText("");
    jLabel28.setText("PackageHandlingCost:");
    jLabel29.setText("InsuranceFee:");
    jLabel30.setText("ShippingIrregular:");
    jPanel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(jPanel4, BorderLayout.NORTH);
    jPanel3.add(jPanel5, BorderLayout.SOUTH);
    jPanel3.add(jPanel6, BorderLayout.CENTER);
    jPanel6.add(jLabel6, BorderLayout.WEST);
    jPanel6.add(jLabel7, BorderLayout.EAST);
    jPanel6.add(jLabel13, BorderLayout.NORTH);
    jPanel6.add(jLabel14, BorderLayout.SOUTH);
    jPanel6.add(jScrollPane1, BorderLayout.CENTER);
    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(jPanel7, BorderLayout.NORTH);
    jPanel7.add(jLabel1,    new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel2,   new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(txtItemId,    new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel3,   new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel4,    new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel5,   new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(txtQuantitySold,    new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel8,    new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel11,   new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel12,    new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(cbxCountryCode,    new GridBagConstraints(2, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel7.add(jLabel9,   new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jPanel9, BorderLayout.SOUTH);
    jPanel9.add(jLabel15,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel16, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(txtShippingType,  new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel17, new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel19, new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel20, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel22, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel23,  new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel24, new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(txtPackageHandlingCost,  new GridBagConstraints(6, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(txtShippingRateType,  new GridBagConstraints(2, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(txtShippingIrregular,  new GridBagConstraints(6, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel28,  new GridBagConstraints(4, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel30,  new GridBagConstraints(4, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel25,  new GridBagConstraints(4, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(txtShippingPackage, new GridBagConstraints(6, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel29, new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(txtInsuranceFee, new GridBagConstraints(2, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel18, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(txtCurrency, new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(jLabel21, new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel9.add(txtShipFromZipCode, new GridBagConstraints(6, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jPanel8, BorderLayout.CENTER);
    jPanel8.add(jLabel10,     new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel8.add(btnGetItemShipping,  new GridBagConstraints(1, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel7.add(txtPostalCode,  new GridBagConstraints(2, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    ComboBoxModel dataModel = new DefaultComboBoxModel(ControlEntryTypes.countryCodes);
    this.cbxCountryCode.setModel(dataModel);
    this.cbxCountryCode.setSelectedIndex(0);
    jPanel2.setPreferredSize(new Dimension(420, 350));
    jPanel3.setPreferredSize(new Dimension(420, 120));
    jPanel4.setPreferredSize(new Dimension(420, 1));
    jPanel6.setPreferredSize(new Dimension(420, 70));
    jPanel7.setPreferredSize(new Dimension(420, 155));
    jPanel8.setPreferredSize(new Dimension(420, 25));
    jPanel9.setPreferredSize(new Dimension(420, 155));
    this.setSize(new Dimension(420, 470));
    this.setResizable(false);
  }

  void btnGetItemShipping_actionPerformed(ActionEvent e)
  {
    try {
      String itemId = this.txtItemId.getText().trim();
      String quantitySold = this.txtQuantitySold.getText().trim();
      String postalCode = this.txtPostalCode.getText().trim();

      if (itemId.length() < 1 || quantitySold.length() < 1 || postalCode.length() < 1) {
          throw new Exception("ItemId, QuantirySold and PostalCode are required inputs.");
      }

      CountryCodeType cct = (CountryCodeType) ((ControlTagItem)this.cbxCountryCode.getSelectedItem()).Tag;

      DetailLevelCodeType[] detailLevels = new DetailLevelCodeType[] {
          DetailLevelCodeType.ReturnAll,
          DetailLevelCodeType.ItemReturnAttributes,
          DetailLevelCodeType.ItemReturnDescription
      };

      GetItemShippingCall api = new GetItemShippingCall(this.apiContext);
      api.setDetailLevel(detailLevels);
      api.setQuantitySold(new Integer(quantitySold));
      api.setItemID(new ItemIDType(itemId));
      api.setDestinationCountryCode(cct);
      api.setDestinationPostalCode(postalCode);
      ShippingDetailsType shippingDetails = api.getItemShipping();
      displayItemShipping(shippingDetails);
    }
    catch (Exception ex) {
      ( (FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }

  void displayItemShipping(ShippingDetailsType shippingDetails)
  {
    CurrencyCodeType currencyId = null;

    ShippingTypeCodeType shippingType = shippingDetails.getShippingType();
    if (shippingType != null) {
      this.txtShippingType.setText(shippingType.getValue().toString());
    }
    AmountType insuranceFee = shippingDetails.getInsuranceFee();
    if (insuranceFee != null) {
        currencyId = insuranceFee.getCurrencyID();
      this.txtInsuranceFee.setText(new Double(insuranceFee.getValue()).toString());
    }
    ShippingRateTypeCodeType shippingRateType = shippingDetails.getShippingRateType();
    if (shippingRateType != null) {
      this.txtShippingRateType.setText(shippingRateType.getValue().toString());
    }
    if (shippingType == ShippingTypeCodeType.Calculated) {
      CalculatedShippingRateType csr = shippingDetails.getCalculatedShippingRate();
      this.txtShipFromZipCode.setText(csr.getOriginatingPostalCode());
      this.txtShippingIrregular.setText(csr.getShippingIrregular().toString());
      this.txtShippingPackage.setText(csr.getShippingPackage().getValue().toString());
      AmountType costs = csr.getPackagingHandlingCosts();
      if (costs != null) {
        this.txtPackageHandlingCost.setText(new Double(costs.getValue()).toString());
        if (currencyId == null) {
          currencyId = costs.getCurrencyID();
        }
      }
    }
    if (currencyId != null) {
      this.txtCurrency.setText(currencyId.getValue().toString());
    }
    DefaultMutableTreeNode root =  new DefaultMutableTreeNode("ShippingRate");
    ShippingServiceOptionTreeBuilder builder = ShippingServiceOptionTreeBuilder.getInstance();
    root.add(builder.buildShippingServiceOptionTree(shippingType, shippingDetails.getShippingServiceOptions()));
    root.add(builder.buildShippingServiceOptionTree(shippingType, shippingDetails.getInternationalShippingServiceOption()));

    JTree jTree1 = new JTree(root);
    jTree1.setEditable(false);
    jTree1.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
    jTree1.setShowsRootHandles(true);
    jTree1.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent e) {
      }
    });

    this.jScrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    this.jScrollPane1.setViewportBorder(BorderFactory.createEtchedBorder());
    this.jScrollPane1.getViewport().add(jTree1, null);
  }
}

class DialogGetItemShipping_btnGetItemShipping_actionAdapter implements java.awt.event.ActionListener {
  DialogGetItemShipping adaptee;

  DialogGetItemShipping_btnGetItemShipping_actionAdapter(DialogGetItemShipping adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnGetItemShipping_actionPerformed(e);
  }
}
