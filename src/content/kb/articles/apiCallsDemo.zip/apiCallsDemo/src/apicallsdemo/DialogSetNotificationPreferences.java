/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.util.Date;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;
import org.apache.axis.types.URI;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.sdk.util.*;
import com.ebay.soap.eBLBaseComponents.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: eBay Inc.</p>
 * @author not attributable
 * @version 1.0
 */

public class DialogSetNotificationPreferences extends JDialog
{
  private ApiContext apiContext = new ApiContext();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel23 = new JLabel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel4 = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField txtDeliveryURL = new JTextField();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  GridBagLayout gridBagLayout3 = new GridBagLayout();
  JButton btnSetNotificationPreferences = new JButton();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JComboBox cbxDeliveryURLStatus = new JComboBox();
  JComboBox cbxNotificationEventStatus = new JComboBox();
  JComboBox cbxNotificationEvent = new JComboBox();
  JTextField txtCallStatus = new JTextField();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JTextField txteBayTime = new JTextField();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel14 = new JLabel();

  public DialogSetNotificationPreferences(Frame frame, String title, boolean modal) {
      super(frame, title, modal);
    try {
      jbInit();
      customInit();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogSetNotificationPreferences() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    this.setModal(true);
    this.setTitle("eBay SDK for Java - SetNotificationPreferences");
    jPanel1.setLayout(borderLayout2);
    jPanel3.setLayout(gridBagLayout2);
    jLabel23.setText("CallStatus:");
    jPanel2.setLayout(gridBagLayout1);
    jLabel1.setText("DeliveryURL:");
    jLabel2.setText("    ");
    txtDeliveryURL.setPreferredSize(new Dimension(200, 21));
    jLabel4.setText("NotificationEvent:");
    jLabel5.setText("       ");
    jLabel3.setText("          ");
    jPanel4.setLayout(gridBagLayout3);
    btnSetNotificationPreferences.setText("SetNotificationPreferences");
    btnSetNotificationPreferences.addActionListener(new DialogSetNotificationPreferences_btnSetNotificationPreferences_actionAdapter(this));
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jLabel7.setText("        ");
    jLabel9.setText("Status:");
    jLabel10.setText("    ");
    jLabel11.setText("        ");
    txtCallStatus.setBackground(UIManager.getColor("Button.background"));
    txtCallStatus.setPreferredSize(new Dimension(80, 21));
    txtCallStatus.setText("");
    txtCallStatus.setScrollOffset(0);
    jLabel12.setText("    ");
    jLabel13.setText("Status:");
    jLabel6.setText("        ");
    jLabel8.setText("    ");
    txteBayTime.setBackground(UIManager.getColor("Button.background"));
    txteBayTime.setPreferredSize(new Dimension(120, 21));
    txteBayTime.setDisabledTextColor(UIManager.getColor("Button.background"));
    txteBayTime.setText("");
    jLabel14.setText("eBayTime:");
    jPanel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(jLabel23,                  new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel3.add(txtCallStatus,        new GridBagConstraints(6, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel3.add(jLabel12,         new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel3.add(jLabel6,    new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel3.add(txteBayTime,   new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel3.add(jLabel8,  new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel3.add(jLabel14,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(jLabel1,   new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel2, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtDeliveryURL,  new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel3, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel4,  new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel5, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel7, new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel9,  new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel10, new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel11, new GridBagConstraints(6, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(cbxDeliveryURLStatus,  new GridBagConstraints(6, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(cbxNotificationEventStatus,  new GridBagConstraints(6, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(cbxNotificationEvent,  new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel13,  new GridBagConstraints(4, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel1.add(jPanel4, BorderLayout.CENTER);
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel4.add(btnSetNotificationPreferences, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

    jPanel2.setPreferredSize(new Dimension(500, 110));
    jPanel3.setPreferredSize(new Dimension(500, 50));
    jPanel4.setPreferredSize(new Dimension(500, 30));
    this.setSize(new Dimension(500, 220));
    this.setResizable(false);
  }

  void btnSetNotificationPreferences_actionPerformed(ActionEvent e)
  {
    try
    {
      DetailLevelCodeType[] detailLevels = new DetailLevelCodeType[] {
          DetailLevelCodeType.ReturnAll,
          DetailLevelCodeType.ItemReturnAttributes,
          DetailLevelCodeType.ItemReturnDescription
      };

      SetNotificationPreferencesCall api = new SetNotificationPreferencesCall(this.
          apiContext);
      api.setDetailLevel(detailLevels);

      ApplicationDeliveryPreferencesType appDeliveryPref = new
          ApplicationDeliveryPreferencesType();

      String sUrl = this.txtDeliveryURL.getText().trim();
      if (sUrl.length() > 0) {
        int idx = this.cbxDeliveryURLStatus.getSelectedIndex();
        EnableCodeType deliveryURLStatus = (EnableCodeType) ((ControlTagItem)this.cbxDeliveryURLStatus.getSelectedItem()).Tag;
        URI uri = new URI();
        if (sUrl.indexOf("@") > 0) {
          uri.setScheme("mailto");
          if (sUrl.startsWith("mailto:")) {
            uri.setPath(sUrl.substring(7));
          }
          else {
            uri.setPath(sUrl);
          }
        }
        else {
          uri.setScheme("http");
          if (sUrl.startsWith("http:")) {
            uri.setPath(sUrl.substring(5));
          }
          else {
            uri.setPath("//" + sUrl);
          }
        }
        appDeliveryPref.setApplicationURL(uri);
        appDeliveryPref.setApplicationEnable(deliveryURLStatus);
        api.setApplicationDeliveryPreferences(appDeliveryPref);
      }

      int idx = this.cbxNotificationEvent.getSelectedIndex();
      if (idx > 0) {
        NotificationEventTypeCodeType net = (NotificationEventTypeCodeType)
            ControlEntryTypes.notificationEvents[idx].Tag;
        idx = this.cbxNotificationEventStatus.getSelectedIndex();
        EnableCodeType eventStatus = (EnableCodeType)
            ControlEntryTypes.enabledStatus[idx].Tag;
        NotificationEnableType notification = new NotificationEnableType();
        notification.setEventType(net);
        notification.setEventEnable(eventStatus);
        NotificationEnableArrayType neat = new NotificationEnableArrayType();
        neat.setNotificationEnable(new NotificationEnableType[] {notification});
        api.setUserDeliveryPreferenceArray(neat);
      }

      SetNotificationPreferencesResponseType resp = api.setNotificationPreferences();
      Date dt = resp.getTimestamp().getTime();
      this.txteBayTime.setText(eBayUtil.toAPITimeString(dt));
      this.txtCallStatus.setText(resp.getAck().getValue().toString());
    }
    catch(Exception ex)
    {
      this.txteBayTime.setText(eBayUtil.toAPITimeString(new Date()));
      this.txtCallStatus.setText("Failure");
      ((FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }

  void customInit()
  {
    ComboBoxModel dataModel = new DefaultComboBoxModel(ControlEntryTypes.enabledStatus);
    this.cbxDeliveryURLStatus.setModel(dataModel);
    this.cbxDeliveryURLStatus.setSelectedIndex(0);

    dataModel = new DefaultComboBoxModel(ControlEntryTypes.enabledStatus);
    this.cbxNotificationEventStatus.setModel(dataModel);
    this.cbxNotificationEventStatus.setSelectedIndex(0);

    dataModel = new DefaultComboBoxModel(ControlEntryTypes.notificationEvents);
    this.cbxNotificationEvent.setModel(dataModel);
    this.cbxNotificationEvent.setSelectedIndex(0);
  }
}

class DialogSetNotificationPreferences_btnSetNotificationPreferences_actionAdapter implements java.awt.event.ActionListener {
  DialogSetNotificationPreferences adaptee;

  DialogSetNotificationPreferences_btnSetNotificationPreferences_actionAdapter(DialogSetNotificationPreferences adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnSetNotificationPreferences_actionPerformed(e);
  }
}
