/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
			  All rights reserved."

*/

package apicallsdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;

public class DialogGetSellerTransactions extends JDialog {
  private ApiContext apiContext = new ApiContext();

  final static int totalColumns = 9;
  final static String[] colNames = new String[] {
      "TransactionID", "ItemID", "Price", "AmountPaid", "QtyPurchased", "Buyer",
      "No. ShippingServices", "No. Intl ShippingServices", "InsuranceWanted"};

  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  JPanel jPanelModifiedTime = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel8 = new JPanel();
  JTextField txtTransPerPage = new JTextField();
  JLabel jLabel1 = new JLabel();
  JTextField txtPageNumber = new JTextField();
  JLabel jLabel2 = new JLabel();
  JPanel jPanel9 = new JPanel();
  JPanel jPanel10 = new JPanel();
  JTextField txtModTimeFrom = new JTextField();
  JLabel jLabel3 = new JLabel();
  JTextField txtModTimeTo = new JTextField();
  JLabel jLabel4 = new JLabel();
  JButton btnCallGetSellerTransactions = new JButton();
  JPanel jPanel5 = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  JTextField txtTotalNumberOfPages = new JTextField();
  JLabel jLabel12 = new JLabel();
  JPanel jPanel22 = new JPanel();
  JLabel jLabel11 = new JLabel();
  JPanel jPanel19 = new JPanel();
  JLabel jLabel7 = new JLabel();
  JTextField txtCount = new JTextField();
  JPanel jPanel18 = new JPanel();
  JTextField txtReturnedItemCountActual = new JTextField();
  JTextField txtHasMoreItems = new JTextField();
  JPanel jPanel21 = new JPanel();
  BorderLayout borderLayout5 = new BorderLayout();
  JPanel jPanel14 = new JPanel();
  JPanel jPanel20 = new JPanel();
  JPanel jPanel11 = new JPanel();
  JLabel jLabel10 = new JLabel();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel13 = new JPanel();
  JPanel jPanel15 = new JPanel();
  JPanel jPanel16 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable tblTransactions = new JTable();

  public DialogGetSellerTransactions(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();

      GuiUtil.setTimeFilterFields(5, this.txtModTimeFrom, this.txtModTimeTo);

    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetSellerTransactions() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jPanel3.setLayout(borderLayout2);
    jLabel1.setToolTipText("");
    jLabel1.setText("TransactionsPerPage:");
    jLabel2.setText("PageNumber:");
    txtTransPerPage.setPreferredSize(new Dimension(60, 21));
    txtTransPerPage.setText("");
    txtPageNumber.setPreferredSize(new Dimension(60, 21));
    txtPageNumber.setText("");
    txtModTimeFrom.setPreferredSize(new Dimension(120, 21));
    txtModTimeFrom.setText("");
    jLabel3.setText("ModifiedTimeFrom:");
    jLabel4.setText("ModifiedTimeTo:");
    txtModTimeTo.setPreferredSize(new Dimension(120, 21));
    txtModTimeTo.setText("");
    btnCallGetSellerTransactions.setText("GetSellerTransactions");
    btnCallGetSellerTransactions.addActionListener(new DialogGetSellerTransactions_btnCallGetSellerTransactions_actionAdapter(this));
    jPanel1.setLayout(borderLayout3);
    jPanel5.setLayout(borderLayout4);
    txtTotalNumberOfPages.setText("");
    txtTotalNumberOfPages.setEditable(false);
    txtTotalNumberOfPages.setPreferredSize(new Dimension(60, 21));
    jLabel12.setText("ReturnedItemCountActual: ");
    jLabel11.setText("Count: ");
    jLabel7.setText("HasMoreItems: ");
    txtCount.setPreferredSize(new Dimension(60, 21));
    txtCount.setEditable(false);
    txtCount.setText("");
    txtReturnedItemCountActual.setPreferredSize(new Dimension(60, 21));
    txtReturnedItemCountActual.setEditable(false);
    txtReturnedItemCountActual.setText("asdf");
    txtReturnedItemCountActual.setText("");
    txtHasMoreItems.setPreferredSize(new Dimension(60, 21));
    txtHasMoreItems.setEditable(false);
    txtHasMoreItems.setText("");
    jPanel14.setLayout(borderLayout5);
    jLabel10.setText("TotalNumberOfPages:");
    jPanel18.setLayout(gridBagLayout2);
    jPanel18.setBorder(BorderFactory.createEtchedBorder());
    jPanel18.setPreferredSize(new Dimension(940, 50));
    jLabel5.setText("    ");
    jLabel6.setText("        ");
    jLabel8.setText("    ");
    jLabel9.setText("        ");
    jLabel13.setText("    ");
    jLabel14.setText("        ");
    jLabel15.setText("    ");
    jPanel11.setPreferredSize(new Dimension(20, 2));
    jScrollPane1.getViewport().setBackground(Color.white);
    jScrollPane1.setDebugGraphicsOptions(0);
    getContentPane().add(panel1, BorderLayout.CENTER);
    panel1.add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel5, BorderLayout.CENTER);

    jPanel5.add(jPanel12, BorderLayout.NORTH);
    jPanel5.add(jPanel13, BorderLayout.EAST);
    jPanel5.add(jPanel15, BorderLayout.SOUTH);
    jPanel5.add(jPanel16, BorderLayout.WEST);
    jPanel5.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(tblTransactions, null);
    jPanel1.add(jPanel14, BorderLayout.NORTH);
    jPanel14.add(jPanel11, BorderLayout.CENTER);
    jPanel11.add(jPanel22, null);
    jPanel14.add(jPanel18, BorderLayout.NORTH);
    jPanel18.add(jLabel7, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel5, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtHasMoreItems, new GridBagConstraints(2, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel6, new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel11, new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel8, new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtCount, new GridBagConstraints(6, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel9, new GridBagConstraints(7, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel10, new GridBagConstraints(8, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel13, new GridBagConstraints(9, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtTotalNumberOfPages, new GridBagConstraints(10, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel14, new GridBagConstraints(11, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel12,  new GridBagConstraints(12, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel15, new GridBagConstraints(13, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtReturnedItemCountActual,  new GridBagConstraints(14, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    panel1.add(jPanel2, BorderLayout.SOUTH);
    panel1.add(jPanel3, BorderLayout.NORTH);
    jPanel3.add(jPanel4,  BorderLayout.NORTH);
    jPanel4.add(jPanel8, null);
    jPanel8.add(jLabel1, null);
    jPanel8.add(txtTransPerPage, null);
    jPanel4.add(jPanel7, null);
    jPanel7.add(jLabel2, null);
    jPanel7.add(txtPageNumber, null);
    jPanel3.add(jPanelModifiedTime, BorderLayout.CENTER);
    jPanelModifiedTime.add(jPanel10, null);
    jPanel10.add(jLabel3, null);
    jPanel10.add(txtModTimeFrom, null);
    jPanelModifiedTime.add(jPanel9, null);
    jPanel9.add(jLabel4, null);
    jPanel9.add(txtModTimeTo, null);
    jPanel3.add(jPanel6, BorderLayout.SOUTH);
    jPanel6.add(btnCallGetSellerTransactions, null);

    this.setSize(new Dimension(950, 500));
  }

  static String[] transactionToColumns(TransactionType trans)
  {
    String[] cols = new String[DialogGetSellerTransactions.totalColumns];
    int i = 0;
    cols[i++] = trans.getTransactionID();
    ItemIDType itemID = trans.getItem().getItemID();
    cols[i++] = itemID == null ? "" : itemID.toString();
    cols[i++] = trans.getTransactionPrice().toString();
    AmountType amt = trans.getAmountPaid();
    cols[i++] = amt == null ? "" : (new Double(amt.getValue())).toString();
    cols[i++] = trans.getQuantityPurchased().toString();
    UserType buyer = trans.getBuyer();
    cols[i++] = buyer == null ? "" : buyer.getUserID().toString();
    ShippingDetailsType shippingDetails = trans.getShippingDetails();
    ShippingServiceOptionsType [] sso = shippingDetails.getShippingServiceOptions();
    int size = sso != null ? sso.length : 0;
    cols[i++] = new Integer(size).toString();
    InternationalShippingServiceOptionsType [] isso = shippingDetails.getInternationalShippingServiceOption();
    size = isso != null ? isso.length : 0;
    cols[i++] = new Integer(size).toString();
    Boolean insuranceWanted = shippingDetails.getInsuranceWanted();
    if (insuranceWanted != null) {
      cols[i] = insuranceWanted.toString();
    }
    return cols;
  }

  void btnCallGetSellerTransactions_actionPerformed(ActionEvent e) {
    try
    {
      GetSellerTransactionsCall api = new GetSellerTransactionsCall(this.apiContext);
      DetailLevelCodeType[] detailLevels = new DetailLevelCodeType[] {
          DetailLevelCodeType.ReturnAll,
      };
      api.setDetailLevel(detailLevels);

      TimeFilter tf = GuiUtil.getTimeFilterFromFields(
          this.txtModTimeFrom, this.txtModTimeTo);

      if( this.txtPageNumber.getText().length() > 0 &&
          this.txtTransPerPage.getText().length() > 0 )
      {
        PaginationType pgn = new PaginationType();
        pgn.setPageNumber(new Integer(this.txtPageNumber.getText()));
        pgn.setEntriesPerPage(new Integer(this.txtTransPerPage.getText()));

        api.setPagination(pgn);
      }

      // Call eBay.
      final TransactionType[] transList = api.getSellerTransactions(tf);

      PaginationResultType pnresult = api.getPaginationResult();

      // Display results.
      this.txtCount.setText(pnresult.getTotalNumberOfEntries().toString());

      this.txtHasMoreItems.setText(api.getHasMoreTransactions() ? "yes" : "no");
      this.txtTotalNumberOfPages.setText(
        pnresult.getTotalNumberOfPages() == null ? "" : pnresult.getTotalNumberOfPages().toString());

      String actualCountTxt = new Integer(api.getReturnedTransactionCountActual()).toString();
      this.txtReturnedItemCountActual.setText(actualCountTxt);

      // Display items in table.
      TableModel dataModel = new AbstractTableModel() {
        public int getColumnCount() { return DialogGetSellerTransactions.totalColumns; }
        public int getRowCount() { return transList == null ? 0 : transList.length;}
        public String getColumnName(int columnIndex){
          return colNames[columnIndex];
        }
        public Object getValueAt(int row, int col)
        {
          TransactionType trans = transList[row];
          return DialogGetSellerTransactions.transactionToColumns(trans)[col];
        }
      };

      this.tblTransactions.setModel(dataModel);
    }
    catch(Exception ex)
    {
      ((FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }
}

class DialogGetSellerTransactions_btnCallGetSellerTransactions_actionAdapter implements java.awt.event.ActionListener {
  DialogGetSellerTransactions adaptee;

  DialogGetSellerTransactions_btnCallGetSellerTransactions_actionAdapter(DialogGetSellerTransactions adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnCallGetSellerTransactions_actionPerformed(e);
  }
}
