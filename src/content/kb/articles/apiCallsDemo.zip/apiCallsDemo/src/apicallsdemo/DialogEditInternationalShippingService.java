/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.soap.eBLBaseComponents.*;
import com.ebay.sdk.helper.*;
import com.ebay.sdk.helper.ui.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: eBay Inc.</p>
 * @author not attributable
 * @version 1.0
 */

public class DialogEditInternationalShippingService extends JDialog
{
  boolean resize;
  InternationalShippingServiceSelector shippingServiceSelector;
  JCheckBox[] cbkShipToLocations = null;

  private ApiContext apiContext = new ApiContext();

  BorderLayout borderLayout1 = new BorderLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;

  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JComboBox cbxShippingService = new JComboBox();
  GridBagLayout gridBagLayout3 = new GridBagLayout();
  JButton btnAdd = new JButton();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JTextField txtShippingServiceCost = new JTextField();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JTextField txtShippingServiceAdditionalCost = new JTextField();
  JButton btnCancel = new JButton();
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel panelShipToLocations = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  BorderLayout borderLayout4 = new BorderLayout();
  JLabel jLabel8 = new JLabel();

  public DialogEditInternationalShippingService(Frame frame, String title, InternationalShippingServiceSelector selector, boolean modal)
  {
    super(frame, title, modal);
    try {
      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
      this.shippingServiceSelector = selector;

      jbInit();
      pack();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  private DialogEditInternationalShippingService() {
    //this(null, "", false);
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    jPanel1.setLayout(borderLayout2);
    this.setModal(true);
    this.setTitle("eBay SDK for Java - Edit International Shipping Service");

    this.jPanel2.setPreferredSize(new Dimension(320, 150));
    jPanel2.setLayout(gridBagLayout2);
    this.jPanel3.setPreferredSize(new Dimension(420, 50));
    jPanel3.setLayout(gridBagLayout3);
    jPanel4.setBorder(BorderFactory.createEtchedBorder());
    jPanel4.setLayout(borderLayout3);

    jLabel1.setText("ShippingService:");
    jLabel2.setText("        ");
    btnAdd.setText("Add");
    btnAdd.addActionListener(new DialogEditInternationalShippingService_btnAdd_actionAdapter(this));
    jLabel3.setText("        ");
    jLabel4.setText("    ");
    jLabel5.setText("ShippingServiceCost:");
    txtShippingServiceCost.setPreferredSize(new Dimension(100, 21));
    jLabel6.setText("   ");
    jLabel7.setText("AdditionalShippingServiceCost:");
    txtShippingServiceAdditionalCost.setMinimumSize(new Dimension(6, 21));
    txtShippingServiceAdditionalCost.setPreferredSize(new Dimension(100, 21));
    txtShippingServiceAdditionalCost.setText("");
    btnCancel.setText("Cancel");
    btnCancel.addActionListener(new DialogEditInternationalShippingService_btnCancel_actionAdapter(this));
    panelShipToLocations.setLayout(gridBagLayout1);
    jPanel5.setBorder(null);
    jPanel5.setPreferredSize(new Dimension(10, 35));
    jPanel5.setLayout(borderLayout4);
    jLabel8.setText("    ShipToLocations:");
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jPanel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(btnAdd, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel3.add(jLabel3, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel3.add(btnCancel, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel1.add(jPanel4, BorderLayout.CENTER);
    jPanel4.add(jPanel5, BorderLayout.NORTH);
    jPanel4.add(jPanel6, BorderLayout.SOUTH);
    jPanel4.add(panelShipToLocations, BorderLayout.CENTER);

    jPanel2.add(jLabel1,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel2,  new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(cbxShippingService,   new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel4, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel5,   new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtShippingServiceCost,   new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel6,  new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(jLabel7,   new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel2.add(txtShippingServiceAdditionalCost,   new GridBagConstraints(2, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel8, BorderLayout.WEST);

    this.buildShipToLocationCheckBoxControls();

    this.setSize(new Dimension(420, 450));
    this.setResizable(false);


    ComboBoxModel dataModel = new DefaultComboBoxModel(this.shippingServiceSelector.getCtrlShippingServices());
    this.cbxShippingService.setModel(dataModel);
    this.cbxShippingService.setSelectedIndex(0);
    if (this.shippingServiceSelector.getShippingType() == ShippingTypeCodeType.Calculated) {
      this.txtShippingServiceCost.setEditable(false);
      this.txtShippingServiceAdditionalCost.setEditable(false);
    }
  }

  void buildShipToLocationCheckBoxControls()
  {
    Hashtable map = this.shippingServiceSelector.getShipToLocationOptions();
    ControlBuilder builder = ControlBuilder.getInstance();
    this.cbkShipToLocations = builder.buildIDCheckBoxControls(this.panelShipToLocations, map, 3);
  }

  void btnCancel_actionPerformed(ActionEvent e)
  {
    this.dispose();
  }

  void btnAdd_actionPerformed(ActionEvent e) {
    InternationalShippingServiceOptionsType sso = new InternationalShippingServiceOptionsType();

    int idx = this.cbxShippingService.getSelectedIndex();
    sso.setShippingService( (ShippingServiceCodeType)this.
                              shippingServiceSelector.getCtrlShippingServices()[
                              idx].Tag);
    if (this.shippingServiceSelector.getShippingType() ==
        ShippingTypeCodeType.Flat) {
      String cost = this.txtShippingServiceCost.getText();
      if (cost.length() > 0) {
        sso.setShippingServiceCost(new AmountType(cost));
      }
      cost = this.txtShippingServiceAdditionalCost.getText();
      if (cost.length() > 0) {
        sso.setShippingServiceAdditionalCost(new AmountType(cost));
      }
    }
    this.shippingServiceSelector.setSelectedShippingServiceOption(sso);
    int cnt = this.cbkShipToLocations != null ? this.cbkShipToLocations.length : 0;
    if (cnt > 0) {
      ArrayList lstShipToLocations = ServiceControlManager.getInstance().getSelectedCheckBoxList(this.cbkShipToLocations);;
      cnt = lstShipToLocations.size();
      if (cnt > 0) {
        String[] arrShipToLocations = new String[cnt];
        for (int i = 0; i < cnt; i++) {
          arrShipToLocations[i] = lstShipToLocations.get(i).toString();
        }
        sso.setShipToLocation(arrShipToLocations);
      }
    }
    this.dispose();
  }
}

class DialogEditInternationalShippingService_btnAdd_actionAdapter implements java.awt.event.ActionListener {
  DialogEditInternationalShippingService adaptee;

  DialogEditInternationalShippingService_btnAdd_actionAdapter(DialogEditInternationalShippingService adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnAdd_actionPerformed(e);
  }
}

class DialogEditInternationalShippingService_btnCancel_actionAdapter implements java.awt.event.ActionListener {
  DialogEditInternationalShippingService adaptee;

  DialogEditInternationalShippingService_btnCancel_actionAdapter(DialogEditInternationalShippingService adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnCancel_actionPerformed(e);
  }
}
