/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;

public class DialogGetFeedback extends JDialog {
  private ApiContext apiContext = new ApiContext();

  final static int totalColumns = 6;
  final String[] colNames = new String[] {
      "UserID", "UserScore", "ItemID", "Type", "Comment", "CommentTime"};

  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();

  JPanel panel1 = new JPanel();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();

  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JTextField txtUserID = new JTextField();
  JLabel jLabel1 = new JLabel();
  JTextField txtStartingPage = new JTextField();
  JLabel jLabel2 = new JLabel();
  JTextField txtItemsPerPage = new JTextField();
  JLabel jLabel3 = new JLabel();
  JPanel jPanel8 = new JPanel();
  JButton btnGetFeedback = new JButton();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable tblFeedbacks = new JTable();

  JPanel jPanel11 = new JPanel();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel13 = new JPanel();
  JPanel jPanel14 = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel7 = new JLabel();

  public DialogGetFeedback(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();

      //
      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetFeedback() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jLabel1.setPreferredSize(new Dimension(50, 15));
    jLabel1.setVerifyInputWhenFocusTarget(true);
    jLabel1.setText("UserID:");
    txtUserID.setPreferredSize(new Dimension(80, 21));
    txtUserID.setText("");
    jPanel5.setLayout(gridBagLayout1);
    txtStartingPage.setMinimumSize(new Dimension(60, 21));
    txtStartingPage.setPreferredSize(new Dimension(60, 21));
    txtStartingPage.setText("1");
    jLabel2.setText("Starting page:");
    txtItemsPerPage.setOpaque(true);
    txtItemsPerPage.setPreferredSize(new Dimension(60, 21));
    txtItemsPerPage.setText("100");
    jLabel3.setText("Items Per page:");
    btnGetFeedback.setText("GetFeedback");
    btnGetFeedback.addActionListener(new DialogGetFeedback_btnGetFeedback_actionAdapter(this));
    jPanel3.setPreferredSize(new Dimension(10, 1));
    jPanel4.setPreferredSize(new Dimension(130, 40));
    jPanel4.setLayout(gridBagLayout2);
    jLabel4.setText("    ");
    jLabel6.setText("    ");
    jLabel5.setPreferredSize(new Dimension(45, 21));
    jLabel5.setText("");
    jScrollPane1.getViewport().setBackground(Color.white);
    jLabel7.setText("    ");
    getContentPane().add(panel1);
    panel1.add(jPanel1,  BorderLayout.NORTH);
    jPanel1.add(jPanel4, BorderLayout.NORTH);
    jPanel4.add(txtUserID,   new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel4.add(jLabel7,  new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel4.add(jLabel1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel1.add(jPanel5, BorderLayout.CENTER);
    jPanel5.add(jLabel2,    new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel4,    new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(txtStartingPage,    new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel5,    new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel3,    new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel6,    new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(txtItemsPerPage,    new GridBagConstraints(6, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    panel1.add(jPanel2,  BorderLayout.CENTER);

    jPanel2.setLayout(borderLayout3);
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.add(jPanel11, BorderLayout.NORTH);
    jPanel2.add(jPanel12, BorderLayout.SOUTH);
    jPanel2.add(jPanel13, BorderLayout.WEST);
    jPanel2.add(jPanel14, BorderLayout.EAST);
    jPanel2.add(jScrollPane1, BorderLayout.CENTER);

    jScrollPane1.getViewport().add(tblFeedbacks, null);
    panel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel1.add(jPanel8,  BorderLayout.SOUTH);
    jPanel8.add(btnGetFeedback, null);

    jPanel5.setPreferredSize(new Dimension(400, 40));
    this.setSize(new Dimension(700, 400));
  }

  static String[] feedbackToColumns(FeedbackDetailType fd)
  {
    String[] cols = new String[totalColumns];
    int i = 0;
    cols[i++] = fd.getCommentingUser() == null ? "" : fd.getCommentingUser().getValue();
    cols[i++] = fd.getCommentingUserScore() == null ? "" : fd.getCommentingUserScore().toString();
    cols[i++] = fd.getItemID() == null ? "" : fd.getItemID().getValue();
    cols[i++] = fd.getCommentType() == null ? "" : fd.getCommentType().toString();
    cols[i++] = fd.getCommentText() == null ? "" : fd.getCommentText();
    cols[i++] = fd.getCommentTime() == null ? "" : eBayUtil.toAPITimeString(fd.getCommentTime().getTime());

    return cols;
  }

  void btnGetFeedback_actionPerformed(ActionEvent e) {
    try
    {
      GuiUtil.isTextControlFilled(this.txtUserID, "Please enter user ID.");

      GetFeedbackCall api = new GetFeedbackCall(this.apiContext);

      api.setUserID(new UserIDType(this.txtUserID.getText()));

      if( this.txtItemsPerPage.getText().length() > 0 &&
          this.txtStartingPage.getText().length() > 0 )
      {
        PaginationType pt = new PaginationType();
        pt.setPageNumber(new Integer(this.txtStartingPage.getText()));
        pt.setEntriesPerPage(new Integer(this.txtItemsPerPage.getText()));
        api.setPagination(pt);
      }

      // Executes the API.
      final FeedbackDetailType[] feedbacks = api.getFeedback();

      // Display items in table.
      TableModel dataModel = new AbstractTableModel() {
        public int getColumnCount() { return DialogGetFeedback.totalColumns; }
        public int getRowCount() { return feedbacks == null ? 0 : feedbacks.length;}
        public String getColumnName(int columnIndex){
          return colNames[columnIndex];
        }
        public Object getValueAt(int row, int col)
        {
          FeedbackDetailType fd = feedbacks[row];
          return feedbackToColumns(fd)[col];
        }
      };

      this.tblFeedbacks.setModel(dataModel);
    }
    catch(Exception ex)
    {
      String msg = ex.getClass().getName() + " : " + ex.getMessage();
      ((FrameDemo)this.getParent()).showErrorMessage(msg);
    }
  }
}

class DialogGetFeedback_btnGetFeedback_actionAdapter implements java.awt.event.ActionListener {
  DialogGetFeedback adaptee;

  DialogGetFeedback_btnGetFeedback_actionAdapter(DialogGetFeedback adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnGetFeedback_actionPerformed(e);
  }
}
