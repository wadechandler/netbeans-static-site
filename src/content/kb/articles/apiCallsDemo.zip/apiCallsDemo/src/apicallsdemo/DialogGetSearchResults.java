/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."

*/

package apicallsdemo;

import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.util.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;

public class DialogGetSearchResults extends JDialog {
  private ApiContext apiContext = new ApiContext();

  final static int totalColumns = 8;
  final String[] colNames = new String[] {
    "ItemID", "Type", "Title", "SubTitle", "StartTime", "Price", "BidCount", "EndTime"};

  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();

  JPanel panel1 = new JPanel();

  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();

  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();

  JTextField queryText = new JTextField();
  JLabel jLabel1 = new JLabel();
  JPanel jPanel6 = new JPanel();
  JButton btnSearch = new JButton();
  JCheckBox cbxCharity = new JCheckBox();
  JCheckBox cbxSearchInDescription = new JCheckBox();
  JCheckBox cbxPaypalOnly = new JCheckBox();
  JLabel jLabel2 = new JLabel();
  JTextField maxPrice = new JTextField();
  JTextField minPrice = new JTextField();
  JLabel jLabel3 = new JLabel();
  JTextField pageNumber = new JTextField();
  JLabel jLabel4 = new JLabel();
  JTextField entriesPerPage = new JTextField();
  JLabel jLabel5 = new JLabel();
  JTextField includeUserId = new JTextField();
  JLabel jLabel6 = new JLabel();
  JTextField categoryID = new JTextField();
  JLabel jLabel7 = new JLabel();
  JComboBox comboItemType = new JComboBox();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable tblResults = new JTable();

  JPanel jPanel16 = new JPanel();
  JPanel jPanel17 = new JPanel();
  JPanel jPanel18 = new JPanel();
  JPanel jPanel19 = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel18 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JTextField txtPostalCode = new JTextField();
  JLabel jLabel20 = new JLabel();
  JTextField txtMaxDistance = new JTextField();
  JLabel jLabel21 = new JLabel();
  JLabel jLabel22 = new JLabel();
  JLabel jLabel23 = new JLabel();
  JTextField txtQuantity = new JTextField();
  JLabel jLabel24 = new JLabel();
  JCheckBox ckbIsLot = new JCheckBox();

  public DialogGetSearchResults(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();

      // Initialize item type combo box.
      Object[] list = new Object[] {
          new ControlTagItem("All Items", ItemTypeFilterCodeType.AllItems),
          new ControlTagItem("Auction Items Only", ItemTypeFilterCodeType.AuctionItemsOnly),
          new ControlTagItem("Fixed Priced Item", ItemTypeFilterCodeType.FixedPricedItem),
      };
      ComboBoxModel dataModel = new DefaultComboBoxModel(list);
      this.comboItemType.setModel(dataModel);
      this.comboItemType.setSelectedIndex(0);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetSearchResults() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jLabel1.setText("Search for:");
    queryText.setOpaque(true);
    queryText.setPreferredSize(new Dimension(200, 21));
    queryText.setRequestFocusEnabled(true);
    queryText.setSelectionStart(0);
    queryText.setText("harry potter");
    btnSearch.setText("Search eBay");
    btnSearch.addActionListener(new DialogGetSearchResults_btnSearch_actionAdapter(this));
    jPanel5.setLayout(gridBagLayout1);
    jLabel2.setPreferredSize(new Dimension(80, 15));
    jLabel2.setText("Maximum price:");
    maxPrice.setPreferredSize(new Dimension(60, 21));
    maxPrice.setText("");
    jLabel3.setPreferredSize(new Dimension(80, 15));
    jLabel3.setText("Minimum price:");
    minPrice.setPreferredSize(new Dimension(60, 21));
    minPrice.setText("");
    pageNumber.setPreferredSize(new Dimension(60, 21));
    pageNumber.setText("1");
    pageNumber.setScrollOffset(0);
    jLabel4.setPreferredSize(new Dimension(80, 15));
    jLabel4.setText("PageNumber:");
    entriesPerPage.setPreferredSize(new Dimension(60, 21));
    entriesPerPage.setText("100");
    jLabel5.setPreferredSize(new Dimension(80, 15));
    jLabel5.setText("Page size:");
    jLabel6.setPreferredSize(new Dimension(80, 15));
    jLabel6.setText("UserID:");
    includeUserId.setPreferredSize(new Dimension(60, 21));
    includeUserId.setSelectionStart(0);
    jLabel7.setPreferredSize(new Dimension(80, 15));
    jLabel7.setText("CategoryID:");
    categoryID.setPreferredSize(new Dimension(60, 21));
    categoryID.setText("");
    jScrollPane1.getViewport().setBackground(Color.white);
    jScrollPane1.setPreferredSize(new Dimension(554, 404));
    jPanel6.setMinimumSize(new Dimension(107, 35));
    jPanel6.setPreferredSize(new Dimension(107, 40));
    jPanel5.setBorder(null);
    jPanel5.setPreferredSize(new Dimension(14, 280));
    jLabel8.setPreferredSize(new Dimension(80, 15));
    jLabel8.setText(" ");
    jLabel9.setText("    ");
    jLabel10.setText("    ");
    jLabel11.setText("Paypal payment only:");
    jLabel12.setText("Charity listing only:");
    jLabel13.setText("Search in description:");
    jLabel14.setText("    ");
    jLabel15.setText("    ");
    jLabel16.setText("    ");
    jLabel17.setText("    ");
    cbxSearchInDescription.setText("");
    cbxCharity.setText("");
    cbxPaypalOnly.setText("");
    jLabel18.setText("Item type:");
    jLabel19.setText("    ");
    jLabel20.setText("PostalCode:");
    txtPostalCode.setPreferredSize(new Dimension(60, 21));
    txtPostalCode.setText("");
    txtMaxDistance.setMinimumSize(new Dimension(6, 21));
    txtMaxDistance.setPreferredSize(new Dimension(60, 21));
    jLabel21.setText("MaxDistance:");
    jLabel22.setText("    ");
    jLabel23.setText("Quantity:");
    jLabel24.setText("IsLot:");
    ckbIsLot.setText("");
    txtQuantity.setPreferredSize(new Dimension(60, 21));
    txtQuantity.setText("");
    getContentPane().add(panel1);
    panel1.add(jPanel1,  BorderLayout.NORTH);
    jPanel1.add(jPanel4,  BorderLayout.NORTH);
    jPanel4.add(jLabel1, null);
    jPanel4.add(queryText, null);
    jPanel1.add(jPanel5, BorderLayout.CENTER);
    jPanel5.add(cbxCharity,         new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, -4, 0, 0), 0, 0));
    jPanel5.add(jLabel8,       new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel9,       new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(cbxPaypalOnly,         new GridBagConstraints(6, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, -4, 0, 0), 0, 0));
    jPanel5.add(jLabel10,      new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel11,      new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel12,     new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(cbxSearchInDescription,     new GridBagConstraints(2, 2, 1, 2, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, -4, 0, 0), 0, 0));
    jPanel5.add(jLabel13,   new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel14,   new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(comboItemType,    new GridBagConstraints(6, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel15,   new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel6,    new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(includeUserId,    new GridBagConstraints(2, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel7,    new GridBagConstraints(4, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(categoryID,    new GridBagConstraints(6, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel16,   new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel17,   new GridBagConstraints(0, 10, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel18,    new GridBagConstraints(4, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel19,   new GridBagConstraints(0, 12, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel22,  new GridBagConstraints(0, 8, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(minPrice, new GridBagConstraints(2, 7, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel3, new GridBagConstraints(0, 7, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(maxPrice, new GridBagConstraints(6, 7, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel2, new GridBagConstraints(4, 7, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel20, new GridBagConstraints(0, 9, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(txtPostalCode, new GridBagConstraints(2, 9, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel21, new GridBagConstraints(4, 9, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(txtMaxDistance, new GridBagConstraints(6, 9, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(entriesPerPage, new GridBagConstraints(6, 13, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel5, new GridBagConstraints(4, 13, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(pageNumber, new GridBagConstraints(2, 13, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel4, new GridBagConstraints(0, 13, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel23,  new GridBagConstraints(0, 11, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(txtQuantity,  new GridBagConstraints(2, 11, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(jLabel24,  new GridBagConstraints(4, 11, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel5.add(ckbIsLot,  new GridBagConstraints(6, 11, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, -4, 0, 0), 0, 0));
    jPanel1.add(jPanel6, BorderLayout.SOUTH);
    jPanel6.add(btnSearch, null);
    panel1.add(jPanel2,  BorderLayout.CENTER);

    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setLayout(borderLayout3);
    jPanel2.add(jPanel16, BorderLayout.NORTH);
    jPanel2.add(jPanel17, BorderLayout.SOUTH);
    jPanel2.add(jPanel18, BorderLayout.WEST);
    jPanel2.add(jPanel19, BorderLayout.EAST);
    jPanel2.add(jScrollPane1, BorderLayout.CENTER);

    jScrollPane1.getViewport().add(tblResults, null);
    panel1.add(jPanel3, BorderLayout.SOUTH);

    this.setSize(new Dimension(850, 650));
  }

  static String[] itemToColumns(ItemType item)
  {
    String[] cols = new String[totalColumns];
    int i = 0;
    cols[i++] = item.getItemID().toString();
    cols[i++] = item.getListingType().toString();
    cols[i++] = item.getTitle();
    cols[i++] = item.getSubTitle() == null ? "" : item.getSubTitle();

    ListingDetailsType dtl = item.getListingDetails();
    cols[i++] = eBayUtil.toAPITimeString(dtl.getStartTime().getTime());

    cols[i++] = (new Double(item.getSellingStatus().getCurrentPrice().getValue())).toString();
    cols[i++] = item.getSellingStatus().getBidCount().toString();
    cols[i++] = eBayUtil.toAPITimeString(dtl.getEndTime().getTime());
    return cols;
  }

  void btnSearch_actionPerformed(ActionEvent e)
  {
    int i;
    String txt, txt2;

    try
    {
      GetSearchResultsCall api = new GetSearchResultsCall(this.apiContext);

      txt = this.queryText.getText();
      if( txt.length() == 0 )
        throw new SdkException("Please enter query string.");
      api.setQuery(txt);

      // Search flags
      ArrayList al = new ArrayList();
      if( this.cbxCharity.isSelected() )
        al.add(SearchFlagsCodeType.Charity);
      if( this.cbxPaypalOnly.isSelected() )
        al.add(SearchFlagsCodeType.PayPalBuyerPaymentOption);
      if( this.cbxSearchInDescription.isSelected() )
        al.add(SearchFlagsCodeType.SearchInDescription);

      SearchFlagsCodeType flags[] = new SearchFlagsCodeType[al.size()];
      for(i = 0; i < al.size(); i++ )
        flags[i] = (SearchFlagsCodeType)al.get(i);

      if( flags.length > 0 )
        api.setSearchFlags(flags);

      //
      ControlTagItem ct = (ControlTagItem)this.comboItemType.getSelectedItem();
      api.setItemTypeFilter((ItemTypeFilterCodeType)ct.Tag);

      //
      txt = this.categoryID.getText();
      if( txt.length() > 0 )
        api.setCategoryID(txt);

      // UserID filter.
      txt = this.includeUserId.getText();
      if( txt.length() > 0 )
      {
        UserIdFilterType uf = new UserIdFilterType();
        uf.setIncludeSellers(
          new UserIDType[] {new UserIDType(txt)}
          );
        api.setUserIdFilter(uf);
      }

      // Price range filter.
      txt = this.minPrice.getText();
      txt2 = this.maxPrice.getText();
      if( txt.length() > 0 || txt2.length() > 0 )
      {
        PriceRangeFilterType prf = new PriceRangeFilterType();
        prf.setMinPrice(new AmountType(Double.parseDouble(txt)));
        prf.setMaxPrice(new AmountType(Double.parseDouble(txt2)));

        api.setPriceRangeFilter(prf);
      }

      txt = this.txtPostalCode.getText().trim();
      txt2 = this.txtMaxDistance.getText().trim();
      if (txt.length() > 0 || txt2.length() > 0) {
        ProximitySearchType pst = new ProximitySearchType();
        pst.setPostalCode(txt);
        pst.setMaxDistance(Integer.parseInt(txt2));
        api.setProximitySearch(pst);
      }

      txt = this.txtQuantity.getText().trim();
      if (txt.length() > 0)
      ;//  api.setQ


      // Pagination settings.
      PaginationType pt = new PaginationType();
      txt = this.entriesPerPage.getText();
      i = 0;
      if( txt.length() > 0 )
      {
        pt.setEntriesPerPage(new Integer(txt));
        i++;
      }
      txt = this.pageNumber.getText();
      if( txt.length() > 0 )
      {
        pt.setPageNumber(new Integer(txt));
        i++;
      }
      if( i > 0 )
        api.setPagination(pt);

      // Call eBay.
      final SearchResultItemType[] items = api.getSearchResults();

       // Display results.
       TableModel dataModel = new AbstractTableModel() {
         public int getColumnCount() {
           return totalColumns;
         }

         public int getRowCount() {
           return items.length;
         }

         public String getColumnName(int columnIndex) {
           return colNames[columnIndex];
         }

         public Object getValueAt(int row, int col) {
           ItemType item = items[row].getItem();
           return itemToColumns(item)[col];
         }
       };

       this.tblResults.setModel(dataModel);
    }
    catch(Exception ex)
    {
      String msg = ex.getClass().getName() + " : " + ex.getMessage();
      ((FrameDemo)this.getParent()).showErrorMessage(msg);
    }
  }
}

class DialogGetSearchResults_btnSearch_actionAdapter implements java.awt.event.ActionListener {
  DialogGetSearchResults adaptee;

  DialogGetSearchResults_btnSearch_actionAdapter(DialogGetSearchResults adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnSearch_actionPerformed(e);
  }
}
