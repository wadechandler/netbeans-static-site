/*
� 2000-2004 eBay Inc. All rights reserved.
 
eBay, eBay API, and eBay SDK are trademarks of eBay Inc.
 
Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.
 
License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.
 
Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
                          All rights reserved."
 
 */

package apicallsdemo;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import org.apache.axis.types.*;
import com.ebay.sdk.*;
import com.ebay.soap.eBLBaseComponents.*;
import com.ebay.sdk.helper.ui.*;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class FrameDemo extends JFrame implements KeyListener, ListSelectionListener, MouseListener {
    private ApiContext apiContext = new ApiContext();
    public static final String TITLE = "eBay SDK for Java - ApiCallsDemo";
    
    long lastMouseClickedTime;
    
    static ArrayList lstCalls = new ArrayList();
    
    static {
        lstCalls.add("AddDispute");
        lstCalls.add("AddDisputeResponse");
        lstCalls.add("AddItem");
        lstCalls.add("AddMemberMessage");
        lstCalls.add("AddOrder");
        lstCalls.add("AddSecondChanceItem");
        lstCalls.add("AddToItemDescription");
        lstCalls.add("EndItem");
        lstCalls.add("GetAccount");
        lstCalls.add("GetAllBidders");
        lstCalls.add("GetCategories");
        lstCalls.add("GetCategory2FinanceOffer");
        lstCalls.add("GetCategoryListings");
        lstCalls.add("GetDispute");
        lstCalls.add("GeteBayOfficialTime");
        lstCalls.add("GetFeedback");
        lstCalls.add("GetFinanceOffers");
        lstCalls.add("GetHighBidders");
        lstCalls.add("GetItem");
        lstCalls.add("GetItemShipping");
        lstCalls.add("GetItemTransactions");
        lstCalls.add("GetMemberMessages");
        lstCalls.add("GetMyeBay");
        lstCalls.add("GetNotificationPreferences");
        lstCalls.add("GetOrders");
        lstCalls.add("GetProductFinder");
        lstCalls.add("GetSearchResults");
        lstCalls.add("GetSellerEvents");
        lstCalls.add("GetSellerList");
        lstCalls.add("GetSellerTransactions");
        lstCalls.add("GetSuggestedCategories");
        lstCalls.add("GetUser");
        lstCalls.add("GetUserDisputes");
        lstCalls.add("LeaveFeedback");
        lstCalls.add("RelistItem");
        lstCalls.add("ReviseCheckoutStatus");
        lstCalls.add("ReviseItem");
        lstCalls.add("SellerReverseDispute");
        lstCalls.add("SetNotificationPreferences");
    }
    
    JPanel contentPane;
    JMenuBar jMenuBar1 = new JMenuBar();
    JMenu jMenuFile = new JMenu();
    JMenuItem jMenuFileExit = new JMenuItem();
    JMenu jMenuHelp = new JMenu();
    JMenuItem jMenuHelpAbout = new JMenuItem();
    JLabel jLabel1 = new JLabel();
    JMenuItem jMenuItemAccount = new JMenuItem();
    JButton btnAccount = new JButton();
    JPanel jPanel1 = new JPanel();
    JPanel jPanel2 = new JPanel();
    JPanel jPanel3 = new JPanel();
    GridLayout gridLayout1 = new GridLayout();
    BorderLayout borderLayout1 = new BorderLayout();
    JPanel jPanel10 = new JPanel();
    JPanel jPanelGetItemTransaction = new JPanel();
    JButton btnGetItemTransaction = new JButton();
    BorderLayout borderLayout2 = new BorderLayout();
    JPanel jPanel4 = new JPanel();
    JPanel jPanel5 = new JPanel();
    JPanel jPanel6 = new JPanel();
    JPanel jPanel7 = new JPanel();
    JScrollPane jScrollPane1 = new JScrollPane();
    
    DefaultListModel lstModel = new DefaultListModel();
    JList lstCommands = new JList(lstModel);
    GridBagLayout gridBagLayout1 = new GridBagLayout();
    JButton btnRun = new JButton();
    
    TitledBorder titledBorder1;
    TitledBorder titledBorder2;
    TitledBorder titledBorder3;
    
    GridBagLayout gridBagLayout2 = new GridBagLayout();
    JLabel jLabel2 = new JLabel();
    JTextField txtSelectedAPI = new JTextField();
    
    //Construct the frame
    public FrameDemo() {
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
            
            // Turn on logging.
            ApiLogging apiLogging = new ApiLogging();
            this.apiContext.setApiLogging(apiLogging);
            
            // Enable Call-Retry.
            CallRetry cr = new CallRetry();
            cr.setMaximumRetries(3);
            cr.setDelayTime(1000); // Wait for one second between each retry-call.
            Token[] apiErrorCodes = new Token[] {
                new Token("10007"), // "Internal error to the application."
                        new Token("931"), // "Validation of the authentication token in API request failed."
                        new Token("521"), // Test of Call-Retry: "The specified time window is invalid."
                        new Token("124") // Test of Call-Retry: "Developer name invalid."
            };
            cr.setTriggerApiErrorCodes(apiErrorCodes);
            
            // Set trigger exceptions for CallRetry.
            // Build a dummy SdkSoapException so that we can get its Class.
            java.lang.Class[] tcs = new java.lang.Class[] {
                com.ebay.sdk.SdkSoapException.class
            };
            cr.setTriggerExceptions(tcs);
            
            this.apiContext.setCallRetry(cr);
            
            this.apiContext.setTimeout(180000);
            
            ApiCredential cred = new ApiCredential();
            
            // Read properties file to load developer credentials
            Properties keys = new Properties();
            try {
                keys.load(new FileInputStream("keys.properties"));
            } catch (IOException e) {
                System.out.println(e);
            }            
            
            cred.seteBayToken(keys.getProperty("token"));
            
            ApiAccount ac = cred.getApiAccount();
            ac.setDeveloper(keys.getProperty("devId"));
            ac.setApplication(keys.getProperty("appId"));
            ac.setCertificate(keys.getProperty("certId"));                   
            
            this.apiContext.setApiCredential(cred);
            
            this.apiContext.setApiServerUrl(keys.getProperty("apiServerUrl"));
            this.apiContext.setEpsServerUrl(keys.getProperty("epsServerUrl"));
            
            // Add listener for token renewal event.
            cred.addTokenEventListener(new DemoTokenEventListener(this));
            customInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //Component initialization
    private void jbInit() throws Exception {
        contentPane = (JPanel)this.getContentPane();
        
        titledBorder1 = new TitledBorder("");
        titledBorder2 = new TitledBorder("");
        titledBorder3 = new TitledBorder("");
        
        contentPane.setLayout(borderLayout1);
        this.setSize(new Dimension(400, 300));
        this.setTitle("eBay SDK for Java - ApiCallsDemo");
        jMenuFile.setText("File");
        jMenuFileExit.setText("Exit");
        jMenuFileExit.addActionListener(new FrameDemo_jMenuFileExit_ActionAdapter(this));
        jMenuHelp.setText("Help");
        jMenuHelpAbout.setText("About");
        jMenuHelpAbout.addActionListener(new FrameDemo_jMenuHelpAbout_ActionAdapter(this));
        jLabel1.setMaximumSize(new Dimension(330, 15));
        jLabel1.setOpaque(false);
        jLabel1.setRequestFocusEnabled(true);
        jLabel1.setToolTipText("");
        jLabel1.setVerifyInputWhenFocusTarget(true);
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setText("Select an API from the list and press button Run to launch the demo.");
        jMenuItemAccount.setRolloverEnabled(false);
        jMenuItemAccount.setText("Account");
        jMenuItemAccount.addActionListener(new
                FrameDemo_jMenuItemAccount_actionAdapter(this));
        btnAccount.setBorder(titledBorder3);
        btnAccount.setMaximumSize(new Dimension(119, 21));
        btnAccount.setMinimumSize(new Dimension(119, 21));
        btnAccount.setPreferredSize(new Dimension(130, 21));
        btnAccount.setText("Config API Account");
        btnAccount.addActionListener(new FrameDemo_btnAccount_actionAdapter(this));
        jPanel1.setLayout(gridLayout1);
        gridLayout1.setColumns(1);
        gridLayout1.setRows(2);
        gridLayout1.setVgap(0);
        jPanel3.setLayout(borderLayout2);
        btnGetItemTransaction.setPreferredSize(new Dimension(148, 25));
        btnGetItemTransaction.setText("GetItemTransaction");
        
        jPanel6.setPreferredSize(new Dimension(50, 10));
        jPanel6.setLayout(gridBagLayout2);
        jPanel5.setPreferredSize(new Dimension(50, 10));
        jPanel2.setBorder(BorderFactory.createEtchedBorder());
        jPanel2.setPreferredSize(new Dimension(50, 50));
        jPanel2.setLayout(gridBagLayout1);
        btnRun.setEnabled(true);
        btnRun.setBorder(titledBorder2);
        btnRun.setText("    Run    ");
        btnRun.addActionListener(new FrameDemo_btnRun_actionAdapter(this));
        jPanel4.setPreferredSize(new Dimension(10, 15));
        jPanel10.setPreferredSize(new Dimension(140, 31));
        jLabel2.setText("    ");
        txtSelectedAPI.setBackground(UIManager.getColor("Button.background"));
        txtSelectedAPI.setBorder(BorderFactory.createLineBorder(Color.black));
        txtSelectedAPI.setPreferredSize(new Dimension(220, 27));
        txtSelectedAPI.setText("");
        txtSelectedAPI.setHorizontalAlignment(SwingConstants.CENTER);
        txtSelectedAPI.setEditable(false);
        jMenuFile.add(jMenuItemAccount);
        jMenuFile.add(jMenuFileExit);
        jMenuHelp.add(jMenuHelpAbout);
        jMenuBar1.add(jMenuFile);
        jMenuBar1.add(jMenuHelp);
        contentPane.add(jPanel1, BorderLayout.NORTH);
        jPanel1.add(jPanel10, null);
        jPanel10.add(btnAccount, null);
        jPanel1.add(jLabel1, null);
        contentPane.add(jPanel3, BorderLayout.CENTER);
        jPanel3.add(jPanel4, BorderLayout.NORTH);
        jPanel3.add(jPanel5, BorderLayout.WEST);
        jPanel3.add(jPanel6, BorderLayout.EAST);
        jPanel3.add(jPanel7, BorderLayout.SOUTH);
        jPanel3.add(jScrollPane1, BorderLayout.CENTER);
        jScrollPane1.getViewport().add(lstCommands, null);
        contentPane.add(jPanel2, BorderLayout.SOUTH);
        jPanel2.add(btnRun,   new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
                ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
        jPanel2.add(jLabel2,  new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
                ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
        jPanel2.add(txtSelectedAPI, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
                ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
        jPanelGetItemTransaction.add(btnGetItemTransaction, null);
        
        this.setJMenuBar(jMenuBar1);
    }
    
    void customInit() {
        lstCommands.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        int size = lstCalls.size();
        for (int i = 0; i < size; i++) {
            lstModel.addElement(lstCalls.get(i));
        }
        
        this.lstCommands.addKeyListener(this);
        this.lstCommands.addListSelectionListener(this);
        this.lstCommands.addMouseListener(this);
    }
    
    public void select() {
        this.lstCommands.setSelectedIndex(0);
        this.lstCommands.grabFocus();
    }
    
    private boolean readyToMakeApiCall() {
        if (!GuiUtil.isApiContextFilled(this.apiContext, true)) {
            showInfoMessage("Please complete account information first.");
            return false;
        }
        return true;
    }
    
    //File | Exit action performed
    public void jMenuFileExit_actionPerformed(ActionEvent e) {
        System.exit(0);
    }
    
    //Help | About action performed
    public void jMenuHelpAbout_actionPerformed(ActionEvent e) {
        FrameDemo_AboutBox dlg = new FrameDemo_AboutBox(this);
        Dimension dlgSize = dlg.getPreferredSize();
        Dimension frmSize = getSize();
        Point loc = getLocation();
        dlg.setLocation( (frmSize.width - dlgSize.width) / 2 + loc.x,
                (frmSize.height - dlgSize.height) / 2 + loc.y);
        dlg.setModal(true);
        dlg.pack();
        dlg.show();
    }
    
    //Overridden so we can exit when window is closed
    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            jMenuFileExit_actionPerformed(null);
        }
    }
    
    private void showAccountDialog() {
        DialogAccount dlg = new DialogAccount(this, "Config Account", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
        
    }
    
    void jMenuItemAccount_actionPerformed(ActionEvent e) {
        this.showAccountDialog();
    }
    
    void btnAccount_actionPerformed(ActionEvent e) {
        this.showAccountDialog();
    }
    
    public ApiContext getApiContext() {
        return this.apiContext;
    }
    
    public void setApiContext(ApiContext apiContext) {
        this.apiContext = apiContext;
    }
    
    public void showErrorMessage(String error) {
        JOptionPane.showMessageDialog(this, error, TITLE, JOptionPane.ERROR_MESSAGE);
    }
    
    public void showInfoMessage(String error) {
        JOptionPane.showMessageDialog(this, error, TITLE,
                JOptionPane.INFORMATION_MESSAGE);
    }
    
    // KeyListner interfaces
    public void keyTyped(KeyEvent evt) {
    }
    
    public void keyPressed(KeyEvent evt) {
        if (this.lstCommands.hasFocus()) {
            char c = Character.toLowerCase(evt.getKeyChar());
            if (c == '\n') {
                btnRun_actionPerformed(null);
            } else {
                int cnt = 0;
                boolean hasSelection = false;
                while (!hasSelection && cnt < this.lstCalls.size()) {
                    String call = (String)this.lstCalls.get(cnt);
                    if (c == Character.toLowerCase(call.charAt(0))) {
                        hasSelection = true;
                        this.lstCommands.setSelectedIndex(cnt - 1);
                        Rectangle rect = this.lstCommands.getCellBounds(cnt, cnt);
                        this.jScrollPane1.getVerticalScrollBar().setValue(rect.y);
                    }
                    cnt++;
                }
            }
        }
    }
    
    public void keyReleased(KeyEvent evt) {
    }
    
    // ListSelectionListner interfaces
    public void valueChanged(ListSelectionEvent e) {
        String api = this.lstCommands.getSelectedValue().toString();
        this.txtSelectedAPI.setText(api);
    }
    
    // MouseListener interfaces
    /**
     * Invoked when the mouse button has been clicked (pressed
     * and released) on a component.
     */
    public void mouseClicked(MouseEvent e) {
        long eventTime = e.getWhen();
        long timeDiff = eventTime - this.lastMouseClickedTime;
        if (timeDiff < 300L) {
            btnRun_actionPerformed(null);
        }
        this.lastMouseClickedTime = eventTime;
    }
    
    /**
     * Invoked when a mouse button has been pressed on a component.
     */
    public void mousePressed(MouseEvent e) {
    }
    
    /**
     * Invoked when a mouse button has been released on a component.
     */
    public void mouseReleased(MouseEvent e) {
    }
    
    /**
     * Invoked when the mouse enters a component.
     */
    public void mouseEntered(MouseEvent e) {
    }
    
    /**
     * Invoked when the mouse exits a component.
     */
    public void mouseExited(MouseEvent e) {
    }
    
    // Execute the selected API
    void btnRun_actionPerformed(ActionEvent e) {
        if (!readyToMakeApiCall()) {
            return;
        }
        
        if (this.lstCommands.getSelectedIndex() > -1) {
            String api = this.lstCommands.getSelectedValue().toString();
            int len = api.length();
            char[] arrChar = api.toCharArray();
            
            StringBuffer buf = new StringBuffer();
            buf.append(Character.toLowerCase(arrChar[0]));
            for (int i = 1; i < len; i++) {
                buf.append(arrChar[i]);
            }
            
            String cmd = buf.toString();
            
            java.lang.reflect.Method m = null;
            try {
                Class c = this.getClass();
                m = this.getClass().getMethod(cmd, new Class[] {c});
                if (m != null) {
                    m.invoke(this, new Object[] {this});
                }
            } catch (Exception ex) {
                
            }
        }
    }
    
    // Methods to display the input dialog for a selected API
    public void addDispute(FrameDemo parentFrame) {
        DialogAddDispute dlg = new DialogAddDispute(this,
                "eBay SDK for Java - AddDispute", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void addDisputeResponse(FrameDemo parentFrame) {
        DialogAddDisputeResponse dlg = new DialogAddDisputeResponse(this, "eBay SDK for Java - AddDisputeResponse", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void addItem(FrameDemo parentFrame) {
        DialogAddItem dlg = new DialogAddItem(this, "eBay SDK for Java - AddItem", SiteCodeType.US, true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void addMemberMessage(FrameDemo parentFrame) {
        DialogAddMemberMessage dlg = new DialogAddMemberMessage(this, "eBay SDK for Java - AddMemberMessage", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void addOrder(FrameDemo parentFrame) {
        DialogAddOrder dlg = new DialogAddOrder(this, "eBay SDK for Java - AddOrder", SiteCodeType.US, true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void addSecondChanceItem(FrameDemo parentFrame) {
        DialogAddSecondChanceItem dlg = new DialogAddSecondChanceItem(this, "eBay SDK for Java - AddSecondChanceItem", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void addToItemDescription(FrameDemo parentFrame) {
        DialogAddToItemDescription dlg = new DialogAddToItemDescription(this, "eBay SDK for Java - AddToItemDescription", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void endItem(FrameDemo parentFrame) {
        DialogEndItem dlg = new DialogEndItem(this, "eBay SDK for Java - EndItem", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getAccount(FrameDemo parentFrame) {
        DialogGetAccount dlg = new DialogGetAccount(this, "eBay SDK for Java - GetAccount", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getAllBidders(FrameDemo parentFrame) {
        DialogGetAllBidders dlg = new DialogGetAllBidders(this, "eBay SDK for Java - GetAllBidders", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getCategories(FrameDemo parentFrame) {
        DialogGetCategories dlg = new DialogGetCategories(this, "eBay SDK for Java - GetCategories", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getCategory2FinanceOffer(FrameDemo parentFrame) {
        DialogGetCategory2FinanceOffer dlg = new DialogGetCategory2FinanceOffer(this, "eBay SDK for Java - GetCategory2FinaceOffer", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getCategoryListings(FrameDemo parentFrame) {
        DialogGetCategoryListings dlg = new DialogGetCategoryListings(this, "eBay SDK for Java - GetCategoryListings", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getDispute(FrameDemo parentFrame) {
        DialogGetDispute dlg = new DialogGetDispute(this, "eBay SDK for Java - GetDispute", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void geteBayOfficialTime(FrameDemo parentFrame) {
        DialogGeteBayOfficialTime dlg = new DialogGeteBayOfficialTime(this, "eBay SDK for Java - GeteBayOfficialTime", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getFeedback(FrameDemo parentFrame) {
        DialogGetFeedback dlg = new DialogGetFeedback(this, "eBay SDK for Java - GetFeedback", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getFinanceOffers(FrameDemo parentFrame) {
        DialogGetFinanceOffers dlg = new DialogGetFinanceOffers(this, "eBay SDK for Java - GetFinaceOffers", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getHighBidders(FrameDemo parentFrame) {
        DialogGetHighBidders dlg = new DialogGetHighBidders(this, "eBay SDK for Java - GetHighBidders", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getItem(FrameDemo parentFrame) {
        DialogGetItem dlg = new DialogGetItem(this, "eBay SDK for Java - GetItem", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getItemShipping(FrameDemo parentFrame) {
        DialogGetItemShipping dlg = new DialogGetItemShipping(this, "eBay SDK for Java - GetItemShipping", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getItemTransactions(FrameDemo parentFrame) {
        DialogGetItemTransactions dlg = new DialogGetItemTransactions(this, "eBay SDK for Java - GetItemTransactions", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getMemberMessages(FrameDemo parentFrame) {
        DialogGetMemberMessages dlg = new DialogGetMemberMessages(this, "eBay SDK for Java - GetMemberMessages", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getMyeBay(FrameDemo parentFrame) {
        DialogGetMyeBay dlg = new DialogGetMyeBay(this, "eBay SDK for Java - GetMyeBay", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getNotificationPreferences(FrameDemo parentFrame) {
        DialogGetNotificationPreferences dlg = new DialogGetNotificationPreferences(this,
                "eBay SDK for Java - GetNotificationPreferencs", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getOrders(FrameDemo parentFrame) {
        DialogGetOrders dlg = new DialogGetOrders(this, "eBay SDK for Java - GetOrders", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getProductFinder(FrameDemo parentFrame) {
        DialogGetProductFinder dlg = new DialogGetProductFinder(this, "eBay SDK for Java - GetProductFinder", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getSearchResults(FrameDemo parentFrame) {
        DialogGetSearchResults dlg = new DialogGetSearchResults(this, "eBay SDK for Java - GetSearchResults", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getSellerEvents(FrameDemo parentFrame) {
        DialogGetSellerEvents dlg = new DialogGetSellerEvents(this, "eBay SDK for Java - GetSellerEvents", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getSellerList(FrameDemo parentFrame) {
        DialogGetSellerList dlg = new DialogGetSellerList(this, "eBay SDK for Java - GetSellerList", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getSellerTransactions(FrameDemo parentFrame) {
        DialogGetSellerTransactions dlg = new DialogGetSellerTransactions(this, "eBay SDK for Java - GetSellerTransactions", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getSuggestedCategories(FrameDemo parentFrame) {
        DialogGetSuggestedCategories dlg = new DialogGetSuggestedCategories(this, "eBay SDK for Java - GetSuggestedCategories", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getUser(FrameDemo parentFrame) {
        DialogGetUser dlg = new DialogGetUser(this, "eBay SDK for Java - GetUser", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void getUserDisputes(FrameDemo parentFrame) {
        DialogGetUserDisputes dlg = new DialogGetUserDisputes(this, "eBay SDK for Java - GetUserDisputes", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void leaveFeedback(FrameDemo parentFrame) {
        DialogLeaveFeedback dlg = new DialogLeaveFeedback(this, "eBay SDK for Java - LeaveFeedback", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void relistItem(FrameDemo parentFrame) {
        DialogRelistItem dlg = new DialogRelistItem(this, "eBay SDK for Java - RelistItem", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void reviseCheckoutStatus(FrameDemo parentFrame) {
        DialogReviseCheckoutStatus dlg = new DialogReviseCheckoutStatus(this, "eBay SDK for Java - ReviseCheckoutStatus", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void reviseItem(FrameDemo parentFrame) {
        DialogReviseItem dlg = new DialogReviseItem(this, "eBay SDK for Java - ReviseItem", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void sellerReverseDispute(FrameDemo parentFrame) {
        DialogSellerReverseDispute dlg = new DialogSellerReverseDispute(this, "eBay SDK for Java - SellerReverseDispute", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
    
    public void setNotificationPreferences(FrameDemo parentFrame) {
        DialogSetNotificationPreferences dlg = new DialogSetNotificationPreferences(this, "eBay SDK for Java - SetNotificationPreferencs", true);
        GuiUtil.CenterComponent(dlg);
        dlg.show();
    }
}

//Classes to handle the menu selection/button press events.
class FrameDemo_jMenuFileExit_ActionAdapter implements ActionListener {
    FrameDemo adaptee;
    
    FrameDemo_jMenuFileExit_ActionAdapter(FrameDemo adaptee) {
        this.adaptee = adaptee;
    }
    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuFileExit_actionPerformed(e);
    }
}

class FrameDemo_jMenuHelpAbout_ActionAdapter implements ActionListener {
    FrameDemo adaptee;
    
    FrameDemo_jMenuHelpAbout_ActionAdapter(FrameDemo adaptee) {
        this.adaptee = adaptee;
    }
    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuHelpAbout_actionPerformed(e);
    }
}

class FrameDemo_jMenuItemAccount_actionAdapter implements java.awt.event.ActionListener {
    FrameDemo adaptee;
    
    FrameDemo_jMenuItemAccount_actionAdapter(FrameDemo adaptee) {
        this.adaptee = adaptee;
    }
    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItemAccount_actionPerformed(e);
    }
}

class FrameDemo_btnAccount_actionAdapter implements java.awt.event.ActionListener {
    FrameDemo adaptee;
    
    FrameDemo_btnAccount_actionAdapter(FrameDemo adaptee) {
        this.adaptee = adaptee;
    }
    public void actionPerformed(ActionEvent e) {
        adaptee.btnAccount_actionPerformed(e);
    }
}

class FrameDemo_btnRun_actionAdapter implements java.awt.event.ActionListener {
    FrameDemo adaptee;
    
    FrameDemo_btnRun_actionAdapter(FrameDemo adaptee) {
        this.adaptee = adaptee;
    }
    public void actionPerformed(ActionEvent e) {
        adaptee.btnRun_actionPerformed(e);
    }
}

