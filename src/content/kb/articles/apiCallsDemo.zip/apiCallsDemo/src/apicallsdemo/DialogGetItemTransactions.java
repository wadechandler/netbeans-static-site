/*
� 2000-2004 eBay Inc. All rights reserved.

eBay, eBay API, and eBay SDK are trademarks of eBay Inc.

Sample Source Code License
The material below is sample source code in the form of example
applications and code fragments (both in the source code files and
documentation provided hereunder), and may include a tutorial
application (collectively, "Sample Source Code" or "SSC").  YOUR
RECEIPT AND USE OF THE SSC IS CONTINGENT UPON THE TERMS AND CONDITIONS
SET FORTH BELOW.

License. Subject to the terms and restrictions set forth herein, eBay
grants you a non-exclusive, non-transferable, non-sublicensable,
royalty-free license to download and use the SSC solely to create and
distribute derivative works ("Derivative Works") which are designed to
assist your end users to efficiently interact with the eBay Site
(e.g., a listing application) (the "License").  Except as otherwise
expressly stated below, you are not permitted to sell, lease, rent,
copy, distribute or sublicense the SSC, or derivative copies thereof,
or to use it in a time-sharing arrangement or in any other
unauthorized manner. This License does not grant you any rights to
patents, copyrights, trade secrets, trademarks, or any other rights in
respect to the SSC.

Redistribution. You may not use the SSC in any manner that is not
expressly authorized under this License. Without limiting the
foregoing, you may redistribute, use and create Derivative Works in
source and binary forms, subject to the following conditions:
  1. Redistributions of SSC must retain this list of conditions and
     the copyright notice and disclaimer noted below.
  2. Redistributions in binary form must reproduce the copyright
     notice, this list of conditions and the disclaimer in the
     documentation and/or other materials provided with the
     distribution.
  3. Redistribution Conditions:
     � Neither the name of eBay Inc. nor the names of its contributors
       may be used to endorse or promote products derived from this
       software or materials without specific prior written
       permission.
     � Disclaimer. "THIS SOFTWARE AND ANY RELATED MATERIALS ARE
       PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
       ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
       TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
       PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
       COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
       INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
       DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
       SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
       BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
       LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
       (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
       THE USE OF THIS SOFTWARE, AND/OR ANY RELATED MATERIALS, EVEN IF
       ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
     � Copyright Notice: "Copyright (c) 2003, eBay Inc.
			  All rights reserved."

*/

package apicallsdemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

import com.ebay.sdk.*;
import com.ebay.sdk.call.*;
import com.ebay.sdk.helper.ui.*;
import com.ebay.soap.eBLBaseComponents.*;

public class DialogGetItemTransactions extends JDialog {

  final static int totalColumns = 7;
  final static String[] colNames = new String[] {
      "ID", "Price", "AmountPaid", "QtyPurchased", "Buyer", "No. ShippingServices", "No. Intl ShippingServices"};

  private ApiContext apiContext = new ApiContext();

  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JLabel jLabel4 = new JLabel();
  JButton btnCallGetItemTransactions = new JButton();
  JTextField txtModTimeTo = new JTextField();
  JPanel jPanel8 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JTextField txtPageNumber = new JTextField();
  JTextField txtModTimeFrom = new JTextField();
  JPanel jPanelModifiedTime = new JPanel();
  JLabel jLabel3 = new JLabel();
  JTextField txtTransPerPage = new JTextField();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanelTimeFrom = new JPanel();
  JLabel jLabel2 = new JLabel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanelTimeTo = new JPanel();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JTextField txtItemID = new JTextField();
  JLabel jLabel5 = new JLabel();
  JTextField txtTotalNumberOfPages = new JTextField();
  JPanel jPanel22 = new JPanel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JTextField txtCount = new JTextField();
  JPanel jPanel18 = new JPanel();
  JTextField txtReturnedItemCountActual = new JTextField();
  JTextField txtHasMoreItems = new JTextField();
  BorderLayout borderLayout5 = new BorderLayout();
  JPanel jPanel14 = new JPanel();
  JPanel jPanel11 = new JPanel();
  JLabel jLabel10 = new JLabel();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel9 = new JPanel();
  BorderLayout borderLayout6 = new BorderLayout();
  JPanel jPanel10 = new JPanel();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel13 = new JPanel();
  JPanel jPanel15 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable tblTransactions = new JTable();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JTextField txtAutoPay = new JTextField();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel18 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JTextField txtFinanceOfferId = new JTextField();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel20 = new JLabel();
  JTextField txtStartPrice = new JTextField();
  JLabel jLabel21 = new JLabel();
  JTextField txtPrivateListing = new JTextField();
  JLabel jLabel22 = new JLabel();
  JTextField txtLotSize = new JTextField();
  JLabel jLabel23 = new JLabel();
  JLabel jLabel24 = new JLabel();
  JTextField txtAppShippingDiscount = new JTextField();

  public DialogGetItemTransactions(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();

      FrameDemo fd = (FrameDemo)frame;
      this.apiContext = fd.getApiContext();

      GuiUtil.setTimeFilterFields(5, this.txtModTimeFrom, this.txtModTimeTo);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogGetItemTransactions() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jLabel4.setText("ModifiedTimeTo:");
    btnCallGetItemTransactions.setText("GetItemTransactions");
    btnCallGetItemTransactions.addActionListener(new DialogGetItemTransactions_btnCallGetItemTransactions_actionAdapter(this));
    txtModTimeTo.setPreferredSize(new Dimension(120, 21));
    txtModTimeTo.setText("");
    jLabel1.setToolTipText("");
    jLabel1.setText("TransactionsPerPage:");
    txtPageNumber.setPreferredSize(new Dimension(60, 21));
    txtPageNumber.setText("");
    txtModTimeFrom.setPreferredSize(new Dimension(120, 21));
    txtModTimeFrom.setText("");
    jLabel3.setText("ModifiedTimeFrom:");
    txtTransPerPage.setPreferredSize(new Dimension(60, 21));
    txtTransPerPage.setText("");
    jPanel3.setLayout(borderLayout2);
    jLabel2.setText("PageNumber:");
    jPanel1.setLayout(borderLayout3);
    jPanel2.setLayout(borderLayout4);
    jLabel5.setText("ItemID:");
    txtItemID.setMinimumSize(new Dimension(6, 21));
    txtItemID.setPreferredSize(new Dimension(80, 21));
    txtItemID.setToolTipText("");
    txtItemID.setText("");
    txtTotalNumberOfPages.setText("");
    txtTotalNumberOfPages.setEditable(false);
    txtTotalNumberOfPages.setPreferredSize(new Dimension(60, 21));
    jLabel11.setText("Count: ");
    jLabel7.setText("HasMoreItems: ");
    txtCount.setPreferredSize(new Dimension(60, 21));
    txtCount.setEditable(false);
    txtCount.setText("");
    txtReturnedItemCountActual.setPreferredSize(new Dimension(60, 21));
    txtReturnedItemCountActual.setEditable(false);
    txtReturnedItemCountActual.setText("asdf");
    txtReturnedItemCountActual.setText("");
    txtHasMoreItems.setPreferredSize(new Dimension(60, 21));
    txtHasMoreItems.setEditable(false);
    txtHasMoreItems.setText("");
    jPanel14.setLayout(borderLayout5);
    jLabel10.setText("TotalNumberOfPages:");
    jPanel9.setLayout(borderLayout6);
    jScrollPane1.getViewport().setBackground(Color.white);
    jPanel11.setPreferredSize(new Dimension(20, 2));
    jLabel13.setText("FinanceOfferID:");
    txtAutoPay.setBackground(UIManager.getColor("Button.background"));
    txtAutoPay.setMinimumSize(new Dimension(57, 21));
    txtAutoPay.setPreferredSize(new Dimension(60, 21));
    txtAutoPay.setText("");
    jPanel18.setLayout(gridBagLayout1);
    jPanel18.setBorder(BorderFactory.createEtchedBorder());
    jLabel6.setText("    ");
    jLabel14.setText("    ");
    jLabel15.setText("        ");
    jLabel16.setText("    ");
    jLabel17.setText("        ");
    jLabel18.setText("ReturnedItemCountActual:");
    jLabel19.setText("StartPrice:");
    txtFinanceOfferId.setBackground(UIManager.getColor("Button.background"));
    txtFinanceOfferId.setPreferredSize(new Dimension(60, 21));
    txtFinanceOfferId.setText("");
    jLabel9.setText("        ");
    jLabel12.setText("    ");
    jLabel20.setText("AutoPay:");
    txtStartPrice.setBackground(UIManager.getColor("Button.background"));
    txtStartPrice.setPreferredSize(new Dimension(60, 21));
    txtStartPrice.setRequestFocusEnabled(true);
    txtStartPrice.setText("");
    jLabel21.setText("Private Listing:");
    txtPrivateListing.setBackground(UIManager.getColor("Button.background"));
    txtPrivateListing.setPreferredSize(new Dimension(60, 21));
    txtPrivateListing.setText("");
    jLabel22.setText("    ");
    jLabel23.setText("LotSize:");
    txtLotSize.setBackground(UIManager.getColor("Button.background"));
    txtLotSize.setPreferredSize(new Dimension(60, 21));
    txtLotSize.setText("");
    jPanel6.setPreferredSize(new Dimension(143, 40));
    jLabel24.setText("ApplyShippingDiscount:");
    txtAppShippingDiscount.setBackground(UIManager.getColor("Button.background"));
    txtAppShippingDiscount.setPreferredSize(new Dimension(60, 21));
    txtAppShippingDiscount.setText("");
    getContentPane().add(panel1);
    panel1.add(jPanel3,  BorderLayout.NORTH);
    jPanel8.add(jLabel1, null);
    jPanel8.add(txtTransPerPage, null);
    jPanel4.add(jPanel5, null);
    jPanel5.add(jLabel5, null);
    jPanel5.add(txtItemID, null);
    jPanel4.add(jPanel7, null);
    jPanel4.add(jPanel8, null);
    jPanel7.add(jLabel2, null);
    jPanel7.add(txtPageNumber, null);
    jPanel3.add(jPanelModifiedTime, BorderLayout.CENTER);
    jPanel3.add(jPanel4, BorderLayout.NORTH);
    jPanelTimeFrom.add(jLabel3, null);
    jPanelTimeFrom.add(txtModTimeFrom, null);
    jPanelModifiedTime.add(jPanelTimeFrom, null);
    jPanelModifiedTime.add(jPanelTimeTo, null);
    jPanelTimeTo.add(jLabel4, null);
    jPanelTimeTo.add(txtModTimeTo, null);
    jPanel3.add(jPanel6, BorderLayout.SOUTH);
    jPanel6.add(btnCallGetItemTransactions, null);
    panel1.add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel2, BorderLayout.CENTER);
    jPanel2.add(jPanel9, BorderLayout.CENTER);
    jPanel9.add(jPanel10, BorderLayout.NORTH);
    jPanel9.add(jPanel12, BorderLayout.WEST);
    jPanel9.add(jPanel13, BorderLayout.EAST);
    jPanel9.add(jPanel15, BorderLayout.SOUTH);
    jPanel9.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(tblTransactions, null);
    jPanel1.add(jPanel14, BorderLayout.NORTH);
    jPanel14.add(jPanel18, BorderLayout.NORTH);
    jPanel14.add(jPanel11, BorderLayout.CENTER);
    jPanel11.add(jPanel22, null);
    jPanel18.add(jLabel8,           new GridBagConstraints(1, 1, GridBagConstraints.REMAINDER, GridBagConstraints.REMAINDER, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel11,       new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel6,     new GridBagConstraints(2, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtCount,    new GridBagConstraints(3, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel7,     new GridBagConstraints(5, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel14,     new GridBagConstraints(6, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtHasMoreItems,    new GridBagConstraints(7, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel15,     new GridBagConstraints(8, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel10,    new GridBagConstraints(9, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel16,     new GridBagConstraints(10, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtTotalNumberOfPages,    new GridBagConstraints(11, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel17,     new GridBagConstraints(4, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel13,  new GridBagConstraints(5, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel19,   new GridBagConstraints(9, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel9,  new GridBagConstraints(12, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel18, new GridBagConstraints(13, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel12,  new GridBagConstraints(14, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtReturnedItemCountActual, new GridBagConstraints(15, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel20,   new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtAutoPay, new GridBagConstraints(3, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtFinanceOfferId, new GridBagConstraints(7, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtStartPrice,  new GridBagConstraints(11, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel21,  new GridBagConstraints(13, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtPrivateListing,  new GridBagConstraints(15, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel22,  new GridBagConstraints(3, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtLotSize,   new GridBagConstraints(3, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel23,   new GridBagConstraints(1, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(jLabel24,   new GridBagConstraints(5, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel18.add(txtAppShippingDiscount,   new GridBagConstraints(7, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

    jPanel18.setPreferredSize(new Dimension(950, 130));
    this.setSize(new Dimension(950, 500));
  }

  static String[] transactionToColumns(TransactionType trans)
  {
    String[] cols = new String[totalColumns];
    int i = 0;
    cols[i++] = trans.getTransactionID();
    cols[i++] = trans.getTransactionPrice().toString();
    AmountType amt = trans.getAmountPaid();
    cols[i++] = amt == null ? "" : (new Double(amt.getValue())).toString();
    cols[i++] = trans.getQuantityPurchased().toString();
    UserType buyer = trans.getBuyer();
    cols[i++] = buyer == null ? "" : buyer.getUserID().toString();
    ShippingDetailsType shippingDetails = trans.getShippingDetails();
    ShippingServiceOptionsType [] sso = shippingDetails.getShippingServiceOptions();
    int size = sso != null ? sso.length : 0;
    cols[i++] = new Integer(size).toString();
    InternationalShippingServiceOptionsType [] isso = shippingDetails.getInternationalShippingServiceOption();
    size = isso != null ? isso.length : 0;
    cols[i++] = new Integer(size).toString();
    return cols;
  }

  void btnCallGetItemTransactions_actionPerformed(ActionEvent e) {
    try
    {
      GetItemTransactionsCall api = new GetItemTransactionsCall(this.apiContext);
      DetailLevelCodeType[] detailLevels = new DetailLevelCodeType[] {
          DetailLevelCodeType.ReturnAll,
      };
      api.setDetailLevel(detailLevels);

      TimeFilter tf = GuiUtil.getTimeFilterFromFields(
          this.txtModTimeFrom, this.txtModTimeTo);

      if( this.txtPageNumber.getText().length() > 0 &&
          this.txtTransPerPage.getText().length() > 0 )
      {
        PaginationType pgn = new PaginationType();
        pgn.setPageNumber(new Integer(this.txtPageNumber.getText()));
        pgn.setEntriesPerPage(new Integer(this.txtTransPerPage.getText()));

        api.setPagination(pgn);
      }

      // Call eBay.
      ItemIDType itemID = new ItemIDType(this.txtItemID.getText());
      final TransactionType[] transList = api.getItemTransactions(itemID, tf);

      PaginationResultType pnresult = api.getPaginationResult();

      // Display results.
      this.txtCount.setText(pnresult.getTotalNumberOfEntries().toString());

      this.txtHasMoreItems.setText(api.getHasMoreTransactions() ? "yes" : "no");
      this.txtTotalNumberOfPages.setText(
        pnresult.getTotalNumberOfPages() == null ? "" : pnresult.getTotalNumberOfPages().toString());

      String actualCountTxt = new Integer(api.getReturnedTransactionCountActual()).toString();
      this.txtReturnedItemCountActual.setText(actualCountTxt);

      ItemType item = api.getItem();
      Boolean autoPay = item.getAutoPay();
      if (autoPay != null) {
        this.txtAutoPay.setText(autoPay.toString());
      }
      else {
        this.txtAutoPay.setText("false");
      }
      Boolean privateListing = item.getPrivateListing();
      if (privateListing != null) {
        this.txtPrivateListing.setText(privateListing.toString());
      }
      else {
        this.txtPrivateListing.setText("false");
      }
      AmountType startPrice = item.getStartPrice();
      if (startPrice != null) {
        this.txtStartPrice.setText(new Double(startPrice.getValue()).toString());
      }

      this.txtFinanceOfferId.setText(item.getFinanceOfferID());
      Integer lotSize = item.getLotSize();
      if (lotSize != null) {
        this.txtLotSize.setText(lotSize.toString());
      }
      Boolean appShippingDiscount = item.getApplyShippingDiscount();
      if (appShippingDiscount != null) {
        this.txtAppShippingDiscount.setText(appShippingDiscount.toString());
      }

      String token = item.getSeller().getEIASToken();

      // Display items in table.
      TableModel dataModel = new AbstractTableModel() {
        public int getColumnCount() { return totalColumns; }
        public int getRowCount() { return transList == null ? 0 : transList.length;}
        public String getColumnName(int columnIndex){
          return colNames[columnIndex];
        }
        public Object getValueAt(int row, int col)
        {
          TransactionType trans = transList[row];
          return transactionToColumns(trans)[col];
        }
      };

      this.tblTransactions.setModel(dataModel);
    }
    catch(Exception ex)
    {
      ((FrameDemo)this.getParent()).showErrorMessage(ex.getMessage());
    }
  }
}

class DialogGetItemTransactions_btnCallGetItemTransactions_actionAdapter implements java.awt.event.ActionListener {
  DialogGetItemTransactions adaptee;

  DialogGetItemTransactions_btnCallGetItemTransactions_actionAdapter(DialogGetItemTransactions adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnCallGetItemTransactions_actionPerformed(e);
  }
}
