/*
 * SamplePortlet.java
 *
 * Created on May 27, 2004, 7:26 PM
 */

import javax.portlet.*;
import java.io.*;
import java.util.logging.*;

/**
 *
 * @author  avk
 */
public class SamplePortlet extends javax.portlet.GenericPortlet {
    
    public void init() {
        System.out.println("SamplePortlet in portalapp::init");
        
    }
    
    public void render() {
        System.out.println("SamplePortlet in portalapp::render");
    }
    
    public void processAction(ActionRequest request, ActionResponse actionResponse)
    throws PortletException, java.io.IOException {
        
        System.out.println("SamplePortlet in portalapp::processRequest");
    }
    
    public void doView(RenderRequest req, RenderResponse res)
    throws PortletException, IOException {
        System.out.println("SamplePortlet in portalapp::doView");
        req.setAttribute("test", "String set by SamplePortlet::processAction");
        res.setContentType("text/html");
        String jspName = "/WEB-INF/jsp/portlet-jsp.jsp";
        PortletRequestDispatcher rd =
        getPortletContext().getRequestDispatcher(jspName);
        rd.include(req, res);
    }
    
    public void doEdit(RenderRequest req, RenderResponse res)
    throws PortletException, IOException {
        System.out.println("SamplePortlet in portalapp::doEdit");
        /*
       res.setContentType("text/html");
      String jspName = "blah.jsp";
      PortletRequestDispatcher rd =
          getPortletContext().getRequestDispatcher("blah.jsp");
      rd.include(req, res);
         */
    }
    public void doHelp(RenderRequest req, RenderResponse res) {
        System.out.println("SamplePortlet in portalapp::doHelp");
        /*
       res.setContentType("text/html");
      String jspName = "blah.jsp";
      PortletRequestDispatcher rd =
          getPortletContext().getRequestDispatcher("blah.jsp");
      rd.include(req, res);
         */
    }
}
