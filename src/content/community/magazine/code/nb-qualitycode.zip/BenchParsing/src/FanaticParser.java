import java.util.Calendar;
import java.util.Date;

/**
 * This parser goes all way down to parse a Date as fast as physically possible.
 * We do both the parsing and the date building manually.
 */
public class FanaticParser extends VeryHardcodedParser
{
    /** Cached timestamp for each month start in the current year. */
    private static final long[] BASE_MONTH = new long[12];
    /** Number of milliseconds in one second. */
    private static final long MS_SEC = 1000L;
    /** Number of milliseconds in one minute. */
    private static final long MS_MIN = MS_SEC * 60;
    /** Number of milliseconds in one hour. */
    private static final long MS_HOUR = MS_MIN * 60;
    /** Number of milliseconds in one day. */
    private static final long MS_DAY = 24 * MS_HOUR;
    
    static
    {
        // Initialize the cache with help from Java's calendar dates, so we
        // don't have to worry about complications like leap years etc.
        Calendar c = Calendar.getInstance();
        c.set(1970, 0, 1, 0, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        
        for (int i = 0; i < BASE_MONTH.length; ++i)
        {
            c.set(Calendar.MONTH, i);
            BASE_MONTH[i] = c.getTimeInMillis();
        }
    }
    
    public Date parse (String s)
    {
        return new Date(BASE_MONTH[parseNN(s, 2) - 1] + (parseNN(s, 0) - 1) * MS_DAY +
	parseNN(s, 4) * MS_HOUR + parseNN(s, 6) * MS_MIN + parseNN(s, 8) * MS_SEC);
    }
}