import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Even more hardcoded than HardcodedParser: we avoid String.substring() and
 * Integer.parseInt(), replacing their calls by custom code to parse the
 * individual numeric components, directly from the source string.
 */
public class VeryHardcodedParser extends Parser
{
    public Date parse (String s)
    {
        return new GregorianCalendar(1970, parseNN(s, 2) - 1, parseNN(s, 0),
            parseNN(s, 4), parseNN(s, 6), parseNN(s, 8)).getTime();
    }
    
    public static int parseNN (String s, int pos)
    {
        return (s.charAt(pos) - '0') * 10 + (s.charAt(pos + 1) - '0');
    }
}