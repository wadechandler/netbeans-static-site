public class BenchParsing
{
    private final float fix;
    private final String testData;
    
    public BenchParsing (float fix, String testData)
    {
        this.fix = fix;
        this.testData = testData;
    }
    
    public void bench (Parser p)
    {
        String s = "";
        long time = System.nanoTime();
        long mem = Runtime.getRuntime().freeMemory();
        
        for (int i = (int)fix; i >= 0; --i)
            p.parse(testData);
        
        time = System.nanoTime() - time;
        mem -= Runtime.getRuntime().freeMemory();
        System.gc();
        String name = p.getClass().getName ();
        name = name.substring(name.indexOf('$') + 1);
        System.out.printf("%-17s: %.3fns / %.4f bytes\n", name, time / fix,  mem / fix);
    }
    
    public static void main (String[] args)
    {
        int LOOPS = 1000;
        float slow = 1.0f;
        boolean benchSDF = true;
        boolean benchSDFCached = true;
        boolean benchHardcoded = true;
        boolean benchVeryHardcoded = true;
        boolean benchExtremeHardcoded = true;
        boolean benchFanatic = true;
        int maxCycles = 3;
        
        if (args.length >= 1)
        {
            slow = Float.parseFloat(args[0]);
            
            if (args.length >= 2)
            {
                maxCycles = Integer.parseInt(args[1]);
                
                if (args.length >= 3)
                {
                    benchSDF = args[2].indexOf('S') != -1;
                    benchSDFCached = args[2].indexOf('C') != -1;
                    benchHardcoded = args[2].indexOf('H') != -1;
                    benchVeryHardcoded = args[2].indexOf('V') != -1;
                    benchExtremeHardcoded = args[2].indexOf('X') != -1;
                    benchFanatic = args[2].indexOf('F') != -1;
                }
            }
        }
        
        final BenchParsing b = new BenchParsing(LOOPS / slow, "3112235959");
        
        for (int cycle = 0; cycle <= maxCycles; ++cycle)
        {
            System.out.println("---- " + cycle + " ----");
            final boolean slowerWarmup = (cycle == 0 && slow == 1.0f);
            if (slowerWarmup) slow /= 8;
            if (benchSDF) b.bench(new SDFParser());
            if (benchSDFCached) b.bench(new SDFCachedParser());
            if (benchHardcoded) b.bench(new HardcodedParser());
            if (benchVeryHardcoded) b.bench(new VeryHardcodedParser());
            if (benchExtremeHardcoded) b.bench(new ExtremeHardcodedParser());
            if (benchFanatic) b.bench(new FanaticParser());
            if (slowerWarmup) slow *= 8;
        }
    }
}
