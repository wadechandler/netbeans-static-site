import java.util.Date;

public abstract class Parser
{
    public abstract Date parse (String s);
}
