import java.util.Date;

/**
 * Another step in hard-codedness... while VeryHardcodedParser uses the
 * GregorianCalendar constructor and then converts it to a Date,
 * here we create the Date directly. Notice that this means using a deprecated API!
 */
public class ExtremeHardcodedParser extends VeryHardcodedParser
{
    public Date parse (String s)
    {
        return new Date(70, parseNN(s, 2) - 1, parseNN(s, 0),
            parseNN(s, 4), parseNN(s, 6), parseNN(s, 8));
    }
}