import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Not optimized at all: Just invokes the vanilla SimpleDateFormat API.
 */
public class SDFParser extends Parser
{
    public Date parse (String s)
    {
        try
        {
            return new SimpleDateFormat("ddMMHHmmss").parse(s);
        }
        catch (ParseException e)
        {
            return null;
        }
    }
}