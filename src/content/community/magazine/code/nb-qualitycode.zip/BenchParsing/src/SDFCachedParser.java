import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Uses SimpleDateFormat, but is faster than SDFParser, because we build the
 * format object only once and reuse it. Unfortunately, this is only good for
 * single-threaded programs, as SimpleDateFormat is not thread-safe.
 */
public class SDFCachedParser extends Parser
{
    private static final SimpleDateFormat fmt = new SimpleDateFormat("ddMMHHmmss");
    
    public Date parse (String s)
    {
        try
        {
            return fmt.parse(s);
        }
        catch (ParseException e)
        {
            return null;
        }
    }
}