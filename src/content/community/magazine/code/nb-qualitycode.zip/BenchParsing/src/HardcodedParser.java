import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Abandons SimpleDateFormat in favor of an algorithm that hard-codes the
 * date format. Supporting a new format would require a new method.
 */
public class HardcodedParser extends Parser
{
    public Date parse (String s)
    {
        return new GregorianCalendar(1970, Integer.parseInt(s.substring(2, 4)) - 1,
            Integer.parseInt(s.substring(0, 2)), Integer.parseInt(s.substring(4, 6)),
            Integer.parseInt(s.substring(6, 8)), Integer.parseInt(s.substring(8, 10))).getTime();
    }
}