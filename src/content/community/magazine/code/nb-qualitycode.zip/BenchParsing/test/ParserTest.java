import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import junit.framework.TestCase;

public class ParserTest extends TestCase
{
    private static final int LOOPS = 100000;
    private static final String testData = "3112235959";
    private static Date testDate;
    
    static
    {
        try
        {
            testDate = new SimpleDateFormat ("ddMMHHmmss").parse (testData);
        }
        catch (ParseException e) { }
    }
    
    public void testSDF ()
    {
        Parser instance = new SDFParser();
        Date result = null;
        
        for (int i = 0; i < LOOPS; ++i)
            result = instance.parse(testData);
        
        assertEquals(testDate, result);
    }
    
    public void testSDFCached()
    {
        Parser instance = new SDFCachedParser();
        Date result = null;
        
        for (int i = 0; i < LOOPS; ++i)
            result = instance.parse(testData);
        
        assertEquals(testDate, result);
    }
    
    public void testHardcoded ()
    {
        Parser instance = new HardcodedParser();
        Date result = null;
        
        for (int i = 0; i < LOOPS; ++i)
            result = instance.parse(testData);
        
        assertEquals(testDate, result);
    }
    
    public void testVeryHardcoded ()
    {
        Parser instance = new VeryHardcodedParser();
        Date result = null;
        
        for (int i = 0; i < LOOPS; ++i)
            result = instance.parse(testData);
        
        assertEquals(testDate, result);
    }
    
    public void testExtremeHardcoded ()
    {
        Parser instance = new ExtremeHardcodedParser();
        Date result = null;
        
        for (int i = 0; i < LOOPS; ++i)
            result = instance.parse(testData);
        
        assertEquals(testDate, result);
    }
    
    public void testFanatic ()
    {
        Parser instance = new FanaticParser();
        Date result = null;
        
        for (int i = 0; i < LOOPS; ++i)
            result = instance.parse(testData);
        
        assertEquals(testDate, result);
    }
}
