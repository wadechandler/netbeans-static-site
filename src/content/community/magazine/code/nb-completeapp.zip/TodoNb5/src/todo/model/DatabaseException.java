package todo.model;

public class DatabaseException extends ModelException {
    
    /** Creates a new instance of BancoDeDadosException */
    public DatabaseException(String msg, Throwable cause) {
        super(msg, cause);
    }
    
}
