package todo.model;

public class ValidationException extends ModelException {
    
    /** Creates a new instance of ValidacaoException */
    public ValidationException(String msg) {
        super(msg);
    }
    
}
